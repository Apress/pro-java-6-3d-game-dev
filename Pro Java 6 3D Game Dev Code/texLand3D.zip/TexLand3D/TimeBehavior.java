
// TimeBehavior.java
// Andrew Davison, June 2006, ad@fivedots.coe.psu.ac.th

/* Update the positions of all the moving balls in the supplied
   ArrayList every timeDelay ms by calling their updatePosition() 
   methods.
*/

import java.util.*;
import java.util.Enumeration;
import javax.media.j3d.*;


public class TimeBehavior extends Behavior
{
  private WakeupCondition timeOut;
  private ArrayList<MovingBall> mBalls;  // the moving balls


  public TimeBehavior(int timeDelay, ArrayList<MovingBall> mbs)
  { mBalls = mbs;
    timeOut = new WakeupOnElapsedTime(timeDelay);
  }

  public void initialize()
  { wakeupOn( timeOut );  }


  public void processStimulus( Enumeration criteria )
  { // ignore criteria
    for (MovingBall mBall : mBalls)    // move all the balls
      mBall.updatePosition(); 
    wakeupOn( timeOut );
  } // end of processStimulus()


}  // end of TimeBehavior class
