
// MovingBall.java
// Andrew Davison, June 2006, ad@fivedots.coe.psu.ac.th

/* A textured, lit ball is placed within the scene, and then
   moved around by TimeBehavior repeated calling updatePosition().

   The ball rotates slightly at random as it moves, and will turn
   when it reaches the edge of the floor.

   MovingBall maintains the scene graph:
     ballTG --> sphere
   Translations and rotations are applied to the ballTG TransformGroup.

   MovingBall is a simplified version of Sprite3D in the Tour3D example.
*/

import java.text.DecimalFormat;
import java.util.*;

import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.geometry.*;


public class MovingBall 
{
  private final static float OBS_FACTOR = 0.5f;  
             /* used to reduce the radius of the ball when testing if 
                the ball is at the edge of the floor */

  private static final float RADIUS = 0.25f;   // of sphere
  private final static float STEP = 0.1f;      // step size for moving the ball
  private final static double ROTATE_AMT = Math.PI / 18.0;  // 10 degrees

  // material colours
  private static final Color3f BLACK = new Color3f(0.0f, 0.0f, 0.0f);
  private static final Color3f GRAY = new Color3f(0.6f, 0.6f, 0.6f);
  private static final Color3f WHITE = new Color3f(0.9f, 0.9f, 0.9f);


  private float[][] heights;   // the floor's height map
  private int floorLen;        // length of floor sides

  private TransformGroup ballTG;    // TG which the ball hangs off

  // reusable objects for various calculations
  private Transform3D t3d, toMove, toRot;  // for manipulating ballTG's transform
  private Vector3f posnVec, moveVec;       // for manipulating the ball's position 

  private Random rand;
  private DecimalFormat df;   // for simpler output during debugging


  public MovingBall(Texture2D ballTex, float[][] hs)
  { 
    heights = hs;
    floorLen = heights.length-1; 

    rand = new Random();
    df = new DecimalFormat("0.##");  // 2 dp

    t3d = new Transform3D();
    toMove = new Transform3D();
    toRot = new Transform3D();
    posnVec = new Vector3f();
    moveVec = new Vector3f();

    makeBall(ballTex);
  }  // end of MovingBall()


  private void makeBall(Texture2D ballTex)
  /* A textured sphere is placed at a random position on the 
     floor's surface. The scenegraph is:  ballTG --> sphere
  */
  {
    Appearance app = new Appearance();

    // combine texture with material and lighting of underlying surface
    TextureAttributes ta = new TextureAttributes();
    ta.setTextureMode( TextureAttributes.MODULATE );
    app.setTextureAttributes( ta );

    // assign gray material with lighting
    Material mat= new Material(GRAY, BLACK, GRAY, WHITE, 25.0f);
       // sets ambient, emissive, diffuse, specular, shininess
    mat.setLightingEnable(true);
    app.setMaterial(mat);

    // apply texture to shape
    if (ballTex != null)
      app.setTexture(ballTex);

    // randomly position the ball on the floor
    t3d.set( genStartPosn()); 

    // the ball's transform group can be changed (so it can move/rotate)
    ballTG = new TransformGroup(t3d);
    ballTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
    ballTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);

    // the ball has normals for lighting, and texture support
    Sphere ball = new Sphere(RADIUS, 
                           Sphere.GENERATE_NORMALS |
                           Sphere.GENERATE_TEXTURE_COORDS,
                           15, app);   // default divs == 15
    ballTG.addChild(ball);
  }  // end of makeBall()



  private Vector3f genStartPosn()
  // position the ball anywhere on the floor
  {
    float x = (float)((rand.nextDouble() * floorLen)-floorLen/2);
    float z = (float)((rand.nextDouble() * floorLen)-floorLen/2);
    float y = getHeight(x, z) + RADIUS;  // so ball is resting on the florr
    posnVec.set(x,y,z);
    return posnVec;
  }  // end of genStartPosn()


  public TransformGroup getTG()
  // called from WrapTexLand3D
  {  return ballTG; }


  public void updatePosition()
  /* Rotate the ball a bit and then move it forward. 
     If the move isn't posiible, then turn the ball until 
     it can move. Called from TimeBehavior. */
  {
    doRotateY();
    while (!moveFwd())
      doRotateY();
  } // end of updatePosition()



  private void doRotateY()
  // rotate the ball around its y-axis by a small random amount
  {
    ballTG.getTransform( t3d );
    toRot.rotY( rotateSlightly() );
    t3d.mul(toRot);
    ballTG.setTransform(t3d);
  } // end of doRotateY()


  private double rotateSlightly()
  // rotate between -ROTATE_AMT and ROTATE_AMT radians
  {  return rand.nextDouble()*ROTATE_AMT*2 - ROTATE_AMT;  }


  private boolean moveFwd()
  /* Move the ball forward by STEP amount, but only if the move 
     keeps the ball on the floor. This is done by testing the move
     first (with tryMove()) before actually carrying out the move
     permanently.
  */
  {
    moveVec.set(0,0,STEP);
    tryMove(moveVec);  // test the move, storing the new position in posnVec
    if (offEdge(posnVec))
      return false;
    else {  // carry out the move
      float heightChg = getHeight(posnVec.x, posnVec.z) + RADIUS - posnVec.y;
      moveVec.set(0, heightChg, STEP);
      doMove(moveVec);
      return true;
    }
   }  // end of moveFwd()


  private void tryMove(Vector3f theMove)
  /* Calculate the effect of the given translation but
     don't update the ball's position until it's been
     tested. Store the new position in the posnVec global.
  */
  { ballTG.getTransform(t3d);
    toMove.setTranslation(theMove);
    t3d.mul(toMove);
    t3d.get(posnVec);
    // printTuple(posnVec, "nextLoc");
  }  // end of tryMove()


  private boolean offEdge(Vector3f loc)
  // is the ball's location off the edge of the floor?
  {
    float r = RADIUS*OBS_FACTOR;
    return ((loc.x - r < -floorLen/2) ||     // off left edge?
            (loc.x + r > floorLen/2) ||      // off right?
            (loc.z - r < -floorLen/2) ||     // off back?
            (loc.z + r > floorLen/2));      // off front?
  }  // end of offEdge()


  private float getHeight(float x, float z)
  // calculate a height for the ball's (x,z) location
  {
    float xLoc = x + floorLen/2;  // (xLoc,zLoc) is on the height map
    float zLoc = z + floorLen/2;
 
    // split (xLoc,zLoc) coordinate into integer and fractional parts
    int xH = (int) Math.floor(xLoc);
    float xFrac = xLoc - xH;

    int zH = (int) Math.floor(zLoc);
    float zFrac = zLoc - zH;

    /* the average height is based on the (xLoc,zLoc) coord's distance from 
       the four surrounding heights in the heights[][] array. */
    float height = ((heights[zH][xH] * (1.0f-zFrac) * (1.0f-xFrac)) +
                    (heights[zH][xH+1] * (1.0f-zFrac) * xFrac) +
                    (heights[zH+1][xH] * zFrac * (1.0f-xFrac) ) +
                    (heights[zH+1][xH+1] * zFrac * xFrac) );
    return height;
  }  // end of getHeight()


  private void doMove(Vector3f theMove)
  // translate the ball by the amount in theMove
  {
    ballTG.getTransform(t3d);
    toMove.setTranslation(theMove);
    t3d.mul(toMove);
    ballTG.setTransform(t3d);
  }  // end of doMove()


  private void printTuple(Tuple3f t, String id)
  // used for debugging, here and in subclasses
  {
    System.out.println(id + " x: " + df.format(t.x) + 
				", " + id + " y: " + df.format(t.y) +
				", " + id + " z: " + df.format(t.z));
  }  // end of printTuple()


}  // end of MovingBall class
