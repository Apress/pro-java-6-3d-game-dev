
Chapter 6. A Multitextured Landscape

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2


Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew


==================================
Files and directories here:

  * TexLand3D.java, WrapTexLand3D.java, MultiFloor.java,
    SplashShape.java, MovingBall.java, TimeBehavior.java
       // 6 Java files

  * images/	// a directory holding 7 textures
      - flowers.jpg, grass.gif, light.gif, r.gif,
        spot.gif, stoneBits.gif, water.jpg

==================================
Requirements:

* J2SE 5.0 or later from http://java.sun.com/j2se/

* Java 3D 1.4.0 (or 1.3.2) from https://java3d.dev.java.net/

==================================
Compilation: 
  $ javac *.java

Execution: 
  $ java TexLand3D
     /* you can move the camera using Java 3D's ORbitBehavior controls
        to pan, rotate, and zoom */

-----------
Last updated: 3rd March 2007