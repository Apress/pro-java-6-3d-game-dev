
// TexLand3D.java
// Andrew Davison, June 2006, ad@fivedots.coe.psu.ac.th

/* An example showing the various uses of multi-texturing for
   making landscape look more interesting.

   The scene's floor is multi-textured with two ground detail
   textures (grass and bits of stone) and a light map.

   The floor also has 'splashes' of extra textures (purple flowers
   and water).

   Several (NUM_BALLS) textured balls move over the floor 
   in random ways. Their position are updated at regular intervals.

   The background is light blue. The balls reflect two light sources, 
   and the camera can be moved using OrbitBehavior controls.
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class TexLand3D extends JFrame
{
  public TexLand3D() 
  {
    super("TexLand3D");
    Container c = getContentPane();
    c.setLayout( new BorderLayout() );
    WrapTexLand3D w3d = new WrapTexLand3D();     // panel holding the 3D canvas
    c.add(w3d, BorderLayout.CENTER);

    setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    pack();
    setResizable(false);    // fixed size display
    setVisible(true);
  } // end of TexLand3D()


// -----------------------------------------

  public static void main(String[] args)
  { new TexLand3D(); }

} // end of TexLand3D class
