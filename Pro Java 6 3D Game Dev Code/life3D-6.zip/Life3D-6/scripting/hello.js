
// hello.js
// Andrew Davison, August 2006, ad@fivedots.coe.psu.ac.th

// Used by ScriptingEx2 class

println('hello world');
