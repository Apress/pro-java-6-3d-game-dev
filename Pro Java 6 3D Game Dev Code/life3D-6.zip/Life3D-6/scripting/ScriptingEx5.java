
// ScriptingEx5.java
// Andrew Davison, July 2006, ad@fivedots.coe.psu.ac.th

/* A container for three code snippets:
   * 1. how a script can use importPackage() to create a Java object

   * 2. how a script can use Java methods against a Java variable
     input to a script

   * 3. how to call a JavaScript function using the Invocable version
     of the engine
*/


import java.io.*;
import javax.script.*;


public class ScriptingEx5 
{
  public static void main(String[] args) throws ScriptException 
  // all script exceptions are thrown
  {
    // create a script engine manager
    ScriptEngineManager factory = new ScriptEngineManager();

    // create a JavaScript engine
    ScriptEngine engine = factory.getEngineByName("js");


    // 1) use a Java package in a script
    engine.eval("importPackage(java.util); " +
                "today = new Date(); " +
                "println('Today is ' + today);");


    // 2) use a String method on a Java variable inside a script
    String name = "Andrew Davison";
    engine.put("name", name);

    engine.eval("nm2 = name.toUpperCase();" +
                "println('Uppercase name: ' + nm2)");


    // 3) store a script function in the engine
    engine.eval("function sayHello(name) {" +
                " println('Hello ' + name);" +
                "}");

    // invoke the function using the Invocable version of the engine
    Invocable invocableEngine = (Invocable) engine;
    Object[] fnArgs = {"Andrew"};   // the function's name argument
    try {
      invocableEngine.invokeFunction("sayHello", fnArgs);
    }
    catch(NoSuchMethodException e)
    {  System.out.println(e);  }

  } // end of main()

} // end of ScriptingEx5 class
