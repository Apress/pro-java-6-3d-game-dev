
Chapter N3. Get a Life (the Java 6 Way)

From the online book:
  Killer Game Programming in Java
  http://fivedots.coe.psu.ac.th/~ad/jg

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew


==================================
Files here:

  * ScriptingEx1.java
       // the three steps for executing a JavaScript string

  * ScriptingEx2.java, hello.js
       // the three steps for executing the JavaScript file, hello.js

  * ScriptingEx3.java, sums.js
       // how to communicate with a script (sums.js)

  * ScriptingEx4.java, sums.js
       // how to communicate with a compiled script (sums.js again)

  * ScriptingEx5.java
       // how to call a JavaScript function, and use importPackage()

These short examples illustrate different aspects of Java scripting.

==================================
Requirements:

* Java SE 6.0 from http://java.sun.com/javase/6/
  Version 6 supports the scripting used in this example.

==================================
Compilation: 
  $ javac *.java

Execution: 
  $ java ScriptingEx1
  $ java ScriptingEx2
  $ java ScriptingEx3
  $ java ScriptingEx4
  $ java ScriptingEx5

-----------
Last updated: 15th August 2006