
// ScriptingEx4.java
// Andrew Davison, August 2006, ad@fivedots.coe.psu.ac.th

/* Shows how to communicate with a compiled script
   sums.js is used again.


*/


import java.io.*;
import javax.script.*;


public class ScriptingEx4 
{
  public static void main(String[] args)
  {
    // create a script engine manager
    ScriptEngineManager factory = new ScriptEngineManager();

    // create a JavaScript engine
    ScriptEngine engine = factory.getEngineByName("js");

    // load and compile the script
    CompiledScript cs = loadCompile(engine, "sums.js");

    int age = 40;
    int[] nums = { 1, 2, 3, 4, 5, 6, 7};   // sum is 28

    // pass values to script using ScriptEngine
    engine.put("age", age);
    engine.put("nums", nums);

    // evaluate compiled script
    evalCSummer(cs, engine);
  } // end of main()


  static private CompiledScript loadCompile(ScriptEngine engine, String fnm)
  // load the script from file, and compile it
  {
    Compilable compEngine = (Compilable) engine;  // compilable version of engine

    CompiledScript cs = null;
    try {
      FileReader fr = new FileReader(fnm);
      cs = compEngine.compile(fr);
      fr.close();
    }
    catch(FileNotFoundException e)
    {  System.out.println(fnm + " not found");  }
    catch(IOException e)
    {  System.out.println("Could not read " + fnm);  }
    catch(ScriptException e)
    {  System.out.println("Problem compiling script in " + fnm);  }
    catch(NullPointerException e)
    {  System.out.println("Problem reading script in " + fnm);  }

    return cs;
  }  // end of loadCompile()


  static private void evalCSummer(CompiledScript cs, ScriptEngine engine)
  /* Evaluate compiled script from a file, and get results.
    
     The evaluation uses CompiledScript.eval(), but the IO mechanisms
     are the same as for ordinary scripts.

     An Object is returned by CompiledScript.eval(), and the scripting 
     variable value for sum is retrieved with ScriptingEngine.get()
  */
  {
    boolean isBigger = false;
    try {
      isBigger = (Boolean) cs.eval();   // converts Object to boolean
    }
    catch(ScriptException e)
    {  System.out.println("Problem evaluating script");  }

    // JavaScript sum number mapped to a Java Double
    double sum = (Double) engine.get("sum");
    System.out.println("(java) sum = " + sum);

    System.out.println("age is bigger = " + isBigger);
    System.out.println();
  }  // end of evalSummer()


} // end of ScriptingEx4 class
