
// ScriptingEx1.java
// Andrew Davison, August 2006, ad@fivedots.coe.psu.ac.th

/* Shows the three steps for executing a JavaScript string
*/

import java.io.*;
import javax.script.*;


public class ScriptingEx1 
{
  public static void main(String[] args) 
  {
    // create a script engine manager (step 1)
    ScriptEngineManager factory = new ScriptEngineManager();

    // create a JavaScript engine (step 2)
    ScriptEngine engine = factory.getEngineByName("js");

    try {
      // evaluate a JavaScript string (step 3)
      engine.eval("println('hello world')");
    }
    catch(ScriptException e)
    {  System.out.println(e);  }
  } // end of main()


} // end of ScriptingEx1 class
