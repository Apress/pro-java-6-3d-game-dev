
// sums.js
// Andrew Davison, August 2006, ad@fivedots.coe.psu.ac.th

/* Compare the input age with the sum of the numbers in nums[],
   and return a boolean indicating if age is bigger or nor.

   Used by ScriptingEx3 and ScriptingEx4.
*/

println("age = " + age);
println("nums[6] = " + nums[6]);

var sum = 0;
for(var i=0; i < nums.length; i++)
  sum += nums[i];

println("sum = " + sum);

age > sum;
