
// ScriptingEx3.java
// Andrew Davison, August 2006, ad@fivedots.coe.psu.ac.th

/* Shows how to communicate with a script (sums.js), and
   the two main ways of retrieving results from the script.
*/


import java.io.*;
import javax.script.*;


public class ScriptingEx3 
{
  public static void main(String[] args)
  {
    // create a script engine manager
    ScriptEngineManager factory = new ScriptEngineManager();

    // create a JavaScript engine
    ScriptEngine engine = factory.getEngineByName("js");

    int age = 40;
    int[] nums = { 1, 2, 3, 4, 5, 6, 7};   // sum is 28

    // pass values to script
    engine.put("age", age);    // simple types are copied
    engine.put("nums", nums);  // object references are copied

    // evaluate script from a file
    evalSummer(engine, "sums.js");

    /* Change values and re-evaluate script.
       The script will see the change to nums[] since it's an
       object, but not the change to num. */
    age = 50;       // increased by 10
    nums[6] = 27;   // increased by 20, so sum is 48
    evalSummer(engine, "sums.js");

    /* Explicitly put age into the engine again. Now
       the script will see the new age value (50). */
    engine.put("age", age);
    evalSummer(engine, "sums.js");
  } // end of main()


  static private void evalSummer(ScriptEngine engine, String fnm)
  /* Evaluate script from a file, and get results.

     One form of output is the Object returned by ScriptingEngine.eval(),
     which is cast to a Boolean, and then to a boolean.

     The other form is the retrieval of the scripting variable value
     for sum with ScriptingEngine.get()
  */
  {
    boolean isBigger = false;
    try {
      FileReader fr = new FileReader(fnm);
      isBigger = (Boolean) engine.eval(fr);   // converts Object to boolean
      fr.close();
    }
    catch(FileNotFoundException e)
    {  System.out.println(fnm + " not found");  }
    catch(IOException e)
    {  System.out.println("IO problem with " + fnm);  }
    catch(ScriptException e)
    {  System.out.println("Problem evaluating script in " + fnm);  }
    catch(NullPointerException e)
    {  System.out.println("Problem reading script in " + fnm);  }

    // JavaScript sum number mapped to a Java Double
    double sum = (Double) engine.get("sum");
    System.out.println("(java) sum = " + sum);

    System.out.println("age is bigger = " + isBigger);
    System.out.println();
  }  // end of evalSummer()


} // end of ScriptingEx3 class
