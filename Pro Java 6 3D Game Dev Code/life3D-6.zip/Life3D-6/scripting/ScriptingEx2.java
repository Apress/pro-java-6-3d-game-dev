
// ScriptingEx2.java
// Andrew Davison, August 2006, ad@fivedots.coe.psu.ac.th

/* Shows the three steps for executing the 
   JavaScript file, hello.js
*/

import java.io.*;
import javax.script.*;


public class ScriptingEx2 
{
  public static void main(String[] args)
  {
    // create a script engine manager
    ScriptEngineManager factory = new ScriptEngineManager();

    // create a JavaScript engine
    ScriptEngine engine = factory.getEngineByName("js");

    // evaluate JavaScript code from the hello.js file
    evalScript(engine, "hello.js");
  } // end of main()


  static private void evalScript(ScriptEngine engine, String fnm)
  // evaluate JavaScript code from a file
  {
    try {
      FileReader fr = new FileReader(fnm);
      engine.eval(fr);
      fr.close();
    }
    catch(FileNotFoundException e)
    {  System.out.println(fnm + " not found");  }
    catch(IOException e)
    {  System.out.println("IO problem with " + fnm);  }
    catch(ScriptException e)
    {  System.out.println("Problem evaluating script in " + fnm);  }
    catch(NullPointerException e)
    {  System.out.println("Problem reading script in " + fnm);  }
  }  // end of evalScript()

} // end of ScriptingEx2 class
