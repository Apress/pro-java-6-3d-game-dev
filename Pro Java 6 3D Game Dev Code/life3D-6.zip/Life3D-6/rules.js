
// rules.js
// Andrew Davison, July 2006, ad@fivedots.coe.psu.ac.th
/*
   Input data is:
    *  states[] from 0 to 26 for all neignbours and the cell
    *  numberLiving in states[]

   The Java code reads the final bindings for the booleans
   beBorn and toDie.
*/

var beBorn = false;
var toDie = false;

if (states[4])
  beBorn = true;

if (states[5] && states[6] && states[17] && states[14])
  toDie = true;

if (numberLiving > 5)
  toDie = true;
