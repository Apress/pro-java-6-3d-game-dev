
// LifeSplashTest.java
// Andrew Davison, July 2006, ad@fivedots.coe.psu.ac.th

/* This class is a test rig for the ClockAnimation class,
   its clock images, and the lifeSplash image. They are
   used (unchanged) in the main Life3D application.

   An animated clock is displayed over the top of the 
   splashscreen until LifeSplashTest's JFrame is made visible
   after a 5 second delay.

   Usage: java -splash:lifeSplash.jpg LifeSplashTest
    
   For details on JAR creation, see the readme.txt file in
   this directory.
 */

import javax.swing.*;
import java.awt.*;


public class LifeSplashTest
{
  public static void main(String args[])
  {
    ClockAnimation ca = new ClockAnimation(7,7);
    ca.start();

    try {
      Thread.sleep(5000);   // 5 secs asleep
    }
    catch (InterruptedException ignored) {}

    // make a window
    JFrame frame = new JFrame("Life3D");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JLabel label = new JLabel("Life3D has started", JLabel.CENTER);

    frame.add(label, BorderLayout.CENTER);
    frame.setSize(300, 95);

    // center this window
    Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension winDim = frame.getSize();
    frame.setLocation( (screenDim.width-winDim.width)/2,
                      (screenDim.height-winDim.height)/2);

    frame.setVisible(true);
  } // end of main()

} // end of LifeSplashTest class
