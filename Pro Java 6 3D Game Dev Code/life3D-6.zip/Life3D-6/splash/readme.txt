
Chapter N3. Get a Life (the Java 6 Way)

From the online book:
  Killer Game Programming in Java
  http://fivedots.coe.psu.ac.th/~ad/jg

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew


==================================
Files and Directories here:

  * LifeSplashTest.java, ClockAnimation.java 
       // 2 Java files
   
  * lifeSplash.jpg   // the splash image
  * mainClass.txt    // manifest information used when making the JAR

  * clocks/ 
      // a directory of 8 clock images, stored in
         clock0.gif to clock7.gif; used for animating
         the splash

This example is a simple test-rig for the ClockAnimation class, 
the lifeSplash.jpg splash image, and the clock images used in
the Life3D application.
   
==================================
Requirements:

* Java SE 6.0 from http://java.sun.com/javase/6/
  Version 6 supports splashscreens used in this example.


==================================
Compilation: 
  $ javac *.java

Execution: 
  $ java -splash:lifeSplash.jpg LifeSplashTest

Making a JAR:
  $ jar -cvfm LifeSplashTest.jar mainClass.txt *.class clocks lifeSplash.jpg
       // this creates LifeSplashTest.jar

Using the JAR
  $ java -jar LifeSplashTest.jar

  or double click on LifeSplashTest.jar


-----------
Last updated: 15th August 2006