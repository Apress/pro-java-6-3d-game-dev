
Chapter 5. When Worlds Collide

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2


Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew


==================================
Bouncer

An Odejava simulation of a bouncing ball, that doesn't use Java 3D.

Bouncer can be used to test the Odejava installation.

Requirements:

* J2SE 5, Odejava
  -- see readme.txt in the parent directory above this one
     for installation details

==================================
Compilation: 
  $ javac Bouncer.java

Execution: 
  $ java Bouncer

-----------
Last updated: 3rd March 2007