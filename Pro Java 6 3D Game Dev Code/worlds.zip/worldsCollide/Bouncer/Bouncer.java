
// Bouncer.java
// Andrew Davison, April 2006, ad@fivedots.coe.psu.ac.th

/*  A sphere is dropped onto a floor, and its position and 
    other information is printed out periodically.

    The sphere is initialised in initDynamics(), and may have 
    linear and angular velocity.

    When the sphere hits the floor (i.e. makes a contact), then
    it bounces. The amount of bounce and friction is set 
    in examineContacts().

    The simulation continues until MAX_STEPS steps have
    been carried out.
 */

import java.text.DecimalFormat;
import javax.vecmath.*;   // from Java 3D

import org.odejava.*;
import org.odejava.ode.*;
import org.odejava.collision.*;


public class Bouncer 
{
  private static final int MAX_STEPS = 1000;  // simulation steps

  private World world;

  // sphere's body and geom
  private Body sphere;
  private GeomSphere sphereGeom;

  // for collisions
  private HashSpace collSpace;      // holds collision info
  private JavaCollision collCalcs;  // calculates collisions
  private Contact contactInfo;      // for accessing contact details

  // for holding sphere info
  private Vector3f pos = new Vector3f();
  private AxisAngle4f axisAng = new AxisAngle4f();

  private DecimalFormat df;


  public Bouncer() 
  {
    df = new DecimalFormat("0.#");  // 1 dp

    // set-up
    Odejava.getInstance();
    initWorld();
    initStatics();
    initDynamics();

    simulate(MAX_STEPS);  // carry out the simulation

    cleanUp();
  } // end of Bouncer()


  private void initWorld() 
  // inialize the world and collision objects engines
  {
    world = new World();
    world.setGravity(0f, -0.2f, 0);  // down y-axis (9.8 is way too fast)

    // max interactions per step (bigger is more accurate, but slower)
    world.setStepInteractions(10);

    // set step size (smaller is more accurate, but slower)
    world.setStepSize(0.05f);

    // create a collision space for the world's geoms
    collSpace = new HashSpace();

    collCalcs = new JavaCollision(world);   // for collision calculations
    contactInfo = new Contact( collCalcs.getContactIntBuffer(),
                               collCalcs.getContactFloatBuffer());
  }  // end of initWorld()


  private void initStatics() 
  /* Initialize static objects. These geoms have no bodies, and so
     the simulation doesn't change their position or orientation.
  */
  {
    // a floor, facing upward
    GeomPlane groundGeom = new GeomPlane(0, 1.0f, 0, 0);
    collSpace.add(groundGeom);
  }  // end of initStatics()


  private void initDynamics() 
  /* Initialize dynamic objects. These geoms have bodies, so the
     simulation may move them or change their orientation as 
     they collide with things. 
  */
  {
    // a sphere of radius 1, mass 1
    sphereGeom = new GeomSphere(1.0f);
    sphere = new Body("sphere", world, sphereGeom);
    sphere.adjustMass(1.0f);

    sphere.setPosition(0, 4.0f, 0);    // starts 4 unit above the floor
    sphere.setLinearVel(2.0f, 0, 0);   // moving to the right
    sphere.setAngularVel(0, 1.0f, 0);  // velocity around y-axis

    collSpace.addBodyGeoms(sphere);
  } // end of initDynamics()


  private void simulate(int maxSteps) 
  // Step through the simulation, and report every 10 steps.
  {
    int stepCount = 1;
    while (stepCount < maxSteps) {
      step();
      // print sphere's details every 10th step
      if ((stepCount % 10) == 0) {
        pos = sphere.getPosition();
        sphere.getAxisAngle(axisAng);
        System.out.println("Step " + stepCount + ") Pos: (" +
                 df.format(pos.x) + ", " + df.format(pos.y) + ", " +
                 df.format(pos.z) + "), angle: " +
                 df.format( Math.toDegrees(axisAng.angle)) );
                 // ", quat: " + sphere.getQuaternion() );
      }
      stepCount++;
/*
      // sleep a bit
      try {
        Thread.sleep(50);   // ms
      }
      catch(Exception e) {}
*/
    }
  } // end of simulate()


  private void step() 
  {
    collCalcs.collide(collSpace);   // find collisions
    examineContacts();              // examine contact points
    collCalcs.applyContacts();      // apply contact joints

    world.stepFast();               // make another step
  }  // end of step()   


  private void examineContacts() 
  // make a sphere contact bounce
  {
    for (int i = 0; i < collCalcs.getContactCount(); i++) {
      contactInfo.setIndex(i);    // look at the ith contact point 

      // if the contact involves the sphere, then make it bounce
      if ((contactInfo.getGeom1() == sphereGeom) ||
          (contactInfo.getGeom2() == sphereGeom)) {
        contactInfo.setMode(Ode.dContactBounce);
        contactInfo.setBounce(0.82f);      // 1 is max bounciness
        contactInfo.setBounceVel(0.1f);    // min velocity for a bounce
        contactInfo.setMu(100.0f);         // 0 is friction-less
        // contactInfo.getPosition(pos);
        // System.out.println("Contact Sphere: " + pos);
      }
    }
  } // end of examineContacts()


  private void cleanUp() 
  {
    collSpace.delete();
    collCalcs.delete();
    world.delete();
    Ode.dCloseODE();
  }  // end of cleanUp()



  // ------------------------------------------------------------

  public static void main(String[] args) 
  {  new Bouncer();  }

} // end of Bouncer class
