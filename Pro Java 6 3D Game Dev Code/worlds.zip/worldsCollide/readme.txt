
Chapter 5. When Worlds Collide

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2


Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew


==================================
Contents

There are two subdirectories:

* Balls3D	-- an example using Odejava and Java 3D

* Bouncer	-- an example using Odejava only

Details on how to compile and run these examples can be found 
in the readme.txt files in their directories.

You can use the Bouncer example to test your installation of Odejava. 


==================================
Requirements:

* J2SE 5.0 from http://java.sun.com/j2se/1.5.0/index.jsp
  (I use its generic ArrayList.)

* Java 3D 1.4.0 (or 1.3.2) from https://java3d.dev.java.net/

* Odejava from https://odejava.dev.java.net/
  See below for details on installing. 

Best Installation order:
  1. J2SE 
  2. Java 3D
  3. Odejava   (Odejava can reuse one of Java 3D's JAR files, vecmath.jar)


=============================================
Installing Odejava (from https://odejava.dev.java.net/)


The "Odejava snapshot" is available from the "2006-01-15_cvs (1)" folder, 
accessed via the website's "Documents & files" menu item. 

The snapshot is a zipped file containing Odejava's platform-independent 
JARs. Extract odejava.jar from the odejava\odejava subdirectory, 
and log4j-1.2.9.jar from odejava\odejava\lib. 

The platform-dependent elements are a separate download.
Grab the "Windows Binaries" zip file from the "004-10-30 natives (4)" folder, 
and extract the odejava.dll file from its windows\release subdirectory.

You should now have three files: 
    odejava.dll, odejava.jar, and log4j-1.2.9.jar

The two JARs should be copied to <JAVA HOME>\jre\lib\ext, and the DLL to 
<JAVA HOME>\jre\bin. On my machine, <JAVA HOME> is 
c:\Program Files\Java\jdk1.5.0_06. 

If you've installed the JRE as well, then also copy the JARs and DLL into 
the corresponding directories below <JRE HOME>. On my machine, <JRE HOME> is 
c:\Program Files\Java\jre1.5.0_06.

You can now use the Bouncer example to test your Odejava installation. 

-----------
Last updated: 3rd March 2007