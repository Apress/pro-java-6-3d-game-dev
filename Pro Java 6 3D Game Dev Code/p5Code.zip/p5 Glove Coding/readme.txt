
Chapter 14. The P5 Glove

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

=============================================
Contents of this Directory

* ShowGlove/
    - a GUI application that displays the P5 glove's data 

* MotionTest/
    - a test-rig for testing the FPSGlove class

* HandView3D/
    - an example combining Java 3D, the P5 Glove, and 
      3D sound using JOAL: the result is a trip around
      a musical cow
    - HandView3D uses the FPSGlove class from the MotionTest
      example

=============================================

Other Hardware/Software You'll Need

P5 Glove
--------
* A new P5 Virtual Reality Glove can be found for around US$50-60 at eBay. 
  I bought mine from CyberWorld (http://www.cwonline.com)

* Download Carl Kenner's Dual Mode Driver Beta 3 for Windows,
  (A_DualModeDriverBeta3.zip) from the "Files" section of the 
  p5Glove group at Yahoo:
     http://groups.yahoo.com/group/p5glove/
  Drivers for Linux and OS X can be found at Kenner's website
  http://www.geocities.com/carl_a_kenner/p5glove.html. I've only
  used the Windows driver.
  For installation details please read the chapter.


Java 3D (needed for HandView3D)
-------
* Available at https://java3d.dev.java.net/


JOAL (needed for HandView3D)
----
* Available at https://joal.dev.java.net/

* Please read my chapter about JOAL, "Chapter 13. 3D Sound with JOAL"
  at http://fivedots.coe.psu.ac.th/~ad/jg2/

---------
Last updated: 4th March 2007