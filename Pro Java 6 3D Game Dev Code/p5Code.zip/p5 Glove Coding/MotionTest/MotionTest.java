
// MotionTest.java
// Andrew Davison, December 2005, ad@fivedots.coe.psu.ac.th

/* Every GLOVE_DELAY ms, display information extracted from 
   the P5 glove.

   MotionTest is a 'test-rig' for the FPSGlove class before using
   it in HandView3D. 

  MotionTest prints:
      - N (near) or F (far) for the z-axis position of the glove
        relative to the tower;

      - L (ROLL_LEFT) or R (ROLL_RIGHT) for the glove's roll;

      - * if enough fingers are bent

   If isAPressed() is true (the glove's 'A' button has been 
   pressed), then MotionTest stops polling and exits.
*/


public class MotionTest
{
  // delay between glove polling
  private static final int GLOVE_DELAY = 100;  // ms

  private int i = 1;   // used for formatting the text output


  public MotionTest() 
  /* While isAPressed() is false, update the glove, get the 
     current settings, sleep a bit, then repeat.
  */
  {
    FPSGlove glove = new FPSGlove();

    while(!glove.isAPressed()) {
      glove.update();   // update the glove settings

      // show z-axis, roll, hand clenched
      showZPosition(glove); 
      showRoll(glove); 
      if (glove.isClenched()) { 
        System.out.print("* ");
        i++;
      }

      if (i > 20) {    // lots of info printed, so add a newline
        i = 1;
        System.out.println();
      }

      try {   // sleep a bit
        Thread.sleep(GLOVE_DELAY);
      }
      catch(InterruptedException e) {}
    }

    glove.close();
  }  // end of MotionTest()



  private void showZPosition(FPSGlove glove)
  /* Depending on the z-axis position constant, print 'N' (NEAR), 
     'F' (FAR), or nothing. NEAR means close to the tower, FAR is
     far from it. 
  */
  {
    int handPos = glove.getZPosition();
    switch(handPos) {
      case FPSGlove.NEAR: System.out.print("N "); i++; break;
      case FPSGlove.FAR: System.out.print("F "); i++; break;
      case FPSGlove.MIDDLE: break;
      default: System.out.print("?? "); i++; break;    // shouldn't happen
    }
  }  // end of showZPosition()


  private void showRoll(FPSGlove glove)
  /* Depending on the roll constant, print 'L' (ROLL_LEFT), 
     'R' (ROLL_RIGHT), or nothing. 
  */
  {
    int handOrient = glove.getRoll();
    switch(handOrient) {
       case FPSGlove.ROLL_LEFT: System.out.print("L "); i++; break;
       case FPSGlove.ROLL_RIGHT: System.out.print("R "); i++; break;
       case FPSGlove.LEVEL: break;
       default: System.out.print("?? "); i++; break;    // shouldn't happen
    }
  }  // end of showRoll()


  // -------------------------------------------------------------

  public static void main (String[] args) 
  {  new MotionTest();  }

}  // end of MotionTest.java
