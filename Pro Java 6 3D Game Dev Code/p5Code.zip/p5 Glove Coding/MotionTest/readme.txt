
Chapter 14. The P5 Glove

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

=============================================
MotionTest

The MotionTest application is a test-rig for the FPSGlove class
used in HandView3D.

The FPSGlove class is a wrapper for Kenner's CP5DLL class,
which only accesses the data needed by HandView3D.
 
The interface returns constants and booleans instead of 
arrays of floats. 

MotionTest consists of:
  MotionTest.java
  FPSGlove.java


=============================================
Other Software/Hardware You Need

* Carl Kenner's Java API. See the chapter for details 
  on installing it. 
* A P5 Glove

=============================================
Compilation: 

$ javac *.java
    // make sure you have Kenner's Java API files installed (see chapter)

=============================================
Execution: 

Use the runP5.bat batch file.

$ runP5 MotionTest
    // make sure you have Kenner's Java API files installed (see chapter)

---------
Last updated: 4th March 2007