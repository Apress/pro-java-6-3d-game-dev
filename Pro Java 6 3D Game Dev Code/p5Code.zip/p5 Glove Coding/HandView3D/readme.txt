
Chapter 14. The P5 Glove

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

=============================================
HandView3D

Take a trip around a 3D scene that contains a musical cow.
Navigate with the P5 glove.


MotionTest consists of:
  - 8 Java files: HandView3D.java, WrapHandView3D.java,
                  ModelLoader.java, JOALSoundMan.java,
                  CheckerFloor.java, ColouredTiles.java,
                  P5Behavior.java, FPSGlove.java   

  - 3 subdirectories:
       images/, holding lava.jpg
       Models/, holding cow.obj
       Sounds/, holding spacemusic.wav

=============================================
Other Software/Hardware You Need

* Carl Kenner's Java API. See the chapter for details 
  on installing it. 

* A P5 Glove.

* Java 3D, https://java3d.dev.java.net/

* JOAL, https://joal.dev.java.net/
  Please read my chapter about JOAL, "Chapter 13. 3D Sound with JOAL"
  at http://fivedots.coe.psu.ac.th/~ad/jg2/


=============================================
Compilation: 

$ javac *.java
    /* make sure you have Kenner's Java API files,
       Java 3D, and JOAL installed */

=============================================
Execution: 

Use the HandView3D.bat batch file.

$ HandView3D
    /* make sure you have Kenner's Java API files,
       Java 3D, and JOAL installed */

---------
Last updated: 4th March 2007