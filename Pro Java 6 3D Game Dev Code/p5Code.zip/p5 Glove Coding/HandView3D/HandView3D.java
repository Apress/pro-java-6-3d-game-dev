
// HandView3D.java
// Andrew Davison, November 2006, ad@fivedots.coe.psu.ac.th

/* A 3D world containing a musical cow.

   Wave your hand left and right, in and out, to move
   around the scene. Incidentally, your hand has to be inside
   a P5 glove or nothing will happen.

   The sound is produced with JOAL, so varies in intensity depending
   on the user's position. It can be switched off/on by
   clenching your fist or, less agressively, by pressing
   the glove's 'A' button.

   Use the HandView3D.bat batch file to start the application:
     > HandView3D
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class HandView3D extends JFrame
{
  private WrapHandView3D w3d;

  public HandView3D() 
  {
    super("HandView3D");
    Container c = getContentPane();
    c.setLayout( new BorderLayout() );
    w3d = new WrapHandView3D();     // panel holding the 3D canvas
    c.add(w3d, BorderLayout.CENTER);

    addWindowListener( new WindowAdapter() {
      public void windowClosing(WindowEvent e)
      { w3d.cleanUp();   // of JOAL and the P5
        System.exit(0);
      }
    });

    pack();
    setResizable(false);    // fixed size display
    setVisible(true);
  } // end of HandView3D()


// -----------------------------------------

  public static void main(String[] args)
  {  new HandView3D(); }

} // end of HandView3D class
