
// WrapHandView3D.java
// Andrew Davison, November 2006, ad@fivedots.coe.psu.ac.th

/* The usual world: checkboard floor, background, lights.
   The new bit is a musical cow. The music is supplied
   by JOAL, using JOALSoundMan. See addCow().

   The viewpoint is moved/rotated with a P5 glove behavior,
   and has a JOAL listener connected to it (see
   createUserControls()).

   There's a cleanUp() method for closing down JOAL and the
   P5 glove at termination time.
*/


import javax.swing.*;
import java.awt.*;

import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.image.*;
import javax.media.j3d.*;
import javax.vecmath.*;



public class WrapHandView3D extends JPanel
// Holds the 3D canvas
{
  private static final int PWIDTH = 512;   // size of panel
  private static final int PHEIGHT = 512; 

  private static final int BOUNDSIZE = 100;  // larger than world

  // info used to position initial viewpoint
  private final static double Z_START = 9.0;

  private static final String BG_DIR = "images/";  
               // directory location of background texture

  private static final String COW_SND = "spacemusic";


  private SimpleUniverse su;
  private BranchGroup sceneBG;
  private BoundingSphere bounds;   // for environment nodes

  private JOALSoundMan soundMan;   // manages the JOAL source and listener
  private P5Behavior p5Beh;        
                        // moves/rotates the viewpoint with P5 glove input


  public WrapHandView3D()
  // A panel holding a 3D canvas
  {
    setLayout( new BorderLayout() );
    setOpaque( false );
    setPreferredSize( new Dimension(PWIDTH, PHEIGHT));

    GraphicsConfiguration config =
					SimpleUniverse.getPreferredConfiguration();
    Canvas3D canvas3D = new Canvas3D(config);
    add("Center", canvas3D);
    canvas3D.setFocusable(true);     // give focus to the canvas 
    canvas3D.requestFocus();

    su = new SimpleUniverse(canvas3D);

    // depth-sort transparent objects on a per-geometry basis
    View view = su.getViewer().getView();
    view.setTransparencySortingPolicy(View.TRANSPARENCY_SORT_GEOMETRY);

    soundMan = new JOALSoundMan();

    createSceneGraph();
    createUserControls();

    su.addBranchGraph( sceneBG );
  } // end of WrapHandView3D()


  private void createSceneGraph()
  // initilise the scene
  { 
    sceneBG = new BranchGroup();
    bounds = new BoundingSphere(new Point3d(0,0,0), BOUNDSIZE);  

    lightScene();         // add the lights
    addBackground("lava.jpg");
    sceneBG.addChild( new CheckerFloor().getBG() );  // add the floor
    addCow();

    sceneBG.compile();   // fix the scene
  } // end of createSceneGraph()


  private void lightScene()
  /* One ambient light, 2 directional lights */
  {
    Color3f white = new Color3f(1.0f, 1.0f, 1.0f);

    // Set up the ambient light
    AmbientLight ambientLightNode = new AmbientLight(white);
    ambientLightNode.setInfluencingBounds(bounds);
    sceneBG.addChild(ambientLightNode);

    // Set up the directional lights
    Vector3f light1Direction  = new Vector3f(-1.0f, -1.0f, -1.0f);
       // left, down, backwards 
    Vector3f light2Direction  = new Vector3f(1.0f, -1.0f, 1.0f);
       // right, down, forwards

    DirectionalLight light1 = 
            new DirectionalLight(white, light1Direction);
    light1.setInfluencingBounds(bounds);
    sceneBG.addChild(light1);

    DirectionalLight light2 = 
        new DirectionalLight(white, light2Direction);
    light2.setInfluencingBounds(bounds);
    sceneBG.addChild(light2);
  }  // end of lightScene()



  private void addCow()
  /* Use ModelLoader (from ObjView3D) to load a cow model,
     and position thw JOAL source at the same spot.
  */
  {
    ModelLoader ml = new ModelLoader();
    Transform3D t3d = new Transform3D();

    // a cow model
    t3d.setTranslation( new Vector3d(-2,0,-4));   // move
    t3d.setScale(0.7); // shrink
    TransformGroup tg1 = new TransformGroup(t3d);
    tg1.addChild( ml.getModel("cow.obj", 1.3) );
    sceneBG.addChild(tg1);

    if (!soundMan.load(COW_SND, -2, 0, -4, true))
      System.out.println("Could not load " + COW_SND);
    else
      soundMan.play(COW_SND);
  }  // end of addCow()



  private void createUserControls()
  /* Position the camera and JOAL listener at the same spot.
     Connect the P5 behavior to the camera's viewpoint.
  */
  { 
    ViewingPlatform vp = su.getViewingPlatform();

    // position viewpoint
    TransformGroup targetTG = vp.getViewPlatformTransform();
    Transform3D t3d = new Transform3D();
    targetTG.getTransform(t3d);
    t3d.setTranslation( new Vector3d(0,1,Z_START));
    targetTG.setTransform(t3d);

    // position JOAL listener at same spot as camera
    soundMan.moveListener(0, (float)Z_START);

    // set up P5 glove controls to move the viewpoint
    p5Beh = new P5Behavior(soundMan, COW_SND);
    p5Beh.setSchedulingBounds(bounds);
    vp.setViewPlatformBehavior(p5Beh);
  } // end of createUserControls()


  private void addBackground(String fnm)
  /* Create a spherical background. The texture for the 
     sphere comes from fnm. */
  {
    Texture2D tex = loadTexture(BG_DIR + fnm);

    Sphere sphere = new Sphere(1.0f,
			      Sphere.GENERATE_NORMALS_INWARD |
				  Sphere.GENERATE_TEXTURE_COORDS, 8);   // default = 15 (4, 8)
    Appearance backApp = sphere.getAppearance();
	backApp.setTexture( tex );

	BranchGroup backBG = new BranchGroup();
    backBG.addChild(sphere);

    Background bg = new Background();
    bg.setApplicationBounds(bounds);
    bg.setGeometry(backBG);

    sceneBG.addChild(bg);
  }  // end of addBackground()


  private Texture2D loadTexture(String fn)
  // load image from file fn as a texture
  {
    TextureLoader texLoader = new TextureLoader(fn, null);
    Texture2D texture = (Texture2D) texLoader.getTexture();
    if (texture == null)
      System.out.println("Cannot load texture from " + fn);
    else {
      System.out.println("Loaded texture from " + fn);
      texture.setEnable(true);
    }
    return texture;
  }  // end of loadTexture()


  public void cleanUp()
  // shut down the glove (in the behavior) and JOAL
  { 
    p5Beh.stopGlove();
    soundMan.cleanUp(); 
  }  // end of cleanUp()

} // end of WrapHandView3D class