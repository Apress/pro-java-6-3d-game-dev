
// FPSGlove.java
// Andrew Davison, December 2005, ad@fivedots.coe.psu.ac.th

/* This FPSGlove class is an adapter for Carl Kenner's CP5DLL class,
   which is part of his Dual Mode driver (Beta 3) for the
   P5 Virtual Reality Glove, version 5.0.12.8, December 2004. 

   The class and driver are available from Yahoo's P5 group,
   http://groups.yahoo.com/group/p5glove/, in the files section
   as A_DualModeDriverBeta3.zip

   This FPSGlove class assumes there's only one glove, and uses
   the glove's z-axis position, roll orientation, finger bends, and 
   button settings.

   * getZPosition() returns a constant representing the z-axis
     position of the glove relative to the tower

   * getRoll() returns a constant representing the
     roll orientation of the glove

   * isClenched() returns true if enough fingers are bent

   * isAPressed() returns true if the 'A' button is pressed

   The methods rely on a series of constraints for deciding
   how to interpret the glove's z- axis position, roll, and finger bends.
   These were determined by observing how the glove responded in
   the ShowGlove application.

   The z-axis is reversed so that the positive direction is towards
   the user. 

   Call update() to update the values before calling the get() methods.

   This class switches off the glove's mouse mode until 
   close() is called. NOTE: on Windows XP/98, the mouse mode
   is not restored by calling P5_RestoreMouse() in close().
*/

import com.essentialreality.*;


public class FPSGlove
{
  // public z-axis position constants (for closeness to tower)
  public final static int NEAR = 0;
  public final static int FAR = 1;
  public final static int MIDDLE = 2;

  // public roll orientation constants
  public final static int ROLL_LEFT = 3;
  public final static int ROLL_RIGHT = 4;
  public final static int LEVEL = 5;

  /* The following constraints were arrived at by observing the glove 
     with the ShowGlove application. The P5 tower was on the right of
     the monitor, level with the front of the screen; I wore the 
     glove on my right hand.

     The constraints will need adjusting if your tower is positioned 
     differently, or you wear the glove on your left hand.
  */

  // finger bend constraints
  private final static int FINGERS_BENT = 3;  // the min. no. of fingers that need to be bent
  private final static int BEND_MIN = 500;    // how far a finger must bend to count

  // rotation constraints
  private final static int RIGHT_ROLL_MIN = 80;  // how far to roll right before it counts
  private final static int LEFT_ROLL_MIN = -40;  // how far to roll left 

  // position constraints
  private final static int NEAR_MIN = 500;    // how near to the tower before it counts
  private final static int FAR_MIN = 900;   // how far back


  // links to the P5 glove(s)
  private CP5DLL gloves;
  private CP5DLL.P5State gloveState;


  public FPSGlove()
  {
    gloves = new CP5DLL();

    // initialize the glove
    if (!gloves.P5_Init()) {
      System.out.println("P5 Initialization failed");
      System.exit(1);
    }

    gloves.P5_SetForwardZ(-1);    // so positive Z is towards the user
    gloves.P5_SetMouseState(-1, false);  // disable mouse mode

    // make sure there's only one glove
    int numGloves = gloves.P5_GetCount();
    if (numGloves > 1) {
      System.out.println("Too many gloves detected: " + numGloves);
      System.exit(1);
    }

    gloveState = gloves.state[0];  // store a reference to the glove state
  } // end of FPSGlove()


  // ---------------- accessing data ------------------
  // update the state before calling the get methods

  public void update()
  { gloveState.update(); }


  public int getZPosition()
  /* Convert the z- axis position into a NEAR, FAR or MIDDLE position
     constant based on the NEAR_MIN and FAR_MIN constraints.
  */
  {
    float zPos = gloveState.filterPos[2];    // filtered z-axis position

    if (zPos < NEAR_MIN) {    // near to the tower
      // System.out.println("front (" + zPos + ")");
      return NEAR;
    }
    else if (zPos > FAR_MIN) {  // far from the tower
      // System.out.println("back (" + zPos + ")");
      return FAR;
    }
    else
      return MIDDLE;
  }  // end of getZPosition()


  public int getRoll()
  /* Convert the glove's roll into ROLL_LEFT, ROLL_RIGHT, or LEVEL 
     constant based on the LEFT_ROLL_MIN and RIGHT_ROLL_MIN constraints.
  */
  {
    float roll = gloveState.filterRoll;   // the glove's roll

    if (roll < LEFT_ROLL_MIN) {   // rolled left
      // System.out.println("Rolled left (" + roll + ")");
      return ROLL_LEFT;
    }
    else if (roll > RIGHT_ROLL_MIN) {  // rolled right
      // System.out.println("Rolled right (" + roll + ")");
      return ROLL_RIGHT;
    }
    else
      return LEVEL;
  }  // end of getRoll()


  public boolean isClenched()
  /* Return true or false if at least FINGERS_BENT fingers 
     are bent to be less than BEND_MIN.
  */
  {
    short[] fingerBends = gloveState.fingerAbsolute;

    boolean isClenched = false;
    int bentCount = 0;
    for(int i=0; i < fingerBends.length; i++) {
      if (fingerBends[i] <= BEND_MIN)
        bentCount++;
    }
    // if (bentCount >= FINGERS_BENT)
    //  System.out.println("Fire (" + bentCount + ")");

    return (bentCount >= FINGERS_BENT);
  }  // end of isClenched()


  public boolean isAPressed()
  // return true if the first button on the glove ('A') is pressed
  { boolean[] buttonPresses = gloveState.button;
    return buttonPresses[0];
  }


  public void close()
  { gloves.P5_RestoreMouse(-1);  // restore mouse mode (does not work)
    gloves.P5_Close();  
  }

} // end of FPSGlove class
