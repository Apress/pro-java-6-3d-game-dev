
// P5Behavior.java
// Andrew Davison, November 2006, ad@fivedots.coe.psu.ac.th

/* Every DELAY ms (75ms), update the P5 glove
   and get its current settings.

   The camera can go forward, backwards, rotate left or right. The
   moves and rotations can be combined depending on the
   z-axis posiition and roll orientation of the glove.

   When enough of the user's fingers are bent, or button A is
   pressed, then the sound is switched on/off. This only happens
   after enough time has passed since the previous toggle.

   All the settings are processed in each call to processStimulus(), 
   so combinations of moves, rotates, and sound toggling are possible.

   The behaviour is added to the user's viewpoint. 
   It extends ViewPlatformBehavior so that targetTG is available
   to it, the ViewPlatform's tranform.

   doMove() and rotateY() are lifted from KeyBehavior in ObjView3D, 
   along with their vector and rotation constants. They're extended
   so that changes to the viewpoint are also applied to the
   JOAL listener. This means that the listener stays with the camera
   as it moves.

   This behaviour does not support lateral or vertical movement.
*/

import java.awt.AWTEvent;
import java.awt.event.*;
import java.util.Enumeration;
import java.text.DecimalFormat;

import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.behaviors.vp.*;


public class P5Behavior extends ViewPlatformBehavior
{
  private static final int DELAY = 75;   // ms (polling interval)
  private static final int TOGGLE_MAX = 14;   
        // toggle count at which soundPlaying can be toggled

  private static final double ROT_AMT = Math.PI / 36.0;   // 5 degrees
  private static final double MOVE_STEP = 0.2;

  // hardwired movement vectors
  private static final Vector3d FWD = new Vector3d(0,0,-MOVE_STEP);
  private static final Vector3d BACK = new Vector3d(0,0,MOVE_STEP);

  // for repeated calcs
  private Transform3D t3d = new Transform3D();
  private Transform3D toMove = new Transform3D();
  private Transform3D toRot = new Transform3D();
  private Vector3d trans = new Vector3d();

  private WakeupCondition wakeUpCond;
  private FPSGlove glove;

  // sound-related
  private JOALSoundMan soundMan; 
  private String soundNm;    // of the JOAL source
  private boolean soundPlaying = true;
  private int toggleCounter = 0;

  private DecimalFormat df = new DecimalFormat("0.##");  // 2 dp


  public P5Behavior(JOALSoundMan sm, String nm)
  { 
    soundMan = sm;
    soundNm = nm;

    glove = new FPSGlove();
    wakeUpCond = new WakeupOnElapsedTime(DELAY);
  } // end of P5Behavior()


  public void initialize()
  {  wakeupOn(wakeUpCond);  }


  public void processStimulus(Enumeration criteria)
  /* Update the glove, get the current settings,
     and apply them to the camera. */
  {
    glove.update();  // update the glove settings

    // possibly translate, turn, and toggle the sound
    translate();
    turn();
    toggleSound();

    wakeupOn(wakeUpCond);       // make sure we are notified again
  } // end of processStimulus()


  private void translate()
  // depending on the z-axis position constant, move forward or back
  {
    int handPos = glove.getZPosition();
    switch(handPos) {
      case FPSGlove.NEAR: doMove(FWD); break;
      case FPSGlove.FAR: doMove(BACK); break;
      case FPSGlove.MIDDLE: break;
      default: System.out.println("pos?"); break;  // shouldn't happen
    }
  }  // end of translate()


  private void turn()
  // depending on the roll constant, turn left or right
  {
    int handOrient = glove.getRoll();
    switch(handOrient) {
       case FPSGlove.ROLL_LEFT: 
                rotateY(ROT_AMT); break;   // turn left
       case FPSGlove.ROLL_RIGHT: 
                rotateY(-ROT_AMT); break; // turn right
       case FPSGlove.LEVEL: break;
       default: System.out.println("rot?"); break;  // shouldn't happen
    }
  }  // end of turn()


  private void toggleSound()
  /* Toggle sound playing if the glove is clenched or
     button A is pressed, but only if the toggleCounter
     has reached TOGGLE_MAX. This imposes an interval
     between the toggling. */
  {
    if (toggleCounter < TOGGLE_MAX)
      toggleCounter++;

    if ((glove.isClenched()||glove.isAPressed()) &&
        (toggleCounter == TOGGLE_MAX)) {
      toggleCounter = 0;  // reset

      if (soundPlaying)   // play --> paused
        soundMan.pause(soundNm);
      else  // paused --> resumed
        soundMan.play(soundNm);
      soundPlaying = !soundPlaying;
    }
  }  // end of toggleSound()



  private void rotateY(double radians)
  // rotate about y-axis by radians
  { targetTG.getTransform(t3d);   // targetTG is the ViewPlatform's tranform
    toRot.rotY(radians);
    t3d.mul(toRot);
    targetTG.setTransform(t3d);

    // rotate the JOAL listener
    soundMan.turnListener((int) Math.toDegrees(radians));
  } // end of rotateY()


  private void doMove(Vector3d theMove)
  // move by the amount in theMove
  { 
    targetTG.getTransform(t3d);
    toMove.setTranslation(theMove);
    t3d.mul(toMove);
    targetTG.setTransform(t3d);

    // reposition the JOAL listener
    t3d.get(trans);
    // printTuple(trans, "loc");
    soundMan.setListenerPos((float)trans.x, (float)trans.z);
  } // end of doMove()


  private void printTuple(Tuple3d t, String id)
  // used for debugging, here and in subclasses
  {
    System.out.println(id + " x: " + df.format(t.x) + 
				", " + id + " y: " + df.format(t.y) +
				", " + id + " z: " + df.format(t.z));
  }  // end of printTuple()



  public void stopGlove()
  // shut down the glove and behavior
  {
    glove.close();
    setEnable(false);
  } // end of stopGlove()

} // end of P5Behavior class
