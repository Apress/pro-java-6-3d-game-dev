
Chapter 14. The P5 Glove

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

=============================================
ShowGlove

The ShowGlove application presents the P5 Glove's data in an
easy-to-read GUI format.

ShowGlove consists of:
  ShowGlove.java
  SpringUtilities.java  // from Sun's J2SE 1.4.2 tutorial
  Glove.java


=============================================
Other Software/Hardware You Need

* Carl Kenner's Java API. See the chapter for details 
  on installing it. 
* A P5 Glove


=============================================
Compilation: 

$ javac *.java
    // make sure you have Kenner's Java API files installed (see chapter)

=============================================
Execution: 

Use the runP5.bat batch file.

$ runP5 ShowGlove
    // make sure you have Kenner's Java API files installed (see chapter)

---------
Last updated: 4th March 2007