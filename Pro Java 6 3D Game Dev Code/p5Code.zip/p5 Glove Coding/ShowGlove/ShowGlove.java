
// ShowGlove.java
// Andrew Davison, December 2005, ad@fivedots.coe.psu.ac.th

/* Evert GLOVE_DISPLAY ms, display information extracted 
  from the P5 glove.

   Display:
     * filtered (x,y,z) position and (pitch,yaw,roll)
     * finger bend amounts
     * button presses
     * visible LEDs, and their values
     * current frame no. and frame rate
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.text.DecimalFormat;



public class ShowGlove extends JFrame 
{
  // time delay between glove polling
  private static final int GLOVE_DELAY = 200;  // ms


  // GUI variables
  private JTextField handInfo[];
    /* displays the filtered glove position (X,Y,Z) 
       and the filtered Pitch/Yaw/Roll. */
  private JTextField fingers[];     // finger bends for thumb -- small finger
  private JTextField timeInfo[];    // frame and framerate 
  private JRadioButton buttons[];   // the four glove buttons: pressed or not?
  private JCheckBox ledBoxes[];     // which of the LEDs are on?
  private JTextField ledFields[];   // the LED values

  private Glove glove;

  // for glove polling
  private Timer pollTimer;   // timer which triggers the polling
  private DecimalFormat df;



  public ShowGlove()
  {
    super("Show Glove Information");

    glove = new Glove();
    initGUI();

    addWindowListener( new WindowAdapter() {
      public void windowClosing(WindowEvent e)
      { glove.close();
        pollTimer.stop();   // stop the timer
        System.exit(0);
       }  
    });

    pack();
    setResizable(false);
    setVisible(true);

    df = new DecimalFormat("0");    // no dp, or "0.#" for 1 dp
    startPolling();
  }  // end of ShowGlove()



  // -------------------- create the GUI ---------------------------

  private void initGUI() 
  {
    // left side of main panel; vertical layout
    JPanel leftPanel = new JPanel();
    leftPanel.setLayout( new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
    leftPanel.add( makeHandInfoPanel() ); 
    leftPanel.add( makeFingersPanel() );
    leftPanel.add( makeTimingsPanel() );

    // right side of main panel; vertical layout
    JPanel rightPanel = new JPanel();
    rightPanel.setLayout( new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
    rightPanel.add( makeButtonsPanel() );
    rightPanel.add( makeLEDsPanel() );

    // set JFrame's layout
    Container c = getContentPane();
    c.setLayout( new BorderLayout(5,5) );

    JPanel p1 = new JPanel();
    p1.add(leftPanel);
    c.add(p1, "West");

    JPanel p2 = new JPanel();
    p2.add(rightPanel);
    c.add(p2, "East");
  }  // end of initGUI()


  private JPanel makeHandInfoPanel()
  // labelled name/value panel for (x,y,z) and (pitch,yaw,roll)
  {
    String handLabels[] = {"X,Y,Z:", "Pitch,Yaw,Roll:"};
    handInfo = new JTextField[handLabels.length];
    return makeLabelledTextBox("Filtered Hand Info", handLabels, handInfo);
  }  // end of makeHandInfoPanel()


  private JPanel makeFingersPanel()
  // labelled name/value panel for finger bends
  {
    String fingerLabels[] = {"Thumb:", "Index:", "Middle:", "Ring:", "Small:"};
    fingers = new JTextField[fingerLabels.length];
    return makeLabelledTextBox("Finger Bends", fingerLabels, fingers);
  }  // end of makeFingersPanel()


  private JPanel makeTimingsPanel()
  // labelled name/value panel for frame no and frame rate
  {
    String timingsLabels[] = {"Frame No.:", "Frame Rate:"};
    timeInfo = new JTextField[timingsLabels.length];
    return makeLabelledTextBox("Frames Info.", timingsLabels, timeInfo);
  }  // end of makeTimingsPanel()


  private JPanel makeLabelledTextBox(String title, String labels[],
                                                     JTextField tfs[])
  /* Create a panel with a title line, consisting of rows of label
     and textfield pairs. */
  {
    int numRows = labels.length;

    JPanel p = new JPanel();
    p.setLayout( new GridLayout(numRows, 2, 5, 5));
    TitledBorder titleBorder = BorderFactory.createTitledBorder(title);
    p.setBorder(titleBorder);  

    for(int i=0; i < numRows; i++) {
      p.add( new JLabel(labels[i], SwingConstants.RIGHT) );
      tfs[i] = new JTextField(10);
      tfs[i].setEditable(false);
      tfs[i].setBackground(Color.white);
      p.add( tfs[i] );
    }

    return p;
  }  // end of makeLabelledTextBox()


  private JPanel makeButtonsPanel()
  // buttons info panel: grid with 1 row, Glove.NUM_BUTTONS cols
  {
    JPanel buttonsPanel = new JPanel();
    buttonsPanel.setLayout( new GridLayout(1, Glove.NUM_BUTTONS));
    TitledBorder buttonsTitle = BorderFactory.createTitledBorder("Buttons");
    buttonsPanel.setBorder(buttonsTitle);  

    buttons = new JRadioButton[Glove.NUM_BUTTONS];
    for (int i=0; i < Glove.NUM_BUTTONS; i++) {
      char ch = (char) ('A' + i);    // to generate A, B, C, D labels
      buttons[i] = new JRadioButton(""+ch);
      buttons[i].setEnabled(false);
      buttonsPanel.add(buttons[i]);
    }

    return buttonsPanel;
  }  // end of makeButtonsPanel()


  private JPanel makeLEDsPanel()
  // LEDs info panel: grid with Glove.NUM_LEDS rows, 2 cols
  {
    JPanel ledsPanel = new JPanel( new SpringLayout() );
    TitledBorder ledsTitle = BorderFactory.createTitledBorder("LEDs");
    ledsPanel.setBorder(ledsTitle);  

    ledBoxes = new JCheckBox[Glove.NUM_LEDS];
    ledFields = new JTextField[Glove.NUM_LEDS];

    for (int i=0; i < Glove.NUM_LEDS; i++) {
      ledBoxes[i] = new JCheckBox(""+i);
      ledBoxes[i].setEnabled(false);
      ledFields[i] = new JTextField(10);
      ledFields[i].setEditable(false);
      ledFields[i].setBackground(Color.white);
      ledsPanel.add(ledBoxes[i]);
      ledsPanel.add(ledFields[i]);
    }

    // layout the panel.
    SpringUtilities.makeCompactGrid(ledsPanel,
                            Glove.NUM_LEDS, 2, // rows, cols
                            3, 3,        // init X, init Y
                            5, 5);       // x Padding, y adding
    return ledsPanel;
  } // end of makeLEDsPanel()



  // -------------------- poll and update GUI ---------------------

  private void startPolling()
  /* Set up a timer which is activated every GLOVE_DELAY ms
     and polls the glove and updates the GUI. 
     Safe since the action handler is executed in the 
     event-dispatching thread. */
  {
    ActionListener pollPerformer = new ActionListener() {
      public void actionPerformed(ActionEvent e) 
      {
	    glove.update();  // must call update() before showing 

        showHandInfo();
        showFingersInfo();
        showFramesInfo();
        showButtonsInfo();
        showLEDsInfo();
      }
    };

    pollTimer = new Timer(GLOVE_DELAY, pollPerformer);
    pollTimer.start();
  }  // end of startPolling()



  private void showHandInfo()
  // show the filtered (x,y,z) and (pitch,yaw,roll)
  { showVals(handInfo[0], glove.getFPos());
    showVals(handInfo[1], glove.getFOrient());
  }  // end of showHandInfo()


  private void showVals(JTextField tf, float vals[])
  { tf.setText( df.format(vals[0]) + ", " +
                df.format(vals[1]) + ", " +
                df.format(vals[2]) );  }


  private void showFingersInfo()
  // show the finger bend info
  {
    short[] fingerBends = glove.getFingers();
    for(int i=0; i < fingers.length; i++)
      fingers[i].setText( "" + fingerBends[i] );
  }  // end of showFingersInfo()


  private void showFramesInfo()
  {
    timeInfo[0].setText("" + glove.getFrameNo());  // frame no.

    float frameRate = glove.getFrameRate();
    timeInfo[1].setText( df.format(frameRate) );
  }  // end of showFramesInfo()


  private void showButtonsInfo()
  // show which buttons are pressed
  {
    boolean[] buttonPresses = glove.getButtons();
    for(int i=0; i < buttons.length; i++)
      buttons[i].setSelected( buttonPresses[i] );
  }  // end of showButtonsInfo()


  private void showLEDsInfo()
  // show which LEDs are visible, and their values
  {
    boolean[] visibleLEDs = glove.getLEDs();
    float[][] ledsPos = glove.getLEDsPos();

    for(int i=0; i < ledFields.length; i++) {
      ledBoxes[i].setSelected( visibleLEDs[i] );
      if(visibleLEDs[i])  // this LED is on
        showVals(ledFields[i], ledsPos[i]);
      else 
        ledFields[i].setText("");   // clear the field
    }
  }  // end of showLEDsInfo()



  // -------------------------------------------------------------

  public static void main (String[] args) 
  {  new ShowGlove();  }

}  // end of ShowGlove.java
