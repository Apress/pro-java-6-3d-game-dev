
// Glove.java
// Andrew Davison, December 2005, ad@fivedots.coe.psu.ac.th

/* This Glove class is a simple facade for Carl Kenner's CP5DLL class,
   which is part of his Dual Mode driver (Beta 3) for the
   P5 Virtual Reality Glove, version 5.0.12.8, December 2004. 

   The class and driver are available from Yahoo's P5 group,
   http://groups.yahoo.com/group/p5glove/, in the files section
   as A_DualModeDriverBeta3.zip

   This Glove class assumes there's only one glove, and offers 
   methods to get the glove's:
     * (x,y,z) position -- filtered and raw
     * (pitch,yaw,roll) -- filtered and raw
     * finger bend amounts
     * button presses
     * visible LEDs, and their values
     * current frame no., and frame rate

   The z-axis is reversed so that the positive direction is towards
   the user. 

   Call update() to update the values before calling the get() methods.

   This class switches off the glove's mouse mode until 
   close() is called. NOTE: on Windows XP/98, the mouse mode
   is not restored by calling P5_RestoreMouse() in close().
*/

import com.essentialreality.*;


public class Glove
{
  // public constants
  public final static int NUM_BUTTONS = 4;
  public final static int NUM_LEDS = 8;

  // links to the P5 glove(s)
  private CP5DLL gloves;
  private CP5DLL.P5State gloveState;  


  public Glove()
  {
    gloves = new CP5DLL();

    // initialize the glove
    if (!gloves.P5_Init()) {
      System.out.println("P5 Initialization failed");
      System.exit(1);
    }

    gloves.P5_SetForwardZ(-1);  // so positive Z is towards the user
    gloves.P5_SetMouseState(-1, false);  // disable mouse mode

    // make sure there's only one glove
    int numGloves = gloves.P5_GetCount();
    if (numGloves > 1) {
      System.out.println("Too many gloves detected: " + numGloves);
      System.exit(1);
    }

    printGloveInfo();
    gloveState = gloves.state[0];  // store a reference to the glove state
  } // end of Glove()


  private void printGloveInfo()
  {
    CP5DLL.P5Info gloveInfo = gloves.info[0];

    System.out.println(
        "Vendor ID: " + gloveInfo.vendorID + 
        "; Product ID: " + gloveInfo.productID + 
        "; Version: " + gloveInfo.version);

    System.out.println(
        "Product: " + gloveInfo.productString +
        "; Manufacturer: " + gloveInfo.manufacturerString +
        "; Serial No.: " + gloveInfo.serialNumString);

    System.out.println("Device ID: " + gloveInfo.deviceID);

    System.out.println(
        "Major Revision No.: " + gloveInfo.majorRevisionNumber +
        "; Minor Revision No.: " + gloveInfo.minorRevisionNumber);

    System.out.println("Glove Type: " + gloveInfo.gloveType);
  }  // end of printGloveInfo()


  // ---------------- accessing data ------------------
  // update the glove's state with update() before calling 
  // the get methods to obtain current values

  public void update()
  { gloveState.update(); }


  public float[] getPos()
  // raw (x,y,z) position
  { return new float[]{gloveState.x, gloveState.y, gloveState.z};  }

  public float[] getFPos()
  // filtered (x,y,z) position 
  { return new float[]{gloveState.filterPos[0], 
                       gloveState.filterPos[1], 
                       gloveState.filterPos[2]};  }

  public float[] getOrient()
  // raw (pitch,yaw,roll)
  { return new float[] {gloveState.pitch, 
                        gloveState.yaw, 
                        gloveState.roll};  }

  public float[] getFOrient()
  // filtered (pitch,yaw,roll)
  { return new float[] {gloveState.filterPitch, 
                        gloveState.filterYaw, 
                        gloveState.filterRoll};  }

  public short[] getFingers()
  // the bend values for the 5 fingers
  {  return gloveState.fingerAbsolute;  }

  public boolean[] getButtons()
  // which of the buttons are on/off
  {  return gloveState.button; }

  public boolean[] getLEDs()
  // which of the LEDs are visible
  {  return gloveState.ledVisible;  }

  public float[][] getLEDsPos()
  // 8*3 array -- 8 LEDs, with (x,y,z) for those that are visible
  {  return gloveState.ledPos; }

  public long getFrameNo()
  {  return gloveState.frame;  }

  public float getFrameRate()
  {  return gloveState.frameRate;  }


  public void close()
  { // gloves.P5_SetMouseState(0, true); 
    gloves.P5_RestoreMouse(-1);  // restore mouse mode (does not work)
    gloves.P5_Close();  
  }

} // end of Glove class
