
Chapter 15. Two JOGL Programming Frameworks

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew


==================================
CubeGL_AR

The rotating cube using the JOGL active rendering 
programming framework. 

Java files here:
  CubeGL.java, CubeCanvasGL.java


==================================
Requirements:

* J2SE 5.0 or later from http://java.sun.com/j2se/
  (I use its nanosecond timer, System.nanoTime(), in the CubeGL
   examples).
  I recommend the release version of Java SE 6.

* JOGL, the JSR-231 1.1.0 release candidate 2, from 
  https://jogl.dev.java.net/
  See the readme.txt file in the top-level directory for 
  details on installing it. 

-----
Compilation: 

Use the compileGL.bat batch file.

$ compileGL *.java

-----
Execution: 

Use the runGL.bat batch file, with the name of the program,
CubeGL, and an optional FPS value.

$ runGL CubeGL <FPS value>
e.g.
  $ runGL CubeGL 80
  $ runGL CubeGL 100
or
  $ runGL CubeGL
     // this uses a default FPS of 80

-----------
Last updated: 4th March 2007