
// PrintExtCanvas.java
// Andrew Davison, February 2006, ad@fivedots.coe.psu.ac.th

/* Print OpenGL info for this device, including the
   supported extensions into the extsInfo.txt file.

   The code uses active rendering.

   I borrowed some ideas from the SingleThreadedGlCanvas class by
   Markus_Persson, January 23, 2006
   http://www.javagaming.org/forums/index.php?topic=12094.15

   The time calculations use System.nanoTime(), so require J2SE 5.0.
*/

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.DecimalFormat;


import javax.media.opengl.*;
import javax.media.opengl.glu.*;
import com.sun.opengl.util.*;


public class PrintExtCanvas extends Canvas implements Runnable
{
  private static final String EXT_FNM = "extsInfo.txt";
  private static final int COL_WIDTH = 40;

  // OpenGL
  private GLDrawable drawable;
  private GLContext context;
  // private GL gl;

  private Thread animator = null;     // the thread that performs the animation



  public PrintExtCanvas(GraphicsConfiguration config, GLCapabilities caps)
  { 
    super(config);
    drawable = GLDrawableFactory.getFactory().getGLDrawable(this, caps, null);
    context = drawable.createContext(null);
  } // end of PrintExtCanvas()



  public void addNotify()
  // wait for the canvas to be added to the JPanel before starting
  { 
    super.addNotify();      // creates the peer
    drawable.setRealized(true);   // the canvas can now be rendering into

    // initialise and start the animation thread 
    if (animator == null) { 
      animator = new Thread(this);
	  animator.start();
    }
  } // end of addNotify()


  public void update(Graphics g) { }

  public void paint(Graphics g) { }


  public void run()
  {
    // make the rendering context current for this thread
    try {
      while (context.makeCurrent() == GLContext.CONTEXT_NOT_CURRENT) {
        System.out.println("Context not yet current...");
        Thread.sleep(100);
      }
    }
    catch (InterruptedException e)
    { e.printStackTrace(); }

    GL gl = context.getGL();
    printDetails(gl);

    context.release();
    context.destroy();
    System.exit(0);
  } // end of run()


  private void printDetails(GL gl)
  // report OpenGL details
  {

    File f = new File(EXT_FNM);
    PrintWriter pw = null;
    try {
      pw = new PrintWriter(new FileWriter(f), true);

      pw.println("GL vendor: " + gl.glGetString(GL.GL_VENDOR));
      pw.println("GL version: " + gl.glGetString(GL.GL_VERSION));
      pw.println("GL renderer: " + gl.glGetString(GL.GL_RENDERER));

      pw.println("GL extensions:");
      String[] extensions = gl.glGetString(GL.GL_EXTENSIONS).split(" ");
      printColumns(extensions, pw);
      pw.close();

      System.out.println("Exts written to file " + EXT_FNM);
    }
    catch(Exception e)
    {  System.out.println("Could not write to file " + EXT_FNM);  }

  }  // end of printDetails()


  private void printColumns(String exts[], PrintWriter pw)
  // two-column output of extensions
  {
    int i = 0;
    while (i < exts.length) {
      pw.print("  ");
      String ext = exts[i++];
      pw.print(ext);    // print first ext
      if (i < exts.length) {
        for (int j = 0; j < (COL_WIDTH - ext.length()); j++)
          pw.print(" ");    // move over to COL_WIDTH pos
        pw.println( exts[i++] );  // print secopnd ext
      } 
      else
        pw.println();
    }
  }  // end of printColumns()

} // end of PrintExtCanvas class

