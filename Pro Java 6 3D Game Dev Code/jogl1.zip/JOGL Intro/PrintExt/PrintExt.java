
// PrintExt.java
// Andrew Davison, February 2006, ad@fivedots.coe.psu.ac.th

/* Print OpenGL info for this device, including the
   supported extensions into the extsInfo.txt file.

   Based on PrintExt.java in the JOGL-231 examples.
   Copyright (C) 2003 Sun Microsystems, Inc.
*/


import javax.swing.*;
import java.awt.*;
import java.awt.event.*; 

import javax.media.opengl.*;
import com.sun.opengl.util.*;


public class PrintExt extends JFrame
{
  public PrintExt()
  {
    super("Print Extensions");

    Container c = getContentPane();
    c.setLayout( new BorderLayout() );
    c.add(makeCanvas(), BorderLayout.CENTER);

    setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

    // make the frame as invisible as possible
    setUndecorated(true);
    setSize(1,1);
    setVisible(true);   // required so that the canvas gets notified
  } // end of PrintExt()


  private PrintExtCanvas makeCanvas()
  {
    // get a configuration suitable for an AWT Canvas (for CubeCanvasGL)
    GLCapabilities caps = new GLCapabilities();

    AWTGraphicsDevice dev = new AWTGraphicsDevice(null);
    AWTGraphicsConfiguration awtConfig = (AWTGraphicsConfiguration)
       GLDrawableFactory.getFactory().chooseGraphicsConfiguration(caps, null, dev);

    GraphicsConfiguration config = null;
    if (awtConfig != null)
      config = awtConfig.getGraphicsConfiguration();

    return new PrintExtCanvas(config, caps);
  }  // end of makeCanvas()


  // ------------------------------------

  public static void main(String[] args)
  {  new PrintExt();  }


}  // end of PrintExt class
