
Chapter 15. Two JOGL Programming Frameworks

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2


Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

=============================================
Contents of this Directory

* PrintExt/
    - a very simple example taken from the JOGL Demos at
      https://jogl.dev.java.net/
    - use this to test your JOGL installation

* CubeGL_CB/
    - the rotating cube example implemented using callbacks 

* CubeGL_AR/
    - the rotating cube example implemented using active rendering 

=============================================

JOGL Installation

* I downloaded JSR-231 1.1.0 release candidate 2 of JOGL 
  from https://jogl.dev.java.net. I chose the Windows build from 
  January 23rd, jogl-1.1.0-rc2-windows-i586.zip, which contains a lib\ 
  subdirectory holding two JARS (jogl.jar and gluegen-rt.jar) and 
  four DLLs (jogl.dll, gluegen-rt.dll, jogl_awt.dll, and jogl_cg.dll).

* I extracted the lib\ directory, renamed it to jogl\, and stored it 
  on my test machine's d: drive (i.e. as d:\jogl\).

* Use the two batch files, compileGL.bat and runGL.bat, in this
  directory to compile and run JOGL programs. They assume that the JAR 
  and DLLs are in d:\jogl. 

* I've placed copies of the batch files in each of the example 
  directories for convenience.

=============================================

JOGL Installation

After installing JOGL, test it using the PrintExt example
in the subdirectory PrintExt/.

---------
Last updated: 4th March 2007