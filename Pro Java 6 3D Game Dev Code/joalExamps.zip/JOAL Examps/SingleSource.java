
// SingleSource.java
// Andrew Davison, October 2006, ad@fivedots.coe.psu.ac.th

// The GUI allows the user to play, stop, or pause a looping sound.


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class SingleSource extends JFrame
                        implements ActionListener
{
  private JOALSoundMan soundMan; 
  private String soundName;

  private JButton playButton, stopButton, pauseButton;


  public SingleSource(String nm)
  {
    super("Single Static Source");

    soundMan = new JOALSoundMan();
    soundName = nm;

    if (!soundMan.load(soundName, true))
      System.exit(1);

    buildGUI();

    addWindowListener( new WindowAdapter() {
      public void windowClosing(WindowEvent e)
      { soundMan.cleanUp(); 
        System.exit(0);
      }
    });

    pack();
    setResizable(false);    // fixed size display
    setVisible(true);
  }  // end of SingleSource()




  private void buildGUI()
  // three buttons for play, stop, and pause
  {
    Container c = getContentPane();
    c.setLayout(new GridLayout(3, 1));

    playButton = new JButton("Play " + soundName);
    playButton.addActionListener(this);
    c.add(playButton);

    stopButton = new JButton("Stop");
    stopButton.addActionListener(this);
    c.add(stopButton);

    pauseButton = new JButton("Pause");
    pauseButton.addActionListener(this);
    c.add(pauseButton);
  }  // end of buildGUI()



  public void actionPerformed(ActionEvent e)
  {
    if (e.getSource() == playButton)
      soundMan.play(soundName);
    else if (e.getSource() == stopButton)
      soundMan.stop(soundName);
    else if (e.getSource() == pauseButton)
      soundMan.pause(soundName);
  }  // end of actionPerformed


  // ---------------------------------------------------


  public static void main(String[] args)
  {  
    if (args.length != 1)
      System.out.println("Usage: runJOAL SingleSource <WAV name>");
    else
      new SingleSource(args[0]);  
  } // end of main()

} // end of SingleSource class
