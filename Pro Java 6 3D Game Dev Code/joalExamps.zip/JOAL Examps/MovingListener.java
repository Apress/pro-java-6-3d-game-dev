
// MovingListener.java
// Andrew Davison, October 2006, ad@fivedots.coe.psu.ac.th

/* Repeated play a sound, and gradually move the listener away from
   it along the +z axis, so the sound fades away. */


public class MovingListener
{
  public static void main(String[] args)
  {  
    if (args.length != 1) {
      System.out.println("Usage: runJOAL MovingListener <WAV name>");
      System.exit(1);
    }
    String soundName = args[0];

    JOALSoundMan soundMan = new JOALSoundMan();
    // the listener is at (0,0,0) facing along the -z axis

    if (!soundMan.load(soundName, true))
      System.exit(1);
    // default position for sound is (0,0,0)
    soundMan.play(soundName);
    
    // move the listener along the z axis 
    for(int i=0; i < 50; i++) {
      soundMan.moveListener(0, 0.1f);
      try {
        Thread.sleep(250);   // sleep for 0.25 secs
      }
      catch(InterruptedException ex) {}
    }

    soundMan.cleanUp();
  }  // end of main()


} // end of MovingListener class
