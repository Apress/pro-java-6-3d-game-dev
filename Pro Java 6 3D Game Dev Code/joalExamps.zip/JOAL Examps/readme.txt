
Chapter 13. 3D Sound with JOAL

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

=============================================
Contents of this Directory

* runJOAL.bat
   - a batch file for running the examples

* 6 Java files:
     - JOALSoundMan.java     // the JOAL sound manager
     - 5 examples that use JOALSoundMan
          MovingSource.java, MovingListener.java,
          MovingListener2.java, TurningListener.java
          SingleSource.java

* Sounds/
    cow.wav, FancyPants.wav, FancyPantsS.wav, ocean.wav


=============================================
Software You Need

* The JOAL API for Windows, available from 
  https://joal.dev.java.net/. Please read section 2.2. of
  the chapter for details on how to install them.
  
=============================================
Compilation: 

$ java *.java
    // make sure you have JOAL installed

=============================================
Execution: 

Use the runJOAL.bat batch file.

Make sure you have JOAL installed.

runJOAL.bat assumes the JOAL DLLs are located
in d:\joal. Change the batch file to match where you've
placed the files.

Examples:

> runJOAL MovingSource FancyPants

> runJOAL MovingListener FancyPants    

> runJOAL MovingListener2

> runJOAL TurningListener FancyPants

> runJOAL SingleSource FancyPants

---------
Last updated: 4th March 2007