
// MovingSource.java
// Andrew Davison, October 2006, ad@fivedots.coe.psu.ac.th

/* Repeated play a sound, and gradually move it away from
   the listener along the -z axis so it fades away. */



public class MovingSource
{
  public static void main(String[] args)
  {  
    if (args.length != 1) {
      System.out.println("Usage: runJOAL MovingSource <WAV name>");
      System.exit(1);
    }
    String soundName = args[0];

    JOALSoundMan soundMan = new JOALSoundMan();
    // the listener is at (0,0,0) facing along the -z axis

    if (!soundMan.load(soundName, true))
      System.exit(1);

    // default position for sound is (0,0,0)
    soundMan.play(soundName); 
    
    // move the sound along the -z axis 
    float step = 0.1f;
    float zPos = 0.0f;
    for(int i=0; i < 50; i++) {
      zPos -= step;
      soundMan.setPos(soundName, 0, 0, zPos);
      try {
        Thread.sleep(250);   // sleep for 0.25 secs
      }
      catch(InterruptedException ex) {}
    }

    // soundMan.stop(soundName);
    soundMan.cleanUp();
  }  // end of main()


} // end of MovingSource class
