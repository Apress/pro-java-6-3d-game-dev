
// MovingListener2.java
// Andrew Davison, October 2006, ad@fivedots.coe.psu.ac.th

/* Repeated play two sound, and gradually move the listener away from
   one sound (the cow) towards the other (ocean). */


public class MovingListener2
{
  public static void main(String[] args)
  {  
    JOALSoundMan soundMan = new JOALSoundMan();

    float xPos = 10.0f;

    soundMan.moveListener(xPos, 0);
    // the listener is at (xPos,0,0) facing along the -z axis

    // cow at (xPos,0,0)
    if (!soundMan.load("cow", xPos,0,0, true))
      System.exit(1);
    soundMan.play("cow");

    // ocean at (-xPos,0,0)
    if (!soundMan.load("ocean", -xPos,0,0, true))
      System.exit(1);
    soundMan.play("ocean");

    
    // move the listener from cow to ocean
    float xStep = (2.0f * xPos)/40.0f;
    for(int i=0; i < 40; i++) {
      soundMan.moveListener(-xStep, 0);
      try {
        Thread.sleep(250);   // sleep for 0.25 secs
      }
      catch(InterruptedException ex) {}
    }

    soundMan.cleanUp();
  }  // end of main()


} // end of MovingListener2 class
