
// TurningListener.java
// Andrew Davison, October 2006, ad@fivedots.coe.psu.ac.th

/* The sound will start in the right speaker, then the listener
   turnd anticlockwise making the sound move to the left speaker, 
   and finally back to the right speaker. */


public class TurningListener
{
  public static void main(String[] args)
  {  
    if (args.length != 1) {
      System.out.println("Usage: runJOAL TurningListener <WAV name>");
      System.exit(1);
    }
    String soundName = args[0];

    JOALSoundMan soundMan = new JOALSoundMan();
    // the listener is at (0,0,0) facing along the -z axis
    soundMan.moveListener(1,0);   // now at (1,0,0) 

    if (!soundMan.load(soundName, 2,0,0, true))    // at (2,0,0)
      System.exit(1);
    soundMan.play(soundName);
    
    // rotate listener anti-clockwise
    for(int i=0; i < 60; i++) { 
      soundMan.turnListener(6);  // 6 degrees each time
      try {
        Thread.sleep(250);   // sleep for 0.25 secs
      }
      catch(InterruptedException ex) {}
    }

    soundMan.cleanUp();
  }  // end of main()


} // end of TurningListener class
