
// Planets3D.java
// Andrew Davison, January 2006, ad@fivedots.coe.psu.ac.th

/* Display the earth, moon, and mars against a static background
   of stars drawn using a subclass of Canvas3D. 
   OrbitBehavior allows the user to navigate.

   The images are stores in the image/ subdirectory.

   Usage examples:
      java Planets3D stars.jpg
      java Planets3D galaxy.jpg
      java Planets3D sun.gif

   Move through the scene using OrbitBehavior mouse and control keys.
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Planets3D extends JFrame
{
  public Planets3D(String backFnm) 
  {
    super("Planets3D");
    Container c = getContentPane();
    c.setLayout( new BorderLayout() );
    WrapPlanets3D w3d = new WrapPlanets3D(backFnm); // panel holding the 3D canvas
    c.add(w3d, BorderLayout.CENTER);

    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pack();
    setResizable(false);    // fixed size display
    setVisible(true);
  } // end of Planets3D()


// -----------------------------------------

  public static void main(String[] args)
  {  
    if (args.length != 1)
      System.out.println("Usage: java Planets3D <fnm from images/>");
    else
      new Planets3D(args[0]);  
  }  // end of main()

} // end of Planets3D class
