
// BGCanvas3D.java
// Andrew Davison, January 2006, ad@fivedots.coe.psu.ac.th

/* A subclass of Canvas3D so that a static 2D background image can
   be included when the 3D canvas is rendered.
*/

import java.awt.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;

import javax.media.j3d.*;


public class BGCanvas3D extends Canvas3D
{
  private BufferedImage backIm;    // the background image
  private J3DGraphics2D render2D;  // for 2D rendering into the 3D canvas


  public BGCanvas3D(GraphicsConfiguration gc, String backFnm)
  { super(gc);
    backIm = loadImage(backFnm);
    render2D = this.getGraphics2D();
  } // end of BGCanvas3D()   


  private BufferedImage loadImage(String fnm)
  // load the BufferedImage in images/<fnm>
  {
    BufferedImage im = null;
    try {
      im = ImageIO.read( getClass().getResource("images/" + fnm));
      System.out.println("Loaded Background: images/" + fnm);
    }
    catch(Exception e)
    { System.out.println("Could not load background: images/" + fnm); }

    return im;
  }  // end of loadImage()


  public void preRender()
  /* Add the background image to the frame before any 3D rendering
     is carried out. */
  {  render2D.drawAndFlushImage(backIm, 0, 0, this);  } 

} // end of BGCanvas3D class
