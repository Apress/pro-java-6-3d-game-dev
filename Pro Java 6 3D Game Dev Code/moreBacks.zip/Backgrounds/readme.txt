
Chapter 8. More Backgrounds and Overlays

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew


============================
There are three examples here, in three directories:

* Planets3D/
     creates a scene made of three planets with a static 
     background;

* SpinPlanets3D/
     the same scene as Planets3D but the background rotates;

* ObjView3D/
     a version of the model viewer from Chapter N7, but with 
     a moveable background and overlays at the front.

They all use Java and Java 3D.
Java: http://java.sun.com/javase/
Java 3D: https://java3d.dev.java.net/

---------
Last updated: 4th March 2007

