
// ShiftBGCanvas3D.java
// Andrew Davison, September 2006, ad@fivedots.coe.psu.ac.th

/* This subclass of Canvas3D overrides its preRender() and postRender()
   methods.

   The preRender() method draws a background which is shifted left or
   right as the camera position in FPShooter3D turns/rotates right or
   left. This requires the background image (backIm) to possibly be drawn
   twice into drawIm before being rendered.

   postRender() also uses drawIm to render a "Moves: <no>" text message
   and a translucent image (titleIm) in the foreground.

   The reuse of drawIm for rendering to the background and foreground
   requires it to be cleared with clearSurface() between each use.
*/

import java.awt.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import javax.media.j3d.*;


public class ShiftBGCanvas3D extends Canvas3D
{
  private static final String BACK_IM = "night.gif";
        /* from http://www.photon.at/~werner/light/night.html */
        /* The code assumes that the width of this background image is
           greater than half the width of the panel. */

  private static final String TITLE_IM = "title.png";

  private BufferedImage drawIm, backIm, titleIm;
  private Graphics2D drawg2d;   // for drawing into drawIm
  private J3DGraphics2D render2D;    // for 2D rendering into the 3D canvas

  private int panelWidth, panelHeight;  // size of drawing area
  private int imWidth;        // width of background image
  private int xc = 0;  // current x-axis position for drawing the BG image

  // for displaying messages
  private Font msgsFont;
  private int moveNum = 0;



  public ShiftBGCanvas3D(GraphicsConfiguration gc, int pWidth, int pHeight)
  {
    super(gc);
    panelWidth = pWidth;
    panelHeight = pHeight;
    // System.out.println("Canvas width: " + getWidth());
    
    /* create a drawing image with support for an alpha channel,
       and a graphic context fro drawing into it */
    drawIm = new BufferedImage(panelWidth, panelHeight, 
                                 BufferedImage.TYPE_4BYTE_ABGR);
    drawg2d = drawIm.createGraphics();

    render2D = this.getGraphics2D();

    backIm = loadImage(BACK_IM);   // load background image
    if (backIm != null) {
      imWidth = backIm.getWidth();
      if (imWidth < panelWidth)
        System.out.println("WARNING: background image is too narrow");
    }

    titleIm = loadImage(TITLE_IM);   // load title image

    // create message font
    msgsFont = new Font("SansSerif", Font.BOLD, 24);
  } // end of ShiftBGCanvas3D()   


  private BufferedImage loadImage(String fnm)
  // load the BufferedImage in images/<fnm>
  {
    BufferedImage im = null;
    try {
      im = ImageIO.read( getClass().getResource("images/" + fnm) );
      System.out.println("Loaded Background: images/" + fnm);
    }
    catch(IOException e)
    { System.out.println("Could not load Background: images/" + fnm);  }

    return im;
  }  // end of loadImage()


  public void preRender()
  // draw the background
  {
    if (backIm == null)   // no BG image to draw
      return;

    clearSurface();

    // adjust x coord to be within the bounds of the image width
    if (xc >= imWidth)
      xc -= imWidth;
    else if (xc <= -imWidth)
      xc += imWidth;

    if (xc > 0) {    // background starts on the right
      drawg2d.drawImage(backIm, xc-imWidth, 0, null);   // draw lhs
      if (xc < panelWidth)      // start of BG is on-screen
        drawg2d.drawImage(backIm, xc, 0, null);   // draw rhs
    }
    else {  // xc <= 0, background starts on the left
      drawg2d.drawImage(backIm, xc, 0, null);   // draw lhs
      int endBG = xc + imWidth;
      if (endBG < panelWidth)   // end of BG is on-screen
        drawg2d.drawImage(backIm, endBG, 0, null);   // draw rhs
    }

    render2D.drawAndFlushImage(drawIm, 0, 0, this);
  }  // end of preRender()


  private void clearSurface()
  /* Clear the drawing surface (drawIm) via its graphics context
     Based on mokopa's code in
        http://www.javagaming.org/forums/index.php?topic=7320.0
  */
  { drawg2d.setComposite(AlphaComposite.getInstance(AlphaComposite.CLEAR, 0.0f));
    drawg2d.fillRect(0,0, panelWidth, panelHeight);
    drawg2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f));
    drawg2d.setColor(Color.BLACK);
  }  // end of clearSurface()



  public void postRender()
  // draw the text message and the title image in the foreground
  {
    clearSurface();

    // draw the title image, with hardwired positioning
    drawg2d.drawImage(titleIm, panelWidth-195, panelHeight-60, null);

    // draw the firing info.
    drawg2d.setFont(msgsFont);
    drawg2d.setColor(Color.red);
    drawg2d.drawString("Moves: " + moveNum, 10, panelHeight-10);

    render2D.drawAndFlushImage(drawIm, 0, 0, this);
  }  // end of postRender()


  // -------- called from KeyBehavior ----------------

  public void shiftLeft(int amt)
  // shift the background left by amt
  {  xc -= amt;  
     moveNum++;
  }

  public void shiftRight(int amt)
  // shift the background right by amt
  {  xc += amt;
     moveNum++;
  }

} // end of ShiftBGCanvas3D class
