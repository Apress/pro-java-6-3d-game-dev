
// WrapObjView3D.java
// Andrew Davison, September 2006, ad@fivedots.coe.psu.ac.th

/* The world consists of a checkboard floor, 
   with a red center square, and labelled XZ axes,
   created by CheckerFloor with the help of the ColouredTiles
   class.

   The floor is populated with models and ground shapes. The
   models are loaded by the ModelLoader class, the ground shapes
   by GroundShape.

   The user moves over the floor using key commands processed by
   KeyBehavior.

   The lighting, background, and initial user positioning are done 
   in this class. 

   This version of the FPS uses ShiftBGCanvas3D which supports 
   a shifting background (triggered by camera movement), and 
   text and translucent image overlays in the foreground.

   ShiftBGCanvas3D is also referenced by KeyBehavior which causes
   the background to shift and updates the text message.
*/


import javax.swing.*;
import java.awt.*;

import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.image.*;
import javax.media.j3d.*;
import javax.vecmath.*;



public class WrapObjView3D extends JPanel
// Holds the 3D canvas where the loaded image is displayed
{
  private static final int PWIDTH = 512;   // size of panel
  private static final int PHEIGHT = 512; 

  private static final int BOUNDSIZE = 100;  // larger than world

  // info used to position initial viewpoint
  private final static double Z_START = 9.0;


  private SimpleUniverse su;
  private BranchGroup sceneBG;
  private BoundingSphere bounds;   // for environment nodes
  private ShiftBGCanvas3D canvas3D;


  public WrapObjView3D()
  // A panel holding a 3D canvas
  {
    setLayout( new BorderLayout() );
    setOpaque( false );
    setPreferredSize( new Dimension(PWIDTH, PHEIGHT));

    GraphicsConfiguration config =
					SimpleUniverse.getPreferredConfiguration();
    canvas3D = new ShiftBGCanvas3D(config, PWIDTH, PHEIGHT);
    // Canvas3D canvas3D = new Canvas3D(config);
    add("Center", canvas3D);
    canvas3D.setFocusable(true);     // give focus to the canvas 
    canvas3D.requestFocus();

    su = new SimpleUniverse(canvas3D);

    // depth-sort transparent objects on a per-geometry basis
    View view = su.getViewer().getView();
    view.setTransparencySortingPolicy(View.TRANSPARENCY_SORT_GEOMETRY);

    createSceneGraph();
    createUserControls();
    
    su.addBranchGraph( sceneBG );
  } // end of WrapObjView3D()



  private void createSceneGraph()
  // initilise the scene
  { 
    sceneBG = new BranchGroup();
    bounds = new BoundingSphere(new Point3d(0,0,0), BOUNDSIZE);  

    lightScene();         // add the lights

    addBackground(); 

    sceneBG.addChild( new CheckerFloor().getBG() );  // add the floor
    addModels();
    addGroundCover();

    sceneBG.compile();   // fix the scene
  } // end of createSceneGraph()


  private void lightScene()
  /* One ambient light, 2 directional lights */
  {
    Color3f white = new Color3f(1.0f, 1.0f, 1.0f);

    // Set up the ambient light
    AmbientLight ambientLightNode = new AmbientLight(white);
    ambientLightNode.setInfluencingBounds(bounds);
    sceneBG.addChild(ambientLightNode);

    // Set up the directional lights
    Vector3f light1Direction  = new Vector3f(-1.0f, -1.0f, -1.0f);
       // left, down, backwards 
    Vector3f light2Direction  = new Vector3f(1.0f, -1.0f, 1.0f);
       // right, down, forwards

    DirectionalLight light1 = 
            new DirectionalLight(white, light1Direction);
    light1.setInfluencingBounds(bounds);
    sceneBG.addChild(light1);

    DirectionalLight light2 = 
        new DirectionalLight(white, light2Direction);
    light2.setInfluencingBounds(bounds);
    sceneBG.addChild(light2);
  }  // end of lightScene()



  private void addModels()
  /* The ModelLoader getModel() method expects a OBJ filename, for
     files in the Models/ subdirectory, and an optional y-axis 
     translation. The method returns a TransformGroup which can
     be used with other TGs to further position, rotate, or scale
     the model.
  */
  {
    ModelLoader ml = new ModelLoader();
    Transform3D t3d = new Transform3D();

    t3d.setIdentity();   // resets t3d  (just to be safe)
    t3d.setTranslation( new Vector3d(0,0,-7));   // move
    t3d.setScale(2.5);   // enlarge
    t3d.setRotation( new AxisAngle4d(0,1,0, Math.toRadians(90)) ); 
              // rotate 90 degrees anticlockwise around y-axis
    TransformGroup tg1 = new TransformGroup(t3d);
    tg1.addChild( ml.getModel("humanoid.obj", 0.8) );
    sceneBG.addChild(tg1);

  }  // end of addModels()


  private void addGroundCover()
  /* GroundShape expects a GIF filename, located in the images/
     subdirectory and a scale factor. The resulting shape is
     located at (0,0) on the (x, z) plain, and can be adjusted
     with an additional TG.
  */
  {
    Transform3D t3d = new Transform3D();

    t3d.set( new Vector3d(4,0,0)); 
    TransformGroup tg1 = new TransformGroup(t3d);
    tg1.addChild( new GroundShape("tree1.gif", 3) );
    sceneBG.addChild(tg1);

    t3d.set( new Vector3d(-3,0,0));
    TransformGroup tg2 = new TransformGroup(t3d);
    tg2.addChild( new GroundShape("tree2.gif", 2) );
    sceneBG.addChild(tg2);

    t3d.set( new Vector3d(2,0,-6));
    TransformGroup tg3 = new TransformGroup(t3d);
    tg3.addChild( new GroundShape("tree4.gif", 3) );
    sceneBG.addChild(tg3);

    t3d.set( new Vector3d(-1,0,-4));
    TransformGroup tg4 = new TransformGroup(t3d);
    tg4.addChild( new GroundShape("cactus.gif") );
    sceneBG.addChild(tg4);
  }  // end of addGroundCover()



  private void createUserControls()
  /*  Attach the keyboard behavior for moving around the scene,
      and set the initial viewpoint.
  */
  { 
    ViewingPlatform vp = su.getViewingPlatform();

    // position viewpoint
    TransformGroup targetTG = vp.getViewPlatformTransform();
    Transform3D t3d = new Transform3D();
    targetTG.getTransform(t3d);
    t3d.setTranslation( new Vector3d(0,1,Z_START));
    targetTG.setTransform(t3d);

    // set up keyboard controls to move the viewpoint
    KeyBehavior keyBeh = new KeyBehavior(canvas3D);
         // keyBeh can adjust the canvas background image
    keyBeh.setSchedulingBounds(bounds);
    vp.setViewPlatformBehavior(keyBeh);
  } // end of createUserControls()


  // ------------------ background method -------------------------


  private void addBackground()
  // the deep blue sea
  { Background back = new Background();
    back.setApplicationBounds( bounds );
    back.setColor(0, 0, 0.639f);    // dark blue
    sceneBG.addChild( back );
  } // end of addBackground()

/*
  private Texture2D loadTexture(String fn)
  // load image from file fn as a texture
  {
    TextureLoader texLoader = new TextureLoader(fn, null);
    Texture2D texture = (Texture2D) texLoader.getTexture();
    if (texture == null)
      System.out.println("Cannot load texture from " + fn);
    else {
      System.out.println("Loaded texture from " + fn);
      texture.setEnable(true);
    }
    return texture;
  }  // end of loadTexture()
*/


} // end of WrapObjView3D class