
// ImageRotator.java
// Andrew Davison, January 2006, ad@fivedots.coe.psu.ac.th

/* Every DELAY ms, rotate the image stored in backIm, and 
   pass the new image over to SpinBGCanvas3D to be rendered
   as the background of the canvas.

   The image is rotated by an additional ROT_AMT degrees 
   in each update.

   The looping is terminated when isRunning is set to be false
   by stopRotating()
*/

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;


public class ImageRotator extends Thread
{
  private static final int DELAY = 200;    // ms (update interval)
  private static final int ROT_AMT =  2;   // rotation, in degrees

  private SpinBGCanvas3D canvas3D;
  private boolean isRunning;
  private BufferedImage backIm;
  private GraphicsConfiguration gc;
  private int currAngle;


  public ImageRotator(String backFnm, SpinBGCanvas3D c3d)
  { 
    canvas3D = c3d;

    backIm = loadBGImage(backFnm);
    canvas3D.updateBG(backIm);  // initally use the unrotated image as the background
    currAngle = ROT_AMT;

    // get GraphicsConfiguration so images can be copied easily and efficiently
    GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
    gc = ge.getDefaultScreenDevice().getDefaultConfiguration();
  } // end of ImageRotator()


  private BufferedImage loadBGImage(String fnm)
  // load the BufferedImage in images/<fnm>
  {
    BufferedImage im = null;
    try {
      im = ImageIO.read( getClass().getResource("images/" + fnm));
      System.out.println("Loaded Background: images/" + fnm);
    }
    catch(Exception e)
    { System.out.println("Could not load background: images/" + fnm); }

    return im;
  }  // end of loadBGImage()




  public void run()
  /*  In each iteration, rotate the basic image (backIm) by currAngle,
      and pass the result over to the canvas to become the new
      background.
  */
  {
    isRunning = true;
    BufferedImage rotIm;

    while(isRunning) {
      rotIm = getRotatedImage(backIm, currAngle);
      canvas3D.updateBG(rotIm);

      currAngle += ROT_AMT;
      if (currAngle > 360)   // reset after one complete rotation
        currAngle -= 360;

      try {
        Thread.sleep(DELAY);      // wait a while
      } 
      catch (Exception ex) {}
    }
  } // end of run()


  public void stopRotating()
  /* Stop the iteration; called by WrapSpinPlanets3D */
  {  isRunning = false; }


  private BufferedImage getRotatedImage(BufferedImage src, int angle) 
  /* Create a new BufferedImage which is the input image, rotated 
     angle degrees clockwise.

     An issue is edge clipping. The simplest solution is to design the
     image with plenty of (transparent) border.

     Explained in chapter 6.
  */
  { 
    if (src == null)
      return null;

    int transparency = src.getColorModel().getTransparency();
    BufferedImage dest =  gc.createCompatibleImage(
                              src.getWidth(), src.getHeight(), transparency);
    Graphics2D g2d = dest.createGraphics();

    AffineTransform origAT = g2d.getTransform(); // save original transform
  
    // rotate the coord. system of the dest. image around its center
    AffineTransform rot = new AffineTransform(); 
    rot.rotate( Math.toRadians(angle), src.getWidth()/2, src.getHeight()/2); 
    g2d.transform(rot); 

    g2d.drawImage(src, 0, 0, null);   // copy in the image

    g2d.setTransform(origAT);    // restore original transform
    g2d.dispose();

    return dest; 
  } // end of getRotatedImage()

} // end of ImageRotator class
