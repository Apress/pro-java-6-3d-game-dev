
Chapter 8. More Backgrounds and Overlays

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew


============================
SpinPlanets3D.java

-----
Compilation: 

$ javac *.java
    // you must have Java 3D installed for the compilation to succeed;

Java 3D is available from http://java.sun.com/products/java-media/3D/

-----
Execution: 

Call SpinPlanets3D with a background image, which is assumed to be stored
in the images/ subdirectory. The larger the image, the more sluggish
the application.

$ java SpinPlanets3D whirlpool.jpg    
          // large image; slows the application

$ java SpinPlanets3D tarantuala.jpg      
          // large image; slows the application

$ java SpinPlanets3D galaxy.jpg    
          // medium-size image; application speed is ok  

$ java SpinPlanets3D sun.gif
          // small image; no effect on application speed

Move through the scene using OrbitBehavior mouse and control keys.

---------
Last updated: 4th March 2007

