
// SpinBGCanvas3D.java
// Andrew Davison, January 2006, ad@fivedots.coe.psu.ac.th

/* A subclass of Canvas3D so that a rotating 2D background image can
   be included when the 3D canvas is rendered.
*/

import java.awt.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import javax.media.j3d.*;


public class SpinBGCanvas3D extends Canvas3D
{
  private BufferedImage backIm = null;   // the background image
  private J3DGraphics2D render2D;       // for 2D rendering into the 3D canvas

  private int panelWidth, panelHeight;  // of drawing area


  public SpinBGCanvas3D(GraphicsConfiguration gc, int pWidth, int pHeight)
  {
    super(gc);
    panelWidth = pWidth;
    panelHeight = pHeight;
    render2D = this.getGraphics2D();
  } // end of SpinBGCanvas3D()   


  public void updateBG(BufferedImage im)
  /* Update the background image, and draw it into the canvas.
     Called by ImageRotator. */
  {  setBGImage(im);
     drawBackground();
  } // end of updateBG()


  private synchronized void setBGImage(BufferedImage im)
  /* The change to the background image is synchronized so
     that it cannot be read by drawBackground() while it is
     being changed. */
  {  backIm = im;  }


  public void preRender()
  {  drawBackground();  }


  private synchronized void drawBackground()
  /* Draw the background image, centered in the panel.
     drawBackground() is synchronized since it may be called by
     the Java 3D render and ImageRotator at the same time. Also,
     it should be synchronized with setBGImage(). so the image isn't
     rendered as it's being changed.
  */
  {
    if (backIm == null)   // no image to draw
      return;

    int xc = (panelWidth - backIm.getWidth())/2;
    int yc = (panelHeight - backIm.getHeight())/2;
    render2D.drawAndFlushImage(backIm, xc, yc, this);
  }  // end of drawBackground()


} // end of SpinBGCanvas3D class
