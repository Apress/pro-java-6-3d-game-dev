
// WrapSpinPlanets3D.java
// Andrew Davison, January 2006, ad@fivedots.coe.psu.ac.th

/* The scene contains three spheres representing the 
   earth, moon, and mars, and a single directional light 
   and ambient light.

   The spheres are textured and lit, and are created via calls
   to addPlanet().

   The background is gradually rotating around the center of the panel.
   The image rotation is managed by an ImageRotator instance. The 
   background is drawn by SpinBGCanvas3D, a subclass of Canvas3D.
   The rotation is terminated by SpinPlanets3D calling stopBackground().

   OrbitBehavior allows the user to navigate. The camera starts
   at position USERPOSN, facing along the -z axis.

   ----
   This class is the same as WrapPlanets3D in the Planets3D
   example, except for the rotating background.
*/

import javax.swing.*;
import java.awt.*;

import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.image.*;
import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.behaviors.vp.*;



public class WrapSpinPlanets3D extends JPanel
// Holds the 3D canvas where the loaded image is displayed
{
  private static final int PWIDTH = 512;   // size of panel
  private static final int PHEIGHT = 512; 

  private static final int BOUNDSIZE = 100;  // larger than world

  private static final Point3d USERPOSN = new Point3d(0,5,30);
    // initial user position

  // colours
  private static final Color3f BLACK = new Color3f(0.0f, 0.0f, 0.0f);
  private static final Color3f GRAY = new Color3f(0.6f, 0.6f, 0.6f);
  private static final Color3f WHITE = new Color3f(0.9f, 0.9f, 0.9f);


  private SimpleUniverse su;
  private BranchGroup sceneBG;
  private BoundingSphere bounds;   // for environment nodes

  private ImageRotator imRotator; // for rotating the background image



  public WrapSpinPlanets3D(String backFnm)
  // A panel holding a 3D canvas: the usual way of linking Java 3D to Swing
  {
    setLayout( new BorderLayout() );
    setOpaque( false );
    setPreferredSize( new Dimension(PWIDTH, PHEIGHT));

    GraphicsConfiguration config =
					SimpleUniverse.getPreferredConfiguration();
    SpinBGCanvas3D canvas3D = new SpinBGCanvas3D(config, PWIDTH, PHEIGHT);
    add("Center", canvas3D);
    canvas3D.setFocusable(true);     // give focus to the canvas 
    canvas3D.requestFocus();

    imRotator = new ImageRotator(backFnm, canvas3D);
    
    su = new SimpleUniverse(canvas3D);
    createSceneGraph();
    initUserPosition();        // set user's viewpoint
    orbitControls(canvas3D);   // controls for moving the viewpoint
    su.addBranchGraph( sceneBG );

    imRotator.start();   // start the background rotating
  } // end of WrapSpinPlanets3D()



  private void createSceneGraph() 
  // initilise the scene
  { 
    sceneBG = new BranchGroup();
    bounds = new BoundingSphere(new Point3d(0,0,0), BOUNDSIZE);   

    lightScene();         // add the light

    // add the planets
    addPlanet("earth.jpg", 3.0f, new Vector3f(-2,0,0));
    addPlanet("moon.jpg", 0.8f, new Vector3f(4,-1,0));
    addPlanet("mars.jpg", 2.0f, new Vector3f(2,3,-15));

    sceneBG.compile();   // fix the scene
  } // end of createSceneGraph()


  private void lightScene()
  /* One ambient light, 1 directional light */
  {
    // Set up the ambient light
    AmbientLight ambientLightNode = new AmbientLight(WHITE);
    ambientLightNode.setInfluencingBounds(bounds);
    sceneBG.addChild(ambientLightNode);

    // Set up the directional light
    Vector3f lightDir  = new Vector3f(-1,-1,-1);   // left, down, backwards 

    DirectionalLight light = 
            new DirectionalLight(WHITE, lightDir);
    light.setInfluencingBounds(bounds);
    sceneBG.addChild(light);
  }  // end of lightScene()


  private void orbitControls(Canvas3D c)
  /* OrbitBehaviour allows the user to rotate around the scene, and to
     zoom in and out.  */
  {
    OrbitBehavior orbit = 
		new OrbitBehavior(c, OrbitBehavior.REVERSE_ALL);
    orbit.setSchedulingBounds(bounds);

    ViewingPlatform vp = su.getViewingPlatform();
    vp.setViewPlatformBehavior(orbit);	 
  }  // end of orbitControls()



  private void initUserPosition()
  // Set the user's initial viewpoint using lookAt()
  {
    ViewingPlatform vp = su.getViewingPlatform();
    TransformGroup steerTG = vp.getViewPlatformTransform();

    Transform3D t3d = new Transform3D();
    steerTG.getTransform(t3d);

    // args are: viewer posn, where looking, up direction
    t3d.lookAt( USERPOSN, new Point3d(0,0,0), new Vector3d(0,1,0));
    t3d.invert();

    steerTG.setTransform(t3d);
  }  // end of initUserPosition()


  public void stopBackground()
  /* Stop the background rotating; 
     called from SpinPlanets3D */
  {  imRotator.stopRotating();  }



  private void addPlanet(String texFnm, float radius, Vector3f posVec)
  /* A planet is a sphere with the specfied radius and vector
     position. It's appearance is a combination of a gray lighted
     material and the texture loaded from texFnm.
  */
  {
    Appearance app = new Appearance();

    // combine texture with material and lighting of underlying surface
    TextureAttributes ta = new TextureAttributes();
    ta.setTextureMode( TextureAttributes.MODULATE );
    app.setTextureAttributes( ta );

    // assign gray material with lighting
    Material mat= new Material(GRAY, BLACK, GRAY, WHITE, 25.0f);
       // sets ambient, emissive, diffuse, specular, shininess
    mat.setLightingEnable(true);
    app.setMaterial(mat);

    // apply texture to shape
    Texture2D texture = loadTexture("images/" + texFnm);
    if (texture != null)
      app.setTexture(texture);

    // make the sphere with normals for lighting, and texture support
    Sphere globe = new Sphere(radius, 
                           Sphere.GENERATE_NORMALS |
                           Sphere.GENERATE_TEXTURE_COORDS,
                           15, app);   // default divs == 15

    // position the sphere
    Transform3D t3d = new Transform3D();
    t3d.set(posVec); 
    TransformGroup tg = new TransformGroup(t3d);
    tg.addChild(globe);
 
    sceneBG.addChild(tg);
  }  // end of addPlanet()



  private Texture2D loadTexture(String fn)
  // load image from file fn as a texture
  {
    TextureLoader texLoader = new TextureLoader(fn, null);
    Texture2D texture = (Texture2D) texLoader.getTexture();
    if (texture == null)
      System.out.println("Cannot load texture from " + fn);
    else {
      System.out.println("Loaded texture from " + fn);
      texture.setEnable(true);
    }
    return texture;
  }  // end of loadTexture()


} // end of WrapSpinPlanets3D class