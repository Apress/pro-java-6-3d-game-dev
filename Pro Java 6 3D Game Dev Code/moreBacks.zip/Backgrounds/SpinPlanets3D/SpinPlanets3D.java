
// SpinPlanets3D.java
// Andrew Davison, January 2006, ad@fivedots.coe.psu.ac.th

/* Display the earth, moon, and mars against a rotating background
   image drawn using a subclass of Canvas3D. 
   OrbitBehavior allows the user to navigate.

   The images are stores in the image/ subdirectory.

   Usage examples:
     java SpinPlanets3D whirlpool.jpg    
                // large image; slows the application

     java SpinPlanets3D tarantuala.jpg      
                // large image; slows the application

     java SpinPlanets3D galaxy.jpg    
                // medium-size image; application speed is ok  

     java SpinPlanets3D sun.gif
                // small image; no effect on application speed

  Move through the scene using OrbitBehavior mouse and control keys.
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class SpinPlanets3D extends JFrame
{
  private WrapSpinPlanets3D w3d;

  public SpinPlanets3D(String backFnm) 
  {
    super("Spin Planets3D");
    Container c = getContentPane();
    c.setLayout( new BorderLayout() );
    w3d = new WrapSpinPlanets3D(backFnm); // panel holding the 3D canvas
    c.add(w3d, BorderLayout.CENTER);

    addWindowListener( new WindowAdapter() {
      public void windowClosing(WindowEvent e)
      { w3d.stopBackground(); 
        System.exit(0);
      }
    });

    pack();
    setResizable(false);    // fixed size display
    setVisible(true);
  } // end of SpinPlanets3D()


// -----------------------------------------

  public static void main(String[] args)
  {  
    if (args.length != 1)
      System.out.println("Usage: java SpinPlanets3D <fnm from images/>");
    else
      new SpinPlanets3D(args[0]);  
  } // end of main()

} // end of SpinPlanets3D class
