
// GrabberBounds.java
// Andrew Davison, June 2006, ad@fivedots.coe.psu.ac.th

/* GrabberBounds contains an array of TGs which extend from 
   the Grabber's forearm to its fingers.

   After the grabber has moved, the world-coordinates for these TGS are 
   used to initialize an array of bounding spheres. These spheres are 
   used for collision detection with spheres in the other grabber.

   The last TG in the array is near the tip of the fingers,
   so is used to detect if the fingers are touching the ground.
*/

import java.text.DecimalFormat;

import javax.media.j3d.*;
import com.sun.j3d.utils.geometry.*;
import javax.vecmath.*;


public class GrabberBounds
{
  private BoundingSphere[] armBounds;
  private double radius;   // of the bounding spheres
  private int numSpheres;

  // TGs used for generating the bounding spheres
  private TransformGroup offsetTG;
  private TransformGroup[] armTGs;

  // reusable objects for the TG --> world coordinate calculations
  private Transform3D t3d, t3d1;
  private Vector3f posnVec; 
  private Point3d wCoord; 

  // for debugging reporting
  private DecimalFormat df = new DecimalFormat("0.##");  // 2 dp;   


  public GrabberBounds(TransformGroup jointTG, float offset, double r, int num)
  {
    radius = r;
    numSpheres = num;

    t3d = new Transform3D();
    t3d1 = new Transform3D();
    posnVec = new Vector3f();
    wCoord = new Point3d();

    initBS();

    makeArmTGs(jointTG, offset);
  } // end of GrabberBounds()


  private void initBS()
  /* Initialise the array of Bounding spheres with a specified
     radius. Their centers will be repeatedly updated as the 
     TGs move. */
  {
    armBounds = new BoundingSphere[numSpheres];

    for (int i=0; i < numSpheres; i++) {
      armBounds[i] = new BoundingSphere();
      armBounds[i].setRadius(radius);
    }
  }  // end of initBS()



  private void makeArmTGs(TransformGroup jointTG, float offset)
  /* Create a chain of TGs in armTGs[], attached to offsetTG.

     offsetTG is connected to jointTG which is the last joint in
     the grabber before the forearm. offsetTG is positioned 
     'offset' units along the forearm after jointTG.

     The TGs in armTGs[] are used to position a chain of
     bounding spheres, which are employed for collision detection.

     A blue sphere is optionally attached to each TG. The spheres act as 
     visual representations of the bounding spheres for the TGs, and
     allow the bounds calculations to be confirmed.
  */
  {
    Appearance blueApp = makeSphereApp();  // sphere's blue appearance

    // move to offset position, along the arm
    t3d.set( new Vector3f(0, offset, 0));
    offsetTG = new TransformGroup(t3d);
    jointTG.addChild(offsetTG);

    /* Create TGs chain after offsetTG. Start at the last one
       and move backwards towards the offsetTG. This makes it easier
       to attach a child TG to its parent. */
    armTGs = new TransformGroup[numSpheres];

    for (int i=(numSpheres-1); i >= 0; i--) {
      t3d.set( new Vector3f(0, (float)(radius*2), 0));
      armTGs[i] = new TransformGroup(t3d);
      armTGs[i].setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
      armTGs[i].setCapability(TransformGroup.ALLOW_LOCAL_TO_VWORLD_READ);
      if (i != numSpheres-1)
        armTGs[i].addChild( armTGs[i+1] );
      armTGs[i].addChild( new Sphere((float)radius, blueApp) );
                // optionally add a sphere for TG visibility
    }
    
    offsetTG.addChild(armTGs[0]);
  }  // end of makeArmTGs()


  private Appearance makeSphereApp()
  // A shiny blue appearance
  {
    Appearance app = new Appearance();

    Color3f black = new Color3f(0.0f, 0.0f, 0.0f);
    Color3f blue = new Color3f(0.3f, 0.3f, 0.8f);
    Color3f specular = new Color3f(0.9f, 0.9f, 0.9f);

    Material blueMat = new Material(blue, black, blue, specular, 25.0f);
       // sets ambient, emissive, diffuse, specular, shininess
    blueMat.setLightingEnable(true);

    app.setMaterial(blueMat);

    return app;
  }  // end of makeSphereApp()


  // -------------------------- check bounding spheres ------------------


  public BoundingSphere[] getArmBounds()
  /* Use the TGs to initialize the centers of the bounding
     spheres. */
  {
    for (int i=0; i < numSpheres; i++) {
      setWCoord(armTGs[i]);  // the wCoord global gets this TG's center point
      // printTuple("armTGs[" + i + "]", wCoord);
      armBounds[i].setCenter(wCoord);
    }
    return armBounds;
  }  // end of getArmBounds()


  private void setWCoord(TransformGroup tg)
  /* Extract the tg's center in world coordinates,
     and assign it to the wCoord global. */
  {
    tg.getLocalToVworld(t3d);   // position, not including this node's positioning
    tg.getTransform(t3d1);      // get this TG's transform
    t3d.mul(t3d1);              // apply it to the coordinates

    t3d.get(posnVec);
    wCoord.set(posnVec);
  }  // end of setWCoord()


  public boolean touches(BoundingSphere[] bs)
  /* Does one of the supplied bounding spheres in bs intersect one
     of this object's bounding spheres? 
     Check in reverse order, which corresponds to checking from
     the grabbers' fingers back up their forearms.
  */
  {
    BoundingSphere[] myBS = getArmBounds();

    for (int i=(bs.length-1); i >= 0; i--)
      for (int j=(myBS.length-1); j >=0; j--)
        if (bs[i].intersect(myBS[j])) {
          // System.out.println("ball " + (j+1) + " touching " + (i+1));
          // touchDetails(myBS[j], bs[i]);
          return true;
        }
    return false;
  }  // end of touches()


  private void touchDetails(BoundingSphere b1, BoundingSphere b2)
  // used for debugging 
  {
    // System.out.println("radii: " + b1.getRadius() + ", " + b2.getRadius());

    Point3d p1 = new Point3d();
    b1.getCenter(p1);
    printTuple("p1 center", p1);

    Point3d p2 = new Point3d();
    b2.getCenter(p2);
    printTuple("p2 center", p2);
  }  // end of touchDetails()


  // ------------------------------ ground touching ------------------------


  public boolean touchingGround()
  /* Check if the last TG is on, or below, ground level. */
  {
    setWCoord(armTGs[numSpheres-1]);  // set wCoord for last TG

    boolean touchingGround = (wCoord.y-radius <= 0);
    if (touchingGround)
      printTuple("last ball touching ground; center: ", wCoord);
    return touchingGround;
  }  // end of touchingGround()


  // ----------------------- debugging ------------------

  private void printTuple(String id, Tuple3d t)
  {
    System.out.println(id + " (" + df.format(t.x) + 
				", " + df.format(t.y) + ", " + df.format(t.z) + ")");
  }  // end of printTuple()


}  // end of GrabberBounds class
