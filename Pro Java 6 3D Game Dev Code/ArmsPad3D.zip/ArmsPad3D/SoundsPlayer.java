
// SoundsPlayer.java
// Andrew Davison, October 2006, ad@fivedots.coe.psu.ac.th

/* Stores sound names and their AudioClip objects (loaded from SOUND_DIR).
   The sounds can be played, looped, and stopped.

   The length of the sound files (in ms) can also be stored, which is useful
   in Obstacle for deciding how long to wait while a sound plays.

   A bug in (some versions of) Java SE 5 and 6 mean that MIDI files
   will not play. This is due to a MIDI OUT transmitter not being
   created, although nothing is reported by the AudioClip.play()
   method. A bug report, no. ??, is in Sun's database
   at ??. Please vote for it to be fixed.
*/

import java.applet.*;
import java.awt.*;
import java.util.*;


public class SoundsPlayer
{
  private final static String SOUND_DIR = "Sounds/";

  private HashMap<String, AudioClip> soundsMap;
  private HashMap<String, Integer> soundLensMap;



  public SoundsPlayer() 
  {
    soundsMap = new HashMap<String, AudioClip>();
    soundLensMap = new HashMap<String, Integer>();
  } // end of SoundsPlayer()


  public boolean load(String fnm)
  // Load the sound file with no sound length
  {  return load(fnm, -1);  }


  public boolean load(String fnm, int soundLen)
  /* Load the sound file and store it as an AudioClip
     in the hash map. Store its length in the soundLens map.
  */
  {
    if (soundsMap.get(fnm) != null) {
      System.out.println(SOUND_DIR + fnm + " already loaded");
      return true;
    }

    AudioClip audioClip = Applet.newAudioClip( 
                getClass().getResource(SOUND_DIR + fnm) );
    if (audioClip == null) {
      System.out.println("Problem loading " +  SOUND_DIR + fnm);
      return false;
    }

    System.out.println("Loaded " +  SOUND_DIR + fnm);
    soundsMap.put(fnm, audioClip);
    soundLensMap.put(fnm, soundLen);
    return true;
  }  // end of load()


  public void play(String fnm)
  // retrieve the relevant AudioClip, and start it playing
  {  
    AudioClip audioClip = (AudioClip) soundsMap.get(fnm);
    if (audioClip == null) {
      System.out.println("Could not find " +  SOUND_DIR + fnm);
      return;
    }
    audioClip.play(); 
  }  // end of play()


  public void playLoop(String fnm)
  // retrieve the relevant AudioClip, and start it playing repeatedly
  {
    AudioClip audioClip = (AudioClip) soundsMap.get(fnm);
    if (audioClip == null) {
      System.out.println("Could not find " +  SOUND_DIR + fnm);
      return;
    }
    audioClip.loop();
  }  // end of playLoop()


  public int getLength(String fnm)
  // return the sound length for fnm (or -1)
  {
    Integer sndLen = (Integer) soundLensMap.get(fnm);
    if (sndLen == null)   // not found
      return -1;
    else
      return sndLen.intValue();
  }  // end of getLength()


  public void stop(String fnm)
  {
    AudioClip audioClip = (AudioClip) soundsMap.get(fnm);
    if (audioClip == null)
      System.out.println(fnm + " not playing");
    else
      audioClip.stop();   // may already have stopped, but calling
                          // stop() again does no harm
  }  // end of stop()


  public void stopAll()
  /* Stop all the music by calling stop() on all the references in
     soundsMap. One issue is that some of the clips may have
     already finished playing by themselves, but there is no way
     to detect that when using the AudioClip class. */
  {
    Set<String> keys = soundsMap.keySet(); 
    Iterator<String> iter = keys.iterator(); 

    AudioClip audioClip;
    while(iter.hasNext()){ 
      audioClip = soundsMap.get( iter.next()); 
      audioClip.stop(); 
    }
  }  // end of stopAll()

} // end of SoundsPlayer class
