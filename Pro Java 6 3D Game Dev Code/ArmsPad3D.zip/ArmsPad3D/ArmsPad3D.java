
// ArmsPad3D.java
// Andrew Davison, October 2006, ad@fivedots.coe.psu.ac.th

/* A world full of 3D models and ground shapes on a checkboard floor. 
   The models and ground shapes were first seen in the ObjView3D
   example. A new feature is that the models/shapes may include
   translucent boxes, acting as bounding boxes. 

   The user's viewpoint is bracketed by two grabbers (first seen
   in the Arms3D example), which can be moved using the keyboard
   or a game pad. 

   The game pad controller comes from the GamePadViewer example.

   If the grabbers hit a bounding box, then movement stops, a sound is
   played, and the game pad rumbles.

   There should also be MIDI music playing in the background, but a
   bug in some versions of Java SE 5/6 may prevent it from being heard.
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class ArmsPad3D extends JFrame
{
  public ArmsPad3D() 
  {
    super("ArmsPad3D");
    Container c = getContentPane();
    c.setLayout( new BorderLayout() );
    WrapArmsPad3D w3d = new WrapArmsPad3D();     // panel holding the 3D canvas
    c.add(w3d, BorderLayout.CENTER);

    setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    pack();
    setResizable(false);    // fixed size display
    setVisible(true);
  } // end of ArmsPad3D()


// -----------------------------------------

  public static void main(String[] args)
  {  new ArmsPad3D(); }

} // end of ArmsPad3D class
