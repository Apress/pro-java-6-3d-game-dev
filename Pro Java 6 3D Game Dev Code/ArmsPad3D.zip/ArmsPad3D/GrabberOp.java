
// GrabberOp.java
// Andrew Davison, October 2006, ad@fivedots.coe.psu.ac.th

/* GrabberOp represents a grabber operation as 4 integer variables:
        opVal : for the grabber operation name
        partVal : for the grabber part being used;
        jointVal : for the grabber joint being used;
        rotVal : for the rotation direction

   The values come from a very large set of public integer constants.
   They're public so they can be used by other classes (e.g. Grabbers
   and Grabber).

   A grabber object can be created either from keystrokes (by KeyBehavior)
   or from game pad input (by GamePadBehavior), so there are three 
   constructors: a default one, one for key input, and one for game pad
   input.

   The constructors call set() methods which examine the keystrokes or game
   pad input to decide how to assign values to opVal, partVal, jointVal,
   and rotVal. The game pad code uses many constants from GamePadController.

   Each of the 4 state variables has their own get/set/is-test methods.

   The reverse() method makes a new GrabberOp object where the rotation
   direction is reversed. This is used for undoing a rotation when a 
   collision is detected in Grabbers.

   ----
   This may seem like a lot of work but the extra level of abstraction of
   having GrabberOp objects means that the grabbers can deal with a mix
   of keyboard and game pad input.
*/

import java.awt.event.*;


public class GrabberOp
{
  // operation name constants (0 - 24)
  public final static int NONE = 0;

  // grabbers base constants
  public final static int BASE_FWD = 1;
  public final static int BASE_BACK = 2;
  public final static int BASE_LEFT = 3;
  public final static int BASE_RIGHT = 4;
  public final static int BASE_ROT_LEFT = 5;
  public final static int BASE_ROT_RIGHT = 6;
  public final static int BASE_UP = 7;
  public final static int BASE_DOWN = 8;

  // left grabber constants
  public final static int LEFT_X_POS = 9;
  public final static int LEFT_X_NEG = 10;
  public final static int LEFT_Y_POS = 11;
  public final static int LEFT_Y_NEG = 12;
  public final static int LEFT_Z_POS = 13;
  public final static int LEFT_Z_NEG = 14;
  public final static int LEFT_FING_POS = 15;
  public final static int LEFT_FING_NEG = 16;

  // right grabber constants
  public final static int RIGHT_X_POS = 17;
  public final static int RIGHT_X_NEG = 18;
  public final static int RIGHT_Y_POS = 19;
  public final static int RIGHT_Y_NEG = 20;
  public final static int RIGHT_Z_POS = 21;
  public final static int RIGHT_Z_NEG = 22;
  public final static int RIGHT_FING_POS = 23;
  public final static int RIGHT_FING_NEG = 24;

  // ------------
  // grabbers part name constants (0-3)
  public static final int NO_PART = 0;
  public static final int BASE = 1;
  public static final int LEFT_GRABBER = 2;
  public static final int RIGHT_GRABBER = 3;

  // ------------
  // joint names constants (0-4)
  public static final int NOT_JOINT = 0;
  public static final int X_JOINT = 1;
  public static final int Y_JOINT = 2;
  public static final int Z_JOINT = 3;
  public static final int FING_JOINT = 4;

  // ------------
  // rotation directions constants (0-2)
  public static final int NO_ROT = 0;
  public static final int POS = 1;
  public static final int NEG = 2;


  // better names for the translation/rotation keys
  // for translating the grabbers
  private final static int forwardKey = KeyEvent.VK_UP;
  private final static int backKey = KeyEvent.VK_DOWN;
  private final static int leftKey = KeyEvent.VK_LEFT;
  private final static int rightKey = KeyEvent.VK_RIGHT;

  // for rotating a grabber's joints and fingers
  private final static int rotXKey = KeyEvent.VK_X;
  private final static int rotYKey = KeyEvent.VK_Y;
  private final static int rotZKey = KeyEvent.VK_Z;
  private final static int rotfinKey = KeyEvent.VK_F;


  // state vars
  private int opVal, partVal, jointVal, rotVal;
     /* opVal is assigned one of the operation name constants;
        partVal is assigned one of the part name constants;
        jointVal is assigned one of the joint name constants;
        rotVal is assigned one of the rotation direction constants;
     */


  public GrabberOp()
  {
    // default values
    opVal = NONE;
    partVal = NO_PART;
    jointVal = NOT_JOINT;
    rotVal = NO_ROT;
  } // end of GrabberOp();



  public GrabberOp(KeyEvent eventKey)
  // create a GrabberOp from keystrokes (by KeyBehavior)
  {
    this();   // assign the default values

    /* this code assumes that the shift and alt keys are used
       as modifiers */
    int keyCode = eventKey.getKeyCode();
    boolean isShift = eventKey.isShiftDown();
    boolean isAlt = eventKey.isAltDown();
    // System.out.println("Using: " + keyCode + " s/a: " + isShift + "/" + isAlt);

    if((keyCode == forwardKey) || (keyCode == backKey) ||
       (keyCode == leftKey) || (keyCode == rightKey))
      setBaseOp(keyCode, isAlt);
    else {  // grabbers
      if (isShift)    // right grabber
        setRightGrabberOp(keyCode, isAlt);
      else  // left grabber
        setLeftGrabberOp(keyCode, isAlt);
    }
  }  // end of GrabberOp() the keyboard


  public GrabberOp(int gamePadComponent, int val)
  // create a GrabberOp from game pad input (by GamePadBehavior)
  {
    this();

    /* this code assumes that the game pad input may be a left
       or right stick, hat, or buttons */
    if (gamePadComponent == GamePadController.LEFT_STICK)
      setLeftStick(val);
    else if (gamePadComponent == GamePadController.RIGHT_STICK)
      setRightStick(val);
    else if (gamePadComponent == GamePadController.HAT)
      setHat(val);
    else if (gamePadComponent == GamePadController.BUTTONS)
      setButton(val);
    else
      System.out.println("Do not recognize game pad component: " +
                              gamePadComponent);
  }  // end of GrabberOp() for the game pad


  // ----------------------- set methods for the keyboard ----------

  private void setBaseOp(int keycode, boolean isAlt)
  /* Make viewer moves forward or backward; 
     rotate left or right */
  { 
    partVal = BASE;
    if(isAlt) {   // key + <alt>
      if(keycode == forwardKey)
        opVal = BASE_UP;
      else if(keycode == backKey)
        opVal = BASE_DOWN;
      else if(keycode == leftKey)
        opVal = BASE_LEFT;
      else if(keycode == rightKey)
        opVal = BASE_RIGHT;
    }
    else {  // just <key>
      if(keycode == forwardKey)
        opVal = BASE_FWD;
      else if(keycode == backKey)
        opVal = BASE_BACK;
      else if(keycode == leftKey)
        opVal = BASE_ROT_LEFT;
      else if(keycode == rightKey)
        opVal = BASE_ROT_RIGHT;
    }
  } // end of setBaseOp()


  private void setRightGrabberOp(int keyCode, boolean isAlt)
  // deal with key input for moving the right grabber
  {
    partVal = RIGHT_GRABBER;
    if (isAlt) {  // ALT means a negative rotation
      rotVal = NEG;
      if(keyCode == rotXKey) {
        opVal = RIGHT_X_NEG;
        jointVal = X_JOINT;
      }
      else if(keyCode == rotYKey) {
        opVal = RIGHT_Y_NEG;
        jointVal = Y_JOINT;
      }
      else if(keyCode == rotZKey) {
        opVal = RIGHT_Z_NEG;
        jointVal = Z_JOINT;
      }
      else if(keyCode == rotfinKey) {
        opVal = RIGHT_FING_NEG;
        jointVal = FING_JOINT;
      }
    }
    else {  // positive rot
      rotVal = POS;
      if(keyCode == rotXKey) {
        opVal = RIGHT_X_POS;
        jointVal = X_JOINT;
      }
      else if(keyCode == rotYKey) {
        opVal = RIGHT_Y_POS;
        jointVal = Y_JOINT;
      }
      else if(keyCode == rotZKey) {
        opVal = RIGHT_Z_POS;
        jointVal = Z_JOINT;
      }
      else if(keyCode == rotfinKey) {
        opVal = RIGHT_FING_POS;
        jointVal = FING_JOINT;
      }
    }
  }  // end of setRightGrabberOp()


  private void setLeftGrabberOp(int keyCode, boolean isAlt)
  // deal with key input for moving the left grabber
  {
    partVal = LEFT_GRABBER;
    if (isAlt) {  // ALT means a negative rotation
      rotVal = NEG;
      if(keyCode == rotXKey) {
        opVal = LEFT_X_NEG;
        jointVal = X_JOINT;
      }
      else if(keyCode == rotYKey) {
        opVal = LEFT_Y_NEG;
        jointVal = Y_JOINT;
      }
      else if(keyCode == rotZKey) {
        opVal = LEFT_Z_NEG;
        jointVal = Z_JOINT;
      }
      else if(keyCode == rotfinKey) {
        opVal = LEFT_FING_NEG;
        jointVal = FING_JOINT;
      }
    }
    else {  // positive rot
      rotVal = POS;
      if(keyCode == rotXKey) {
        opVal = LEFT_X_POS;
        jointVal = X_JOINT;
      }
      else if(keyCode == rotYKey) {
        opVal = LEFT_Y_POS;
        jointVal = Y_JOINT;
      }
      else if(keyCode == rotZKey) {
        opVal = LEFT_Z_POS;
        jointVal = Z_JOINT;
      }
      else if(keyCode == rotfinKey) {
        opVal = LEFT_FING_POS;
        jointVal = FING_JOINT;
      }
    }
  }  // end of setLeftGrabberOp()


  // -------------------- set methods for the game pad ----------


  private void setLeftStick(int dir)
  // deal with input from the game pad's left stick
  // not using GamePadController NONE, NE, NW, SE, SW
  {
    partVal = LEFT_GRABBER;   // left stick --> left grabber

    if (dir == GamePadController.NORTH) {   // y up
      opVal = LEFT_Y_POS;
      jointVal = Y_JOINT;  rotVal = POS;
    }
    else if (dir == GamePadController.SOUTH) {  // y down
      opVal = LEFT_Y_NEG;
      jointVal = Y_JOINT;  rotVal = NEG;
    }
    else if (dir == GamePadController.EAST) {  // x right
      opVal = LEFT_X_NEG;
      jointVal = X_JOINT;  rotVal = NEG;
    }
    else if (dir == GamePadController.WEST) {  // x left
      opVal = LEFT_X_POS;
      jointVal = X_JOINT;  rotVal = POS;
    }
  }  // end of setLeftStick()



  private void setRightStick(int dir)
  // deal with input from the game pad's right stick
  // not using GamePadController NONE, NE, NW, SE, SW 
  {
    partVal = RIGHT_GRABBER;  // right stick --> right grabber

    if (dir == GamePadController.NORTH) {   // y up
      opVal = RIGHT_Y_POS;
      jointVal = Y_JOINT;  rotVal = POS;
    }
    else if (dir == GamePadController.SOUTH) {  // y down
      opVal = RIGHT_Y_NEG;
      jointVal = Y_JOINT;  rotVal = NEG;
    }
    else if (dir == GamePadController.EAST) {  // x right
      opVal = RIGHT_X_NEG;
      jointVal = X_JOINT;  rotVal = NEG;
    }
    else if (dir == GamePadController.WEST) {  // x left
      opVal = RIGHT_X_POS;
      jointVal = X_JOINT;  rotVal = POS;
    }
  }  // end of setRightStick()



  private void setHat(int dir)
  // deal with input from the game pad's hat
  // not using GamePadController NONE, NE, NW, SE, SW
  {
    partVal = BASE;    // hat --> grabbers base
    if (dir == GamePadController.NORTH)   // base up
      opVal = BASE_UP;
    else if (dir == GamePadController.SOUTH)  // base down
      opVal = BASE_DOWN;
    else if (dir == GamePadController.EAST)  // base rotate right
      opVal = BASE_ROT_RIGHT;
    else if (dir == GamePadController.WEST)  // base rotate left
      opVal = BASE_ROT_LEFT;
  }  // end of setHat()



  private void setButton(int buttonIndex)
  /* The game pad buttons are mapped to several parts of the grabbers:
     the base, left/right fingers, and the left/right z-joints
  */
  {
    // base
    if (buttonIndex == 0) {   // button 1  (right pad)
      opVal = BASE_FWD;   // base moves forward
      partVal = BASE;
    }
    else if (buttonIndex == 1) {   // button 2
      opVal = BASE_RIGHT;   // base moves right  
      partVal = BASE;
    }
    else if (buttonIndex == 2){   // button 3
      opVal = BASE_BACK;   // base moves back
      partVal = BASE;
    }
    else if (buttonIndex == 3) {   // button 4
      opVal = BASE_LEFT;   // base moves left
      partVal = BASE;
    }
    //  fingers
    else if (buttonIndex == 4) {   // button 5  (on front)
      opVal = LEFT_FING_POS;   // left fingers open
      partVal = LEFT_GRABBER;
      jointVal = FING_JOINT;  rotVal = POS;
    }
    else if (buttonIndex == 5) {   // button 6
      opVal = RIGHT_FING_POS;   // right fingers open
      partVal = RIGHT_GRABBER;
      jointVal = FING_JOINT;  rotVal = POS;
    }
    else if (buttonIndex == 6){   // button 7
      opVal = LEFT_FING_NEG;   // left fingers close
      partVal = LEFT_GRABBER;
      jointVal = FING_JOINT;  rotVal = NEG;
    }
    else if (buttonIndex == 7) {   // button 8
      opVal = RIGHT_FING_NEG;   // right fingers close
      partVal = RIGHT_GRABBER;
      jointVal = FING_JOINT;  rotVal = NEG;
    }
    // z-joints
    else if (buttonIndex == 8) {   // button 9  (on top)
      opVal = LEFT_Z_POS;   // left z-joint rotates
      partVal = LEFT_GRABBER;
      jointVal = Z_JOINT;  rotVal = POS;
    }
    else if (buttonIndex == 9) {   // button 10
      opVal = RIGHT_Z_POS;   // right z-joint rotates
      partVal = RIGHT_GRABBER;
      jointVal = Z_JOINT;  rotVal = POS;
    }
    else if (buttonIndex == 10){   // button 11
      opVal = LEFT_Z_NEG;   // left z-joint rotates
      partVal = LEFT_GRABBER;
      jointVal = Z_JOINT;  rotVal = NEG;
    }
    else if (buttonIndex == 11) {   // button 12
      opVal = RIGHT_Z_NEG;   // right  z-joint rotates
      partVal = RIGHT_GRABBER;
      jointVal = Z_JOINT;  rotVal = NEG;
    }
  } // end of setButton()



  // ------------------ op methods -------------------

  public int getOp()
  {  return opVal;  }

  public boolean isOp(int op)
  {  return opVal == op;  }

  public void setOp(int op)
  {  opVal = op;  }  // no checking of op


  // ------------------ parts methods -------------------

  public int getPart()
  {  return partVal;  }

  public boolean isPart(int p)
  {  return partVal == p;  }

  public void setPart(int p)
  {  partVal = p;  }  // no checking of p


  // ------------------ joint methods -------------------

  public int getJoint()
  {  return jointVal;  }

  public boolean isJoint(int j)
  {  return jointVal == j;  }

  public void setJoint(int j)
  {  jointVal = j;  }  // no checking of j


  // ------------------ rotation methods -------------------

  public int getRotation()
  {  return rotVal;  }

  public boolean isRotation(int r)
  {  return rotVal == r;  }

  public void setRotation(int r)
  {  rotVal = r;  }  // no checking of r


  
  // -------------------------------------


  public GrabberOp reverse()
  /* Make a copy of this object with a reversed rotation. This is used for 
     undoing a rotation when a collision is detected in Grabbers.
  */
  {
    // copy the op, part, and joint values for this object
    GrabberOp gop = new GrabberOp();
    gop.setOp(opVal);
    gop.setPart(partVal);
    gop.setJoint(jointVal);

    // reverse the rotation (if possible)
    if (rotVal == NO_ROT) {
      System.out.println("Cannot reverse since no rotation found");
      gop.setRotation(rotVal);
    }
    else if (rotVal == POS)
      gop.setRotation(NEG);
    else   // must be NEG
      gop.setRotation(POS);

    return gop;
  }  // end of reverse()

}  // end of GrabberOp class
