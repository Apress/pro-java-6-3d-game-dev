
Chapter 12. Game Pad Grabbers

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2


Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

=============================================
Contents of this Directory

* compileJI.bat
   - a batch file for compiling the ArmsPad3D example

* runJI.bat
   - a batch file for running the example

* 16 Java files:
    ArmsPad3D.java, WrapArmsPad3D.java, 
    CheckerFloor.java, ColouredTiles.java, 
    GroundShape.java, ModelLoader.java, 
    Obstacles.java, Obstacle.java, SoundsPlayer.java,
    Grabbers.java, Grabber.java, GrabberBounds.java,
    KeyBehavior.java, GamePadBehavior.java, GrabberOp.java
    GamePadController.java   

* images/
    lava.jpg, steel.jpg, tree2.jpg, tree4.jpg

* models/     // the 3D models
    cow.obj, pig.obj, pig.mtl, teapot.obj

* Sounds/
    cow.wav, door.wav, oink.wav, wood.wav
    mission_impossible_tv.mid 


=============================================
Software/Hardware You Need

* The JInput API for Windows, available from 
  https://jinput.dev.java.net. Look in the Win32 folder 
  under the "Documents & Files" menu item.
  
* A game pad: the GamePadController class, and several other classes,
  assumes there is a device with two analog sticks, a hat, 
  12 buttons, and rumbler support attached to the machine. 

* This chapter is a follow-up to:
     Chapter 11. Building a Game Pad Controller with JInput
     http://fivedots.coe.psu.ac.th/~ad/jg2/ch11/
  **READ THAT CHAPTER FIRST** to learn how use JInput with
  the game pad.


=============================================
Compilation: 

Use the compileJI.bat batch file.

$ compileJI *.java
    // make sure you have JInput installed

compileJI.bat assumes the JInput library files are located
in d:\jinput\bin. Change the batch file to match where you've
placed the files.


=============================================
Execution: 

Use the runJI.bat batch file.

$ runJI ArmsPad3D
    // make sure you have JInput installed

runJI.bat assumes the JInput library files are located
in d:\jinput\bin. Change the batch file to match where you've
placed the files.


=============================================
Changes on 25th January 2007

1. Changed playSound() in the Obstacle class to use a
   single threaded executor service to play the sound.

2. Changed rumblePad() in the Grabbers class to use a
   single threaded executor service to play the 
   game pad rumbler.

---------
Last updated: 4th March 2007