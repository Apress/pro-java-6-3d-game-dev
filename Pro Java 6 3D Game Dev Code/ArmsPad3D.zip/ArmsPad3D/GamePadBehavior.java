
// GamePadBehavior.java
// Andrew Davison, October 2006, ad@fivedots.coe.psu.ac.th

/* Use game pad input to affect the grabbers.

   Every DELAY ms, poll the GamePadController
   and convert all the component settings into new GrabberOp
   objects, which are past to the Grabbers object for processing.

   No translations or rotations are executed here.
*/

import java.awt.AWTEvent;
import java.awt.event.*;
import java.util.*;

import javax.media.j3d.*;
import com.sun.j3d.utils.universe.*;


public class GamePadBehavior extends Behavior
{
  private static final int DELAY = 75;   // ms (polling interval)


  private Grabbers grabbers;
  private ArrayList<GrabberOp> gops;   // storage for the created GrabberOps
  private GamePadController gamePad;
  private WakeupCondition wakeUpCond;


  public GamePadBehavior(Grabbers gs, GamePadController gp)
  { 
    grabbers = gs;
    gamePad = gp;

    gops = new ArrayList<GrabberOp>();
    wakeUpCond = new WakeupOnElapsedTime(DELAY);
  } // end of GamePadBehavior()


  public void initialize()
  {  wakeupOn(wakeUpCond);  }


  public void processStimulus(Enumeration criteria)
  // Periodically send game pad input as GrabberOps to Grabbers
  {
    gops.clear();     // clear array list for storing the GrabberOps

    gamePad.poll();   // update the game pad's components

    /* create GrabberOps for the game pad components:
          left/right sticks, a hat, and buttons
    */
    processLeftStick( gamePad.getXYStickDir() );
    processRightStick( gamePad.getZRZStickDir() );
    processHat( gamePad.getHatDir() );
    processButtons( gamePad.getButtons() );

    // System.out.println("Processing " + gops.size() + " grabber ops");
    // send the GrabberOps to Grabbers
    for(int i=0; i < gops.size(); i++)
      grabbers.processOp( gops.get(i) );

    wakeupOn(wakeUpCond);       // make sure we are notified again
  } // end of processStimulus()


  private void processLeftStick(int dir)
  /* The 8 compass directions of the left stick are converted into
     GrabberOps. The diagonal directions are converted into two operations
     each. This means that only NORTH, SOUTH, EAST, and WEST need to be
     processed in GrabberOp.
     The NONE direction is not converted into a GrabberOp.
  */
  {
    if ((dir == GamePadController.NORTH) || (dir == GamePadController.SOUTH) ||
        (dir == GamePadController.EAST) || (dir == GamePadController.WEST)) 
      gops.add( new GrabberOp(GamePadController.LEFT_STICK, dir) );
    else if (dir == GamePadController.NE) {
      gops.add( new GrabberOp(GamePadController.LEFT_STICK, GamePadController.NORTH) );
      gops.add( new GrabberOp(GamePadController.LEFT_STICK, GamePadController.EAST) );
    }
    else if (dir == GamePadController.NW) {
      gops.add( new GrabberOp(GamePadController.LEFT_STICK, GamePadController.NORTH) );
      gops.add( new GrabberOp(GamePadController.LEFT_STICK, GamePadController.WEST) );
    }
    else if (dir == GamePadController.SE) {
      gops.add( new GrabberOp(GamePadController.LEFT_STICK, GamePadController.SOUTH) );
      gops.add( new GrabberOp(GamePadController.LEFT_STICK, GamePadController.EAST) );
    }
    else if (dir == GamePadController.SW) {
      gops.add( new GrabberOp(GamePadController.LEFT_STICK, GamePadController.SOUTH) );
      gops.add( new GrabberOp(GamePadController.LEFT_STICK, GamePadController.WEST) );
    }
  }  // end of processLeftStick()


  private void processRightStick(int dir)
  /* The 8 compass directions of the right stick are converted into
     GrabberOps. The diagonal directions are converted into two operations
     each. This means that only NORTH, SOUTH, EAST, and WEST need to be
     processed in GrabberOp.
     The NONE direction is not converted into a GrabberOp.
  */
  {
    if ((dir == GamePadController.NORTH) || (dir == GamePadController.SOUTH) ||
        (dir == GamePadController.EAST) || (dir == GamePadController.WEST)) 
      gops.add( new GrabberOp(GamePadController.RIGHT_STICK, dir) );
    else if (dir == GamePadController.NE) {
      gops.add( new GrabberOp(GamePadController.RIGHT_STICK, GamePadController.NORTH) );
      gops.add( new GrabberOp(GamePadController.RIGHT_STICK, GamePadController.EAST) );
    }
    else if (dir == GamePadController.NW) {
      gops.add( new GrabberOp(GamePadController.RIGHT_STICK, GamePadController.NORTH) );
      gops.add( new GrabberOp(GamePadController.RIGHT_STICK, GamePadController.WEST) );
    }
    else if (dir == GamePadController.SE) {
      gops.add( new GrabberOp(GamePadController.RIGHT_STICK, GamePadController.SOUTH) );
      gops.add( new GrabberOp(GamePadController.RIGHT_STICK, GamePadController.EAST) );
    }
    else if (dir == GamePadController.SW) {
      gops.add( new GrabberOp(GamePadController.RIGHT_STICK, GamePadController.SOUTH) );
      gops.add( new GrabberOp(GamePadController.RIGHT_STICK, GamePadController.WEST) );
    }
  }  // end of processRightStick()


  private void processHat(int dir)
  /* The 8 compass directions of the hat are converted into
     GrabberOps. The diagonal directions are converted into two operations
     each. This means that only NORTH, SOUTH, EAST, and WEST need to be
     processed in GrabberOp.
     The NONE direction is not converted into a GrabberOp.
  */
  {
    if ((dir == GamePadController.NORTH) || (dir == GamePadController.SOUTH) ||
        (dir == GamePadController.EAST) || (dir == GamePadController.WEST)) 
      gops.add( new GrabberOp(GamePadController.HAT, dir) );
    else if (dir == GamePadController.NE) {
      gops.add( new GrabberOp(GamePadController.HAT, GamePadController.NORTH) );
      gops.add( new GrabberOp(GamePadController.HAT, GamePadController.EAST) );
    }
    else if (dir == GamePadController.NW) {
      gops.add( new GrabberOp(GamePadController.HAT, GamePadController.NORTH) );
      gops.add( new GrabberOp(GamePadController.HAT, GamePadController.WEST) );
    }
    else if (dir == GamePadController.SE) {
      gops.add( new GrabberOp(GamePadController.HAT, GamePadController.SOUTH) );
      gops.add( new GrabberOp(GamePadController.HAT, GamePadController.EAST) );
    }
    else if (dir == GamePadController.SW) {
      gops.add( new GrabberOp(GamePadController.HAT, GamePadController.SOUTH) );
      gops.add( new GrabberOp(GamePadController.HAT, GamePadController.WEST) );
    }
  }  // end of processRightStick()


  private void processButtons(boolean[] buttons)
  /* Each of the pressed game pad buttons is converted into a
     GrabberOp. */
  {
    for (int i=0; i< buttons.length; i++)
      if (buttons[i]) // is pressed
        gops.add( new GrabberOp(GamePadController.BUTTONS, i) );
  }  // end of processButtons()


} // end of GamePadBehavior class
