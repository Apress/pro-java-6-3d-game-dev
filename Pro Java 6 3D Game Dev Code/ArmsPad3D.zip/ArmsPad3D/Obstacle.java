
// Obstacle.java
// Andrew Davison, January 2007, ad@fivedots.coe.psu.ac.th

/* An obstacle is a bounding box with a semi-transparent visible box
   located in the same space to make things easier to test/debug.

   Collision detection is done by calling the intersect() method
   with a Bounds object or a point. If an intersection occurs then a
   sound is played with the help of the SoundsPlayer object.

   A sound is played to its end before the sound can be played again.
*/

import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.geometry.*;
import java.util.concurrent.*;


public class Obstacle
{
  private String soundFnm;   
  private BoundingBox boundBox;

  private ExecutorService soundExecutor;
  private SoundsPlayer soundsPlayer;
  private boolean isSoundPlaying = false;


  public Obstacle(BranchGroup sceneBG, SoundsPlayer sp, 
                            String sndfnm,
                            double x, double z, 
                            double xLen, double yLen, double zLen)
  // create the bounding and visible boxes
  {
    soundsPlayer = sp;
    soundFnm = sndfnm;
    soundExecutor = Executors.newSingleThreadExecutor();
        // create a single worker thread to process sound playing tasks

    makeBoundBox(x, z, xLen, yLen, zLen);
    if (sceneBG != null)
      addVisibleBox(sceneBG, x, z, xLen, yLen, zLen);

  }  // end of Obstacle()


  private void makeBoundBox(double x, double z, double xLen, double yLen, double zLen)
  /* The bounding box is centered at (x,z) on the XZ plane, with sides of
     the dimensions xLen, yLen, and zLen. It's base rests on the XZ plane.
  */
  {
    Point3d lower = new Point3d(x-xLen/2, 0, z-zLen/2);
    Point3d upper = new Point3d(x+xLen/2, yLen, z+zLen/2);
    // System.out.println("lower: (" + lower.x + "," + lower.y + "," + lower.z + ")");
    // System.out.println("upper: (" + upper.x + "," + upper.y + "," + upper.z + ")");

    boundBox = new BoundingBox(lower, upper);
  }  // end of makeBoundBox


  private void addVisibleBox(BranchGroup sceneBG, double x, double z, 
                                       double xLen, double yLen, double zLen)
  /* The visible box is centered at (x,z) on the XZ plane, with sides of
     the dimensions xLen, yLen, and zLen. It's base rests on the XZ plane.
     The box occupies the same space as the bounding box.
     It has a default white colour but is translucent.
  */

  {
    Appearance app = new Appearance();    // default white colour

    // switch off face culling
    PolygonAttributes pa = new PolygonAttributes();
    pa.setCullFace(PolygonAttributes.CULL_NONE);
    app.setPolygonAttributes(pa);

    // semi-transparent appearance
    TransparencyAttributes ta = new TransparencyAttributes();
    ta.setTransparencyMode( TransparencyAttributes.BLENDED );
    ta.setTransparency(0.7f);     // 1.0f is totally transparent
    app.setTransparencyAttributes(ta);

    Box obsBox = new Box( (float)xLen/2, (float)yLen/2, (float)zLen/2, app);

    // fix box position
    Transform3D t3d = new Transform3D();
    t3d.setTranslation( new Vector3d(x, yLen/2+0.01, z) ); // bit above ground

    TransformGroup tg = new TransformGroup();
    tg.setTransform(t3d);
    tg.addChild(obsBox); 

    sceneBG.addChild(tg);
  }  // end of addVisibleBox()


  public boolean intersect(Bounds b)
  /* If b intersects with the bounding box for this object then play
     the 'soundFnm' sound. */
  {  
    boolean isIntersecting = boundBox.intersect(b);
    if (isIntersecting)
      playSound();
    return isIntersecting;  
  }  // end of intersect() with Bounds


  public boolean intersect(Point3d p)
  /* If p intersects with the bounding box for this object then play
     the 'soundFnm' sound. */
  {
    boolean isIntersecting = boundBox.intersect(p);
    if (isIntersecting)
      playSound();
    return isIntersecting;  
  }  // end of intersect() with Point3d


  private void playSound()
  /* Play the obstacle sound if it isn't already playing,
     and ignore other sound playing requests until the 
     sound has finished. */
  {
    if ((soundFnm != null) && !isSoundPlaying)
      soundExecutor.execute( new Runnable() {
        public void run() 
        {
          isSoundPlaying = true;
          int sndLen = soundsPlayer.getLength(soundFnm);  
          if (sndLen == -1)
            sndLen = 1000;   // a reasonable default waiting time (1 sec)
          soundsPlayer.play(soundFnm);
          try {
            Thread.sleep(sndLen);   // wait for sound to finish
          }
          catch(InterruptedException ex) {}
          isSoundPlaying = false;
        } // end of run()
      });
  }  // end of playSound()


} // end of Obstacle class
