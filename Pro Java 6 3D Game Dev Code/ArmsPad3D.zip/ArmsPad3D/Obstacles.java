
// Obstacles.java
// Andrew Davison, October 2006, ad@fivedots.coe.psu.ac.th

/* A wrapper for an ArrayList of Obstacle objects. It also
   stores a reference to the SoundPlayer which plays sounds when
   something hits the obstacles. The sceneBG ref. is used to attach
   an obstacle's visible box to the scene.

   There are several intersection methods for testing a Bound
   object, a Bounds array, and a point against every obstacle.
*/

import java.util.*;
import javax.media.j3d.*;
import javax.vecmath.*;


public class Obstacles
{
  private BranchGroup sceneBG;
  private SoundsPlayer soundsPlayer;
  private ArrayList<Obstacle> obs;


  public Obstacles(BranchGroup sceneBG, SoundsPlayer sp)
  {
    this.sceneBG = sceneBG;
    soundsPlayer = sp;
    obs = new ArrayList<Obstacle>();
  }  // end of Obstacles()


  public void add(String sndfnm, double x, double z, 
                                double xLen, double yLen, double zLen)
  {  obs.add( new Obstacle(sceneBG, soundsPlayer, sndfnm, x, z, 
                                               xLen, yLen, zLen) );  }


  public boolean intersect(Bounds b)
  {
    Obstacle ob;
    for(int i=0; i < obs.size(); i++) {
      ob = obs.get(i);
      if (ob.intersect(b))
        return true;
    }
    return false;
  } // end of intersect() for bounds object


  public boolean intersects(Bounds[] bs)
  {
    for(int i=0; i < bs.length; i++) {
      if (intersect(bs[i]))
        return true;
    }
    return false;
  } // end of intersects() for bounds array


  public boolean intersect(Point3d p)
  {
    Obstacle ob;
    for(int i=0; i < obs.size(); i++) {
      ob = obs.get(i);
      if (ob.intersect(p))
        return true;
    }
    return false;
  } // end of intersect() for a point


}  // end of Obstacles class