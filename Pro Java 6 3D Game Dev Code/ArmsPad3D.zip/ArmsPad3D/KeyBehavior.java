
// KeyBehavior.java
// Andrew Davison, October 2006, ad@fivedots.coe.psu.ac.th

/* Use key presses to affect the grabbers.
   The code here is much simpler than in other KeyBehavior classes
   since the key codes are converted into GrabberOp objects, which
   are processed inside Grabbers. No translations or rotations are
   executed here.
*/

import java.awt.AWTEvent;
import java.awt.event.*;
import java.util.Enumeration;

import javax.media.j3d.*;



public class KeyBehavior extends Behavior
{
  private WakeupCondition keyPress;
  private Grabbers grabbers;

  public KeyBehavior(Grabbers gs)
  { 
    grabbers = gs;
    keyPress = new WakeupOnAWTEvent(KeyEvent.KEY_PRESSED);  
  }  // end of keyBehavior()


  public void initialize()
  {  wakeupOn( keyPress );  }


  public void processStimulus(Enumeration criteria)
  // respond to a keypress
  {
    WakeupCriterion wakeup;
    AWTEvent[] event;
    GrabberOp gop;

    while( criteria.hasMoreElements() ) {
      wakeup = (WakeupCriterion) criteria.nextElement();
      if( wakeup instanceof WakeupOnAWTEvent ) {
        event = ((WakeupOnAWTEvent)wakeup).getAWTEvent();
        for( int i = 0; i < event.length; i++ ) {
          if( event[i].getID() == KeyEvent.KEY_PRESSED ) {
            gop = new GrabberOp( (KeyEvent)event[i] );  // make a GrabberOp
            if (!gop.isOp(GrabberOp.NONE))
              grabbers.processOp(gop);  // send it to Grabbers for processing
            // else
            //  System.out.println("Ignoring key press");
          }
        }
      }
    }
    wakeupOn( keyPress );
  } // end of processStimulus()


}  // end of KeyBehavior class
