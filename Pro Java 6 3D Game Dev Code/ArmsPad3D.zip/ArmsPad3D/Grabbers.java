
// Grabbers.java
// Andrew Davison, January 2007, ad@fivedots.coe.psu.ac.th

/* Significantly revised from the version in Arms3D. */

/* The grabbers consists of a base, and left and right arms.
   The base can be translated and rotated, using operations in this
   class. The grabber arms have several joints which can be 
   rotated individually, but those operations are handled by Grabber
   instances.

   The grabbers are attached to the camera viewpoint via a PlatformGeometry
   instance (in WrapArmsPad3D), and the base is rotated/translated by
   affecting the viewpoint's targetTG TransformGroup.

   Movement operations may come from the keyboard or a game pad, but 
   arrive as GrabberOp objects.

   An operation is tried out, and if the resulting base or arm positions
   collide with each other, obstacles, or the floor, then the operation
   is undone. This try-and-see technique is employed before the scene is
   rendered, so a move-undo pair won't be seen by the user. The
   user will only see that the grabbers don't move at all.

   A collision with an obstacle triggers the playing of a sound in
   the relevant Obstacle object, and the game pad is made to rumble
   by the rumblePad() method in this class.


   ---------- Changes from Grabbers in the Arms3D example ------

   * key processing replaced by GrabberOp usage;

   * base movement/rotation is applied to targetTG not midPtTG
     (which has been removed);

   * there's no creation of a WakeupOr condition in buildWakeUps() and
     no getJointsWakeup() method to access it;

   * processKey() is replaced by processOp() which examines
     a GrabberOp rather than key press data;

   * The new collision detection algorithm is based around trying
     the operation and testing the resulting Transforms to
     see if they intersect with anything. If they do then the
     transforms are undone, all before the scene is rendered.
     This means that there's no 'stutter' as the base or an
     arm hits something. Instead the user simply sees that the
     grabbers don't move, although a sound is played by the obstacle,
     and the game pad rumbles.

   * The base can translate and rotate; in Arms3D it could
     only translate. The transforms are applied to targetTG
     which is the camera's viewpoint. The grabbers are connected
     to this transform via a platform geometry, so move as
     well.
*/

import java.awt.event.*;
import java.util.*;
import java.text.DecimalFormat;
import java.util.concurrent.*;

import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.image.*;


public class Grabbers
{
  // the grabbers metallic texture
  private final static String TEX_FNM = "images/steel.jpg";

  // used when rotating the base
  private static final double ROT_AMT = Math.PI / 36.0;   // 5 degrees
  private static final double MOVE_STEP = 0.2;

  // hardwired movement vectors used when translating the base
  private static final Vector3d FWD = new Vector3d(0,0,-MOVE_STEP);
  private static final Vector3d BACK = new Vector3d(0,0,MOVE_STEP);
  private static final Vector3d LEFT = new Vector3d(-MOVE_STEP,0,0);
  private static final Vector3d RIGHT = new Vector3d(MOVE_STEP,0,0);
  private static final Vector3d UP = new Vector3d(0,MOVE_STEP,0);
  private static final Vector3d DOWN = new Vector3d(0,-MOVE_STEP,0);

  // used for repeated calcs
  private Transform3D t3d = new Transform3D();
  private Transform3D toMove = new Transform3D();
  private Transform3D toRot = new Transform3D();

  // scene graph elements
  private TransformGroup targetTG;   // the ViewPlatform's transform group
  private TransformGroup grabbersTG;
  private Grabber leftGrabber, rightGrabber;

  private int upMoves = 0;
  private GamePadController gamePad;   // used to switch on rumbling
  private boolean isRumbling = false;
  private ExecutorService rumblerExecutor;


  // private int touchCounter = 1;
  private Obstacles obs;    // obstacles used during collision detection


  private DecimalFormat df = new DecimalFormat("0.##");  // 2 dp



  public Grabbers(Vector3d posnVec, float grabOffset, 
                  TransformGroup targetTG,
                  Obstacles obs, GamePadController gp)
  /*  Build the scene graph for the grabbers:
       grabbersTG ---> leftGrabber's TG
                |---> rightGrabber's TG
      grabbersTG is attached to the cameras viewpoint by WrapArmsPad3D.
  */
  { 
    this.targetTG = targetTG;
    this.obs = obs;
    gamePad = gp;

    Texture2D tex = loadTexture(TEX_FNM);  // used by both grabbers

    // position the grabbers
    t3d.set(posnVec);
    grabbersTG = new TransformGroup(t3d);

    // add the left grabber
    leftGrabber = new Grabber("left", tex, -grabOffset);
    grabbersTG.addChild( leftGrabber.getBaseTG() );

    // add the right grabber
    rightGrabber = new Grabber("right", tex, grabOffset);
    grabbersTG.addChild( rightGrabber.getBaseTG() );

    rumblerExecutor = Executors.newSingleThreadExecutor();
        // create a single worker thread to process rumbler tasks

  }  // end of Grabbers()


  private Texture2D loadTexture(String fn)
  // load image from file fn as a texture
  {
    TextureLoader texLoader = new TextureLoader(fn, null);
    Texture2D texture = (Texture2D) texLoader.getTexture();
    if (texture == null)
      System.out.println("Cannot load texture from " + fn);
    else {
      System.out.println("Loaded texture from " + fn);
      texture.setEnable(true);
    }
    return texture;
  }  // end of loadTexture()


  public TransformGroup getTG()
  // called by WrapArms3D
  {  return grabbersTG;  }


  // -------------- grabber translation and rotation --------------------


  synchronized public void processOp(GrabberOp gop)
  /* Try out the operation with doOp(), then test if it causes a
     collision. If it does then undo the operation, and tell the
     user by making the game pad buzz. 

     The method is synchronized since it may be called by two
     behaviors (KeyBehavior and GamePadBehavior) which may be
     running in separate threads. */
  {
    if (doOp(gop))
      if (isColliding()) {
        rumblePad();
        undoOp(gop);
      }
  } // end of processOp()


  private boolean doOp(GrabberOp gop)
  /* The operation may either affect the grabbers base, or one
     of the grabber arms.
  */
  {
    if (gop.isOp(GrabberOp.NONE))
      return false;

    boolean done = false;

    if (gop.isPart(GrabberOp.BASE)) {
      // System.out.println("Processing base");
      done = affectBase(gop);
    }
    else if (gop.isPart(GrabberOp.LEFT_GRABBER)) {
      // System.out.println("Processing left grabber");
      done = leftGrabber.rotate(gop);
    }
    else if (gop.isPart(GrabberOp.RIGHT_GRABBER)) {
      // System.out.println("Processing right grabber");
      done = rightGrabber.rotate(gop);
    }

    return done;
  }  // end of doOp()


  private boolean affectBase(GrabberOp gop)
  /* Make base forward or backward, 
     rotate left or right, up or down, left or right. 
     Down movement is restricted so the grabbers can't
     descend through the floor.
  */
  { 
    if (gop.isOp(GrabberOp.BASE_FWD))
      doMove(FWD);
    else if (gop.isOp(GrabberOp.BASE_BACK))
      doMove(BACK);
    else if (gop.isOp(GrabberOp.BASE_ROT_LEFT))
      rotateY(ROT_AMT);
    else if (gop.isOp(GrabberOp.BASE_ROT_RIGHT))
      rotateY(-ROT_AMT);
    else if (gop.isOp(GrabberOp.BASE_UP)) {
      upMoves++;
      doMove(UP);
    }
    else if (gop.isOp(GrabberOp.BASE_DOWN)) {
      if (upMoves > 0) {  // don't drop below start height
        upMoves--;
        doMove(DOWN);
      }
      else
        return false;   // since doing nothing
    }
    else if (gop.isOp(GrabberOp.BASE_LEFT))
      doMove(LEFT);
    else if (gop.isOp(GrabberOp.BASE_RIGHT))
      doMove(RIGHT);

    return true;
  }  // end of affectBase()


  private void doMove(Vector3d theMove)
  // move targetTG by the amount in theMove
  { 
    targetTG.getTransform(t3d);   // targetTG is the ViewPlatform's transform group
    toMove.setTranslation(theMove);
    t3d.mul(toMove);
    targetTG.setTransform(t3d);
  } // end of doMove()


  private void rotateY(double radians)
  // rotate about the y-axis of targetTG by radians
  { targetTG.getTransform(t3d);   // targetTG is the ViewPlatform's transform group
    toRot.rotY(radians);
    t3d.mul(toRot);
    targetTG.setTransform(t3d);
  } // end of rotateY()



  private boolean isColliding()
  /* Test for 5 colliding possibilities. 
        * the arms may be touching each other
        * the left or right arm might be touching an obstacle
        * the left or right arm might be touching the ground
  */
  {
    BoundingSphere[] bs = rightGrabber.getArmBounds();
    if (leftGrabber.touches(bs)) {   // arms touching each other?
      // System.out.println((touchCounter++) + ") Arms are touching");
      return true;
    }

    // check the right arm against the obstacles
    if (obs.intersects(bs)) {   
      // System.out.println((touchCounter++) + ") Right Arm hit obstacle");
      return true;
    }

    // check the left arm against obstacles
    bs = leftGrabber.getArmBounds();
    if (obs.intersects(bs)) {
      // System.out.println((touchCounter++) + ") Left Arm hit obstacle");
      return true;
    }

    // are either arms touching the ground?
    if (leftGrabber.touchingGround()) {
      // System.out.println("Left Grabber's fingers are touching the ground");
      return true;
    }

    if (rightGrabber.touchingGround()) {
      // System.out.println("Right Grabber's fingers are touching the ground");
      return true;
    }

    return false;
  }  // end of isColliding()



  private void rumblePad()
  /* Play the rumbler for 0.5 secs if it's not already rumbling, 
     and ignore other rumbler requests until this one has finished. */
  {
    if (!isRumbling)
      rumblerExecutor.execute( new Runnable() {
        public void run() 
        {
          isRumbling = true;
          gamePad.setRumbler(true);
          try {
            Thread.sleep(500);   // wait for 0.5 secs
          }
          catch(InterruptedException ex) {}
          gamePad.setRumbler(false);
          isRumbling = false;
        } // end of run()
      });
  }  // end of rumblePad()



  private void undoOp(GrabberOp gop)
  /* Undo the operation in gop. If gop is a base
     operation then use undoBase(), otherwise reverse
     the rotation operation, and apply it to the relevant
     grabber. */
  {
    if (gop.isPart(GrabberOp.BASE))  // is a base op
      undoBase(gop);
    else {
      GrabberOp revGOP = gop.reverse();  // reverse the rotation op
      if (revGOP.isPart(GrabberOp.LEFT_GRABBER))
        leftGrabber.rotate(revGOP);
      else  // must be right grabber
        rightGrabber.rotate(revGOP);
    }
  }  // end of undoOp()



  private void undoBase(GrabberOp baseGOP)
  /* Look at the grabber op and if it's a base operation
     then do the opposite. This method is used to 'undo'
     the base operation in baseGOP. */
  {
    switch (baseGOP.getOp()) { 
      case GrabberOp.NONE: break;     // do nothing

      case GrabberOp.BASE_FWD: doMove(BACK); break; 
      case GrabberOp.BASE_BACK: doMove(FWD); break;
      case GrabberOp.BASE_LEFT: doMove(RIGHT); break;
      case GrabberOp.BASE_RIGHT: doMove(LEFT); break;
      case GrabberOp.BASE_ROT_LEFT: rotateY(-ROT_AMT); break;
      case GrabberOp.BASE_ROT_RIGHT: rotateY(ROT_AMT); break;
      case GrabberOp.BASE_UP: doMove(DOWN); break;
      case GrabberOp.BASE_DOWN: doMove(UP); break;

      default: System.out.println("Not a base grabber op"); break;
    }
  } // end of undoBase()

}  // end of Grabbers class
