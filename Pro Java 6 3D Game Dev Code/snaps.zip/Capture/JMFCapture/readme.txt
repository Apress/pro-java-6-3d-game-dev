
Chapter 9. Webcam Snaps  -- the JMF example

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2


Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th
  http://fivedots.coe.psu.ac.th/~ad/jg


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

---------------------------------
Example Files:
  * 3 Java files: ShowJPics.java, JPicsPanel.java, JMFCapture.java

---------------------------------
Compilation: 

$ javac *.java
    // you must have JMF installed

JMF is available from http://java.sun.com/products/java-media/jmf/
I installed the JMF Performance Pack for Windows v.2.1.1e 

---------------------------------
Execution: 

$ java ShowJPics


The capture device must be registered with "JMF Registry"
before ShowJPics will see it. You'll find the application below 
the JMF menu item in Windows. See section 5.2. of the chapter for
more details. 

Check the device name using "JMF Registry", and update the 
CAP_DEVICE string in JMFCapture.java accordingly. Currently it
has the value: "vfw:Microsoft WDM Image Capture (Win32):0",
which is a commonly used name in WinXP.

On my test machine, it sometimes takes 5 seconds for the first
picture to appear, but only ~30ms for each subsequent one.

The application 'freezes' for a few seconds when the application's
close box is pressed, to wait for the JMF link to be completely
shut down.

---------
Last updated: 4th March 2007