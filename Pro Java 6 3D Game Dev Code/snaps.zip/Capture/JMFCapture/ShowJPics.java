
// ShowJPics.java
// Andrew Davison, September 2005, ad@fivedots.psu.ac.th

/* Show a sequence of images snapped from a webcam. The aim is to update 
   the images so quickly that the sequence looks like a video.

   This version uses JMF, and there's also a Java-based TWAIN API version.
   This version averages an image update every 35 ms. The TWAIN
   version takes a snap every 4 secs!

   Usage:
      > java ShowJPics
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class ShowJPics extends JFrame 
{
  private JPicsPanel pp;

  public ShowJPics()
  {
    super( "Show JMF Capture Pics" );
    Container c = getContentPane();
    c.setLayout( new BorderLayout() );   

    pp = new JPicsPanel(); // the sequence of snaps appear here
    c.add( pp, "Center");

    addWindowListener( new WindowAdapter() {
      public void windowClosing(WindowEvent e)
      { pp.closeDown();    // stop snapping pics
        System.exit(0);
      }
    });

    pack();  
    setResizable(false);
    setVisible(true);
  } // end of ShowJPics()


  public static void main( String args[] )
  {  new ShowJPics();  }

} // end of ShowJPics class
