
// ShowPics.java
// Andrew Davison, September 2005, ad@fivedots.psu.ac.th

/* Show a sequence of images snapped from a webcam. The aim is to update 
   the images so quickly that the sequence looks like a video.

   This version uses a Java-based TWAIN API, and there's also a JMF version.
   This version averages an image update every 4 seconds! The JMF
   version takes a snap every 35 ms.

   Usage
     - use the JavaTwain.bat file:
       > JavaTwain ShowPics

    - or type the full command line:
      > java -Xbootclasspath/p:D:\morena\morena_license.jar ShowPics

    This says where the Morena license file is located.
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class ShowPics extends JFrame 
{
  private PicsPanel pp;

  public ShowPics()
  {
    super( "Show Twain Pics" );
    Container c = getContentPane();
    c.setLayout( new BorderLayout() );   

    pp = new PicsPanel();   // the sequence of snaps appear here 
    c.add( pp, "Center");

    addWindowListener( new WindowAdapter() {
      public void windowClosing(WindowEvent e)
      { pp.closeDown();  // stop snapping pics
        System.exit(0);
      }
    });

    pack();  
    setResizable(false);
    setVisible(true);
  } // end of ShowPics()


  public static void main( String args[] )
  {  new ShowPics();  }

} // end of ShowPics class

