
// TwainCapture.java
// Andrew Davison, September 2005, ad@fivedots.coe.psu.ac.th

/* TwainCapture uses the Morena Java TWAIN API to access a webcam
   (http://www.gnome.sk/Twain/jtp.html). Morena 6
   is designed for general image acquisition hardware 
   (scanners, cameras), and supports TWAIN and SANE. 

   grabImage() returns a BufferedImage with dimensions (size*size).
   An image takes about 3-4 secs to be 'snapped' on an old Win98
   machine, but the first image may take up to 5-8 secs!

   close() shuts down the TWAIN link.
*/



import java.awt.*;
import javax.swing.*;
import java.awt.image.*;

import SK.gnome.twain.*;


public class TwainCapture
{
  private int size;       // x/y- dimensions of final BufferedImage
  private double scaleFactor;  // snap --> returned image scaling

  private TwainSource source;
  private MediaTracker imageTracker;
  private boolean closedDevice;


  public TwainCapture(int sz)
  {
    size = sz;
    scaleFactor = 0;   // dummy initial value

    source = null;
    imageTracker = new MediaTracker( new JPanel() );
    closedDevice = true;   // since device is not available yet

    source = chooseSource();
    // source = defaultSource();  // simpler alternative 
    System.out.println("Using source " + source);

    // hide the TWAIN source user interface
    source.setVisible(false);
    closedDevice = false;
  }  // end of TwainCapture()


  private TwainSource chooseSource()
  /* Select a source which has a controllable GUI, since 
     the GUI will be made invisible prior to its use. 
     I've found it a good idea to always call TwainManager.close()
     prior to exiting, otherwise the OS can start to act
     strangely after the appl. has terminated.
  */
  {
    TwainSource src = null;
    try {
      if (!TwainManager.isAvailable()) {
        System.out.println("Twain not available");
        close();
        System.exit(1); 
      }

      TwainSource[] srcs = TwainManager.listSources();
      System.out.println("No. of Twain Sources: " + srcs.length);
      if (srcs.length == 0) {    // no sources
        close();
        System.exit(1);
      }

      int guiIdx = -1;   // index position of GUI controllable device
      for (int i=0; i < srcs.length; i++) {
         System.out.println("" + (i+1) + ". Testing " + srcs[i]);
         if (srcs[i].getUIControllable()) {
           guiIdx = i;
           System.out.println("  UI is controllable");
         }
      }
      if (guiIdx == -1) {  // no source is GUI controllable
        System.out.println("No controllable source GUIs");
        close();
        System.exit(1);
      }
      else
        src = srcs[guiIdx];
    }
    catch (TwainException e)
    { System.out.println(e);  
      close();
      System.exit(1);
    }

    if (src == null) {
      close();
      System.exit(1);
    }

    return src;
  }  // end of chooseSource()


  private TwainSource defaultSource()
  // use the default TWAIN source
  {
    TwainSource src = null;
    try { 
      src = TwainManager.getDefaultSource();
    }
    catch (TwainException e)
    { System.out.println(e);
      close();
      System.exit(1);
    }
    return src;
  }  // end of defaultSource()



  synchronized public BufferedImage grabImage()
  // snap an image, then wait for it to be fully loaded
  {
    if (closedDevice)
      return null;

    Image im = Toolkit.getDefaultToolkit().createImage(source);
    imageTracker.addImage(im, 0);
    try {
      imageTracker.waitForID(0);
    }
    catch (InterruptedException e) {
      return null;
    }
    if (imageTracker.isErrorID(0))
      return null;

    return makeBIM(im);
  } // end of grabImage()



  private BufferedImage makeBIM(Image im)
  /* Make a BufferedImage copy of im, assuming no alpha channel.
     Resize it to fit into size dimensions. */
  {
    BufferedImage copy = new BufferedImage(size, size, 
                                        BufferedImage.TYPE_INT_RGB);
                                        // BufferedImage.TYPE_3BYTE_BGR);
      // TYPE_3BYTE_BGR is a BufferedImage format that can support 
      // dynamic texturing in OpenGL v.1.2 (and above) and D3D

    // create a graphics context
    Graphics2D g2d = copy.createGraphics();

    // image --> resized BufferedImage
    setScale(g2d, im);
    g2d.drawImage(im,0,0,null);
    g2d.dispose();
    return copy;
  }  // end of makeBIM()


  private void setScale(Graphics2D g2d, Image im)
  /* Scale the image according to the scaleFactor value, by
     scaling the graphics context instead. */
  {
    if (scaleFactor == 0.0) {  // scale not yet set
      int width = im.getWidth(null);     // get the image's dimensions
      int height = im.getHeight(null);
      if (width > height)
        scaleFactor = ((double) size) / width;
      else
        scaleFactor = ((double) size) / height;
    }
    g2d.scale(scaleFactor, scaleFactor);
  }  // end of setScale()


  synchronized public void close()
  /* close() and grabImage() are synchronized so that it's not
     possible to close down the source while an image is being
     snapped. */
  { 
    try {
      TwainManager.close();
    }
    catch (TwainException e)
    { System.out.println(e); }
    closedDevice = true;
  }  // end of close();


  public boolean isClosed()
  {  return closedDevice;  }

}  // end of TwainCapture class