
Chapter 9. Webcam Snaps  -- the TWAIN example

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th
  http://fivedots.coe.psu.ac.th/~ad/jg


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

---------------------------------
Example Files:
  * 3 Java files: ShowPics.java, PicsPanel.java, TwainCapture.java

---------------------------------
Morena 6.3.2.2

I used a 30-day evaluation copy of Morena 6.3.2.2, a commercial
Java interface for TWAIN, available from
http://www.gnome.sk/Twain/jtp.html

The Windows installation of Morena involves three JAR files:
   morena.jar, morena_windows.jar, and morena_license.jar

They should be added to Java''s classpath, or copied into 
<JAVA_HOME>\jre\lib\ext and <JRE_HOME>\lib\ext.


---------------------------------
Compilation: 

$ javac *.java
    // you must have Morena installed

---------------------------------
Execution: 

$ java ShowPics
    // you must have Morena installed

On my test machine, it sometimes takes 10 seconds for the first
picture to appear, and several seconds for each subsequent one.

The application 'freezes' for a few seconds when the application's
close box is pressed, to wait for the TWAIN link to be completely
shut down.

---------
Last updated: 4th March 2007