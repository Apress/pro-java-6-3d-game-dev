
// ShowPics.java
// Andrew Davison, September 2005, ad@fivedots.psu.ac.th


/* Take a picture every DELAY ms, and show in the panel.
   A good DELAY value can be obtained by looking at the 
   average time for obtaining a snap, which is written at
   the bottom of the panel.

   For Windows 98, the average time is 4 secs, but I've
   set the delay to 1 second, which does no harm except
   that the thread never sleeps.

   The snaps are taken by a thread, which is terminated when the
   running boolean is set to true by closeDown(). closeDown()
   blocks until the run() has called TwainCapture.close() and finished. 
   This avoids nasty OS effects after the application has 
   terminated, but it means that clicking on the close box
   'freezes' the application for 1-2 secs.
*/


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.*;
import java.text.DecimalFormat;
import java.io.*;
import javax.imageio.*;

import SK.gnome.twain.*;


public class PicsPanel extends JPanel implements Runnable
{
  private static final int SIZE = 256;  // x/y- dimensions of panel
  private static final int DELAY = 1000;  // ms  (1 FPS)

  private static final String SAVE_FNM = "c:\\windows/desktop/twainPic.jpg";
      // file location for a saved snap

  private BufferedImage image = null;
  private TwainCapture camera; 
  private boolean running;
  
  // used for the average ms snap time info
  private int imageCount = 0;
  private long totalTime = 0;
  private DecimalFormat df;
  private Font msgFont;


  public PicsPanel()
  {
    setBackground(Color.white);
    Dimension d = new Dimension(SIZE, SIZE);
    setMinimumSize(d);
    setPreferredSize(d);

    df = new DecimalFormat("0.##");  // 2 dp
    msgFont = new Font("SansSerif", Font.BOLD, 18);

    new Thread(this).start();   // start updating the panel's image
  } // end of PicsPanel()



  public void run()
  /* take a picture every DELAY ms */
  {
    camera = new TwainCapture(SIZE);
         // must create Java Twain in same thread that uses it

    long duration;
    BufferedImage im = null;
    running = true;

    while (running) {
	  long startTime = System.currentTimeMillis();
      System.out.println("Start loading image " + (imageCount+1) + "...");
      im = camera.grabImage();   // take a snap
      duration = System.currentTimeMillis() - startTime;

      if (im == null)
        System.out.println("Problem loading image " + (imageCount+1));
      else {
        image = im;   // only update image if im contains something
        imageCount++;
        totalTime += duration;
        System.out.println("Image " + imageCount + " loaded in " +
                            duration + " ms");
        repaint();
      }

      if (duration < DELAY) {
        try {
          Thread.sleep(DELAY-duration);  // wait until DELAY time has passed
        } 
        catch (Exception ex) {}
      }
    }

    // saveSnap(image, SAVE_FNM);   // save last image
    camera.close();   // close down the camera
  }  // end of run()



  public void paintComponent(Graphics g)
  /* Draw the snap and add the average secs snap time at the 
     bottom of the panel. */
  { 
    super.paintComponent(g);
    g.drawImage(image, 0, 0, this);   // draw the snap

    // write stats
	g.setColor(Color.blue);
    g.setFont(msgFont);
    if (imageCount > 0) {
      double avgGrabTime = (double) totalTime / (imageCount*1000);
	  g.drawString("Pic " + imageCount + "  " +
                   df.format(avgGrabTime) + " secs", 
                   5, SIZE-10);  // bottom left
    }
    else  // no image yet
	  g.drawString("Loading...", 5, SIZE-10);
  } // end of paintComponent()


  public void closeDown()
  /* Terminate run() and wait for the camera to be closed.
     This stops the application from exiting until everything
     has finished. */
  { 
    running = false;
    while (!camera.isClosed()) {
      try {
        Thread.sleep(DELAY);
      } 
      catch (Exception ex) {}
    }
  } // end of closeDown()


  private void saveSnap(BufferedImage im, String fnm)
  // Save image as JPG
  {
    System.out.println("Saving image");
    try {
      ImageIO.write(im, "jpg", new File(fnm));
    }
    catch(IOException e)
    {  System.out.println("Could not save image");  }
  }  // end of saveSnap()


} // end of PicsPanel class

