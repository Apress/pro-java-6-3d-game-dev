
Chapter 9. Webcam Snaps

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

---------------------------------

There are two example directories:

JMFCapture/     webcam snaps using JMF (Java Media Framework)
TwainCapture/   webcam snaps using TWAIN

See the readme.txt files in the directories for details on
how to compile and run the examples.

---------
Last updated: 4th March 2007