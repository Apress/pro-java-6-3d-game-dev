
Chapter 11. Building a Game Pad Controller with JInput

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2


Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

=============================================
GamePadViewer

GamePadViewer shows how Swing and JInput can be combined.

The application displays the current position of the game pad's
analog sticks, POV hat, and which buttons are being pressed. It
also allows the device's rumbler to be switched on and off.

GamePadViewer consists of:
  GamePadViewer.java
  ButtonsPanel.java
  CompassPanel.java
  GamePadController.java


=============================================
Software/Hardware You Need

* The JInput API for Windows, available from 
  https://jinput.dev.java.net. Look in the Win32 folder 
  under the "Documents & Files" menu item.
  
* A game pad: the GamePadViewer application assumes there is a 
  device with two analog sticks, a hat, 12 buttons, and rumbler
  support attached to the machine. 

  Read the chapter to see how to check out the game pad in
  Windows and DirectX before you start with JInput.


=============================================
Compilation: 

Use the compileJI.bat batch file.

$ compileJI *.java
    // make sure you have JInput installed

compileJI.bat assumes the JInput library files are located
in d:\jinput\bin. Change the batch file to match where you've
placed the files.

=============================================
Execution: 

Use the runJI.bat batch file.

$ runJI GamePadViewer
    // make sure you have JInput installed

runJI.bat assumes the JInput library files are located
in d:\jinput\bin. Change the batch file to match where you've
placed the files.

---------
Last updated: 4th March 2007