
Chapter 11. Building a Game Pad Controller with JInput

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2


Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

=============================================
Contents of this Directory

* runTest.bat
   - a batch file for running JInput's test applications

* SimpleExamples/
    - three small JInput examples

* GamePadViewer/
    - an example combining Swing and JInput

=============================================
Software/Hardware You Need

* The JInput API for Windows, available from 
  https://jinput.dev.java.net. Look in the Win32 folder 
  under the "Documents & Files" menu item.
  
* A game pad: the GamePadViewer application assumes there is a 
  device with two analog sticks, a hat, 12 buttons, and rumbler
  support attached to the machine. 

  Read the chapter to see how to check out the game pad in
  Windows and DirectX before you start with JInput.


=============================================
Execution of the batch file: 

A tests JAR for JInput is available from https://jinput.dev.java.net
(read the chapter for details).

The JAR contains three test applications, which can be executed
using runTest.bat
    // make sure you have JInput installed;
    // runTest.bat should be in the same directory as the JAR

$ runTest ControllerReadTest

$ runTest ControllerTextTest

$ runTest RumbleTest

runTest.bat assumes the JInput library files are located
in d:\jinput\bin. Change the batch file to match where you've
placed the files.

---------
Last updated: 4th March 2007