
Chapter 17. Picking on the Models

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew


==================================
TourModelsGL

TourModelsGL is a 3D world containing 4 OBJ models, 
which also illustrates picking, 3D sound, and fog. 
The models are loaded with the OBJLoader package, and
the 3D sound uses JOAL. 

The user can navigate around the scene using the arrow keys.
Also, ctrl-left_arrow and ctrl-right_arrow translate the camera
left and right.


What's Here?
------------
- 3 Java files:
  TourModelsGL.java, TourModelsCanvasGL.java, JOALSoundMan.java

- 2 batch files:
  compileGL.bat and runGL.bat

- a Sounds/ directory 
  It contains the penguin audio file:
    * penguin.wav

- a models/ directory
  It contains the 4 OBJ models that are loaded into the scene:
    * a red couch:       couch.obj, couch.mtl
    * a penguin:         penguin.obj, penguin.mtl, penguin.gif
    * a racing car:      formula.obj, formula.mtl, metal.jpg
    * a rose and a vase: rose+vase.obj, rose+vase.mtl

The racing car model comes from Evangelos Pournaras' JautOGL game 
(http://today.java.net/pub/a/today/2006/10/10/development-of-3d-multiplayer-racing-game.html 
and https://jautogl.dev.java.net/).

==================================
Requirements:

* J2SE 5.0 or later from http://java.sun.com/j2se/
  (I use its nanosecond timer, System.nanoTime()).
  I recommend the release version of Java SE 6.

* JOGL, the JSR-231 1.1.0 release candidate 2, from 
  https://jogl.dev.java.net/
  See the readme.txt file in the top-level directory for 
  details on installing it. 

* The JOAL API, available from https://joal.dev.java.net/. 
  Please read section 2.2. of chapter 13
  (http://fivedots.coe.psu.ac.th/~ad/jg2/ch13/)
  for details on how to install them.

* The batch files in this directory, compileGL.bat and runGL.bat
  assume that:
    - the JOGL JAR and DLLs are in d:\jogl 
    - the OBJLoader package is also in d:\jogl,
      stored as the JAR OBJLoader.jar
    - the JOAL JAR is in Java's jre\lib\ext directory
    - the JOAL DLLs are in d:\joal

-----

Compilation: 

1. Use the compileGL.bat batch file.

   $ compileGL *.java

-----
Execution: 

Use the runGL.bat batch file, with the name of the program,
TourModelsGL.

   $ runGL TourModelsGL

-----------
No Fog?

If you want to disable the fog, then comment out the call to
addFog() in initRender() in TourModelsCanvasGL.java.

-----------
Last updated: 4th March 2007