
// JOALSoundMan.java
// Andrew Davison, January 2007, ad@fivedots.coe.psu.ac.th

/*  Maintain hashmaps of sound buffers/sources and a listener 
    using the JOAL API (https://joal.dev.java.net/).
    
    Any sound can be played, paused, stopped.
    The (x,y,z) position of a sound can be changed.

    The (x,z) position of the listener, and its angle to the -z axis 
    can be changed.

    The cleanUp() method closes the object down at termination time.
*/

import java.awt.*;
import java.util.*;
import java.text.DecimalFormat;
import java.io.*;
import java.nio.ByteBuffer;

import net.java.games.joal.*;
import net.java.games.joal.util.*;



public class JOALSoundMan
{
  private final static String SOUND_DIR = "Sounds/";  
             // where the WAV files are located

  private DecimalFormat df = new DecimalFormat("0.##");  // 2 dp

  private AL al;  // to access the JOAL API

  private HashMap<String, int[]> buffersMap;  
  private HashMap<String, int[]> sourcesMap;  
    // store for the sounds: (name, buffer) and (name, source) pairs

  // listener info
  private float xLis, yLis, zLis;    // current position
  private float[] oriLis;   // orientation
  private int angleLis = 0;
    // anti-clockwise rotation anyway from -z axis


  public JOALSoundMan()
  {
    buffersMap = new HashMap<String, int[]>();
    sourcesMap = new HashMap<String, int[]>();

    initOpenAL();
    initListener();
  } // end of JOALSoundMan()


  private void initOpenAL()
  // set up the link to OpenAL (OpenAL Utility Toolkit) via JOAL
  {
    try {
      ALut.alutInit();  
          /* creates an OpenAL context and makes it current on 
             the current thread. */
      al = ALFactory.getAL();   // to access OpenAL 
      al.alGetError();          // clear any error bits

      // System.out.println("JOAL version: " + Version.getVersion());
                  // Version class not in v.1.1.0
    }
    catch (ALException e) {
      e.printStackTrace();
      System.exit(1);
    }
  } // end of initOpenAL()



  private void initListener()
  // position the listener at (0,0,0) facing towards (0,0,-1)
  {
    xLis = 0.0f; yLis  = 0.0f; zLis = 0.0f; 
    al.alListener3f(AL.AL_POSITION, xLis, yLis, zLis);  // position at origin
    al.alListener3i(AL.AL_VELOCITY, 0, 0, 0);   // no velocity

    // the first 3 elems are "look at", second 3 are "up direction"
    // face along -z axis, with up being the +y axis
    oriLis = new float[] {xLis, yLis, zLis-1.0f,  0.0f, 1.0f, 0.0f};
    al.alListenerfv(AL.AL_ORIENTATION, oriLis, 0);
  } // end of initListener()



  // --------------- source methods -----------------------------


  public boolean load(String nm, boolean toLoop)
  /* load the sound as a buffer, then use it to initialize a
     OpenAL source. Store the sound name and buffer & source in 
     hash maps. */
  {
    if (sourcesMap.get(nm) != null) {
      System.out.println(nm + " already loaded");
      return true;
    }

    int[] buffer = initBuffer(nm);
    if (buffer == null)
      return false;

    int[] source = initSource(nm, buffer, toLoop);
    if (source == null) {
      al.alDeleteBuffers(1, buffer, 0); // no need for the buffer anymore
      return false;
    }

    if (toLoop)
      System.out.println("Looping source created for " + nm);
    else
      System.out.println("Source created for " + nm);

    buffersMap.put(nm, buffer);
    sourcesMap.put(nm, source);
    return true;
  } // end of loadSource()



  private int[] initBuffer(String nm)
  /* Create a buffer for the sound. A buffer is a collection of
     various WAV data, which is loaded first, then used to 
     initialize the buffer. */
  {
    // create arrays for holding various WAV file info
    int[] format = new int[1];
    ByteBuffer[] data = new ByteBuffer[1];
    int[] size = new int[1];
    int[] freq = new int[1];
    int[] loop = new int[1];

    // load WAV file into the data arrays
    String fnm = SOUND_DIR + nm + ".wav";
    try {
      ALut.alutLoadWAVFile(fnm, format, data, size, freq, loop);
    }
    catch(ALException e) {
      System.out.println("Error loading WAV file: " + fnm);
      return null;
    }
    // System.out.println("Sound size = " + size[0]);
    // System.out.println("Sound freq = " + freq[0]);


    // create an empty buffer to hold the sound data
    int[] buffer = new int[1];   // 
    al.alGenBuffers(1, buffer, 0);
    if (al.alGetError() != AL.AL_NO_ERROR) {
      System.out.println("Could not create a buffer for " + nm);
      return null;
    }

    // store data in the buffer
    al.alBufferData(buffer[0], format[0], data[0], size[0], freq[0]);

    // ALut.alutUnloadWAV(format[0], data[0], size[0], freq[0]);   // not in API anymore
    return buffer;
  }  // end of initBuffer()



  private int[] initSource(String nm, int[] buf, boolean toLoop)
  /* Use the sound buffer to initailize a sound source.
     The source is positioned at (0,0,0) with no velocity.
     The sound may play looping, depending on toLoop.
  */
  {
    // create a source (a point in space that emits a sound)
    int[] source = new int[1]; 
    al.alGenSources(1, source, 0);
    if (al.alGetError() != AL.AL_NO_ERROR) {
      System.out.println("Error creating source for " + nm);
      return null;
    }

    // configure source, positioned at (0,0,0)
    al.alSourcei(source[0], AL.AL_BUFFER, buf[0]);  // bind buffer
    al.alSourcef(source[0], AL.AL_PITCH, 1.0f);
    al.alSourcef(source[0], AL.AL_GAIN, 1.0f);
    al.alSource3f(source[0], AL.AL_POSITION, 0.0f, 0.0f, 0.0f);  // posn at origin
    al.alSource3i(source[0], AL.AL_VELOCITY, 0, 0, 0);  // no velocity
    if (toLoop)
      al.alSourcei(source[0], AL.AL_LOOPING, AL.AL_TRUE);  // looping sound
    else
      al.alSourcei(source[0], AL.AL_LOOPING, AL.AL_FALSE);  // not looping

    if (al.alGetError() != AL.AL_NO_ERROR) {
      System.out.println("Error configuring source for " + nm);
      return null;
    }

    return source;
  } // end of initSource()



  public boolean setPos(String nm, float x, float y, float z)
  // move the nm sound to (x,y,z)
  {
    int[] source = (int[]) sourcesMap.get(nm);
    if (source == null) {
      System.out.println("No source found for " + nm);
      return false;
    }

   // System.out.println("Moving source for " + nm + " to (" +
   //           df.format(x) + ", " + df.format(y) + ", " + df.format(z) + ")");
   al.alSource3f(source[0], AL.AL_POSITION, x, y, z);
   return true;
  }  // end of setPos()



  public boolean load(String nm, float x, float y, float z, boolean toLoop)
  { 
    if (load(nm, toLoop))
      return setPos(nm, x, y, z);
    else
      return false;
  }  // end of load() with (x,y,z) pos



  public boolean play(String nm)
  // play/resume the nm sound
  {
    int[] source = (int[]) sourcesMap.get(nm);
    if (source == null) {
      System.out.println("No source found for " + nm);
      return false;
    }

    System.out.println("Playing " + nm);
    al.alSourcePlay(source[0]);
    return true;
  }  // end of play()


  public boolean stop(String nm)
  // stop the nm sound playing
  {
    int[] source = (int[]) sourcesMap.get(nm);
    if (source == null) {
      System.out.println("No source found for " + nm);
      return false;
    }

    System.out.println("Stopping " + nm);
    al.alSourceStop(source[0]);
    return true;
  }  // end of stop()


  public boolean pause(String nm)
  // pause the nm sound from playing
  {
    int[] source = (int[]) sourcesMap.get(nm);
    if (source == null) {
      System.out.println("No source found for " + nm);
      return false;
    }

    System.out.println("Pausing " + nm);
    al.alSourcePause(source[0]);
    return true;
  }  // end of pause()



  // --------------------- listener methods ---------------------

  public void moveListener(float xStep, float zStep)
  // move the listener by (x,z) step (y is always 0, on the floor)
  {
    float x = xLis + xStep;  
    float z = zLis + zStep;
    setListenerPos(x, z);
  }  // end of moveListener()


  public void setListenerPos(float xNew, float zNew)
  // position the listener at (xNew,zNew) (y is always 0, on the floor)
  {
    float xOffset = xNew-xLis;
    float zOffset = zNew-zLis;

    xLis = xNew;  zLis = zNew;
    // System.out.println("Moving listener to (x,z): (" +
    //          df.format(xLis) + ", " + df.format(zLis) + ")");
    al.alListener3f(AL.AL_POSITION, xLis, yLis, zLis);

    /* keep the listener facing the same direction by
       moving the "look at" point by the (x,z) offset */
    oriLis[0] += xOffset; 
    oriLis[2] += zOffset;
       // no change needed to y-coord in oriLis[1]
    // System.out.println("Facing (x,z): (" + 
    //                         df.format(oriLis[0]) + ", " + 
    //                         df.format(oriLis[2]) + ")");
    al.alListenerfv(AL.AL_ORIENTATION, oriLis, 0);
  }  // end of setListenerPos()


  public float getX()
  { return xLis; }

  public float getZ()
  { return zLis; }


  public void turnListener(int degrees)
  // turn the listener anti-clockwise by degrees
  {  setListenerOri( angleLis+degrees ); } 


  public void setListenerOri(int ang)
  /* Set the listener's orientation to ang degrees
     (in the anti-clockwise direction around the y-axis) */
  {
    angleLis = ang;

    double angle = Math.toRadians(angleLis);
    float xLen = -1.0f * (float) Math.sin(angle);
    float zLen = -1.0f * (float) Math.cos(angle);
    // System.out.println(angleLis + ") turn (x,z): (" + df.format(xLen) + 
    //                              ", " + df.format(zLen) + ")");

    /* face in the (xLen, zLen) direction by adding the
       values to the listener position */
    oriLis[0] = xLis+xLen; oriLis[2] = zLis+zLen;
    // System.out.println(angleLis + ") facing (x,z): (" + 
    //                         df.format(oriLis[0]) + ", " + 
    //                         df.format(oriLis[2]) + ")");
    al.alListenerfv(AL.AL_ORIENTATION, oriLis, 0);
  }  // end of setListenerOri()


  public int getAngle()
  { return angleLis; }


  // -------------------------- finish --------------------------

  public void cleanUp()
  // delete all the source and buffers in the hash maps
  {
    Set<String> keys = sourcesMap.keySet(); 
    Iterator<String> iter = keys.iterator(); 

    String nm;
    int[] buffer, source;
    while(iter.hasNext()){ 
      nm = iter.next();

      source = sourcesMap.get(nm); 
      System.out.println("Stopping " + nm);
      al.alSourceStop(source[0]);
      al.alDeleteSources(1, source, 0);

      buffer = buffersMap.get(nm); 
      al.alDeleteBuffers(1, buffer, 0); 
    }

    ALut.alutExit();
  } // end of cleanUp()


} // end of JOALSoundMan class
