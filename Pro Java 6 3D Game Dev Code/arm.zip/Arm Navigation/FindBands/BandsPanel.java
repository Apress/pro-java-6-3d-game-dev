
// BandsPanel.java
// Andrew Davison, October 2005, ad@fivedots.psu.ac.th

/* A BandAnalyzer object is created, which analyzes pictures
   taken by a webcam of the user's arm, and draws the 
   resulting images into this panel.
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.*;
import java.text.DecimalFormat;


public class BandsPanel extends JPanel
{
  private static final int SIZE = 256;  // x/y- dimensions of capture image


  private BandsAnalyzer ba;

  private BufferedImage image = null;
  
  // used for reporting the average processing time info
  private int imageCount = 0;
  private long totalTime = 0;
  private DecimalFormat df;
  private Font msgFont;



  public BandsPanel()
  {
    setBackground(Color.white);
    Dimension d = new Dimension(SIZE, SIZE);
    setMinimumSize(d);
    setPreferredSize(d);

    df = new DecimalFormat("0.#");  // 1 dp
    msgFont = new Font("SansSerif", Font.BOLD, 18);

    ba = new BandsAnalyzer(this, SIZE);
    ba.start();   // start responding to user arm movements
  } // end of BandsPanel()


  public void closeDown()
  // terminate analyzer
  {  ba.closeDown();  }


  public void showImage(BufferedImage im, long duration)
  /* Update the image (and related stats) in the panel.
     This method is called from BandsAnalyzer, inside its
     run() loop. */
  {
    image = im;
    imageCount++;
    totalTime += duration;
    repaint();
  }  // end of showImage()



  public void paintComponent(Graphics g)
  /* Draw the snap and show the average processing time at the 
     bottom of the panel. */
  { 
    super.paintComponent(g);
    g.drawImage(image, 0, 0, this);   // draw the snap

    // write stats
	g.setColor(Color.blue);
    g.setFont(msgFont);
    if (imageCount > 0) {
      double avgGrabTime = (double) totalTime / imageCount;
	  g.drawString("Pic " + imageCount + "  " +
                   df.format(avgGrabTime) + " ms", 
                   5, SIZE-10);  // bottom left
    }
    else  // no image yet
	  g.drawString("Loading...", 5, SIZE-10);
  } // end of paintComponent()


} // end of BandsPanel class

