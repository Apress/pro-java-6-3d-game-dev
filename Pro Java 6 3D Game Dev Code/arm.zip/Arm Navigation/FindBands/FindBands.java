
// FindBands.java
// Andrew Davison, October 2005, ad@fivedots.coe.psu.ac.th

/* The user moves their left arm in
   front of a webcam. The user should be wearing a coloured
   strap on their arm containing three coloured bands.

   The camera takes pictures of the strap, and depending
   on the visible band, and the strap's position, 
   rotation or translation command messages are printed out.

   The analyzed webcam image is shown in a JPanel to indicate
   the amount of processing being carried out. The average
   amount of time (in ms) for image snapping and processing is
   also reported. On my test Win XP and 98 machines, the average
   is around 90 ms.

   FindBands is a test rig for checking the camera's positioning, 
   and the choice of colours on the strap. Once FindBands is
   working correctly, the band colours (defined as constants
   in the BandsAnalyzer class) can be added to the version of
   the BandsAnalyzer class used by the BandsCheckers3D 
   application.
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class FindBands extends JFrame 
{
  private BandsPanel bp;

  public FindBands()
  {
    super("Find Bands");
    Container c = getContentPane();
    c.setLayout( new BorderLayout() );   

    bp = new BandsPanel();
    c.add( bp, "Center");

    addWindowListener( new WindowAdapter() {
      public void windowClosing(WindowEvent e)
      { bp.closeDown();    // stop snapping pics
        System.exit(0);
      }
    });

    pack();  
    setResizable(false);
    setVisible(true);
  } // end of FindBands()


  public static void main( String args[] )
  {  new FindBands();  } 

} // end of FindBands class

