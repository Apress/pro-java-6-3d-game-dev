
Chapter 10. Navigating a 3D Scene by Waving Your Arm

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th
  http://fivedots.coe.psu.ac.th/~ad/jg


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

---------------------------------
Contents:

  * BandObjView3D/ directory
      -- contains the BandObjView3D application
      -- try this _after_ getting FindBands working

  * FindBands/ directory
      -- contains the FindBands application
      -- get this working first, before trying BandObjView3D

  * wristBand.gif
      -- a copy of my wrist band
   

  BandObjView3D/ Contents:
  * 11 Java files: BandObjView3D.java, WrapBandObjView3D.java,
                   CheckerFloor.java, ColouredTiles.java,
                   ModelLoader.java, GroundShape.java,
                   BandsAnalyzer.java, BandManager.java,
                   Blob.java, JMFCapture.java, Mover.java
                  JMFCapture.java, Mover.java, WrapBandObjView3D.java
    and two subdirectories: Models/ and images/

  FindBands/ Contents:
  * 6 Java files: BandManager.java, BandsAnalyzer.java, 
                  BandsPanel.java,
                  Blob.java, FindBands.java, JMFCapture.java


---------------------------------
Compilation for FindBands and BandObjView3D: 

cd to the relevant directory, and:

$ javac *.java
    /* You must have JMF installed for FindBands
       and JMF and Java 3D for BandObjView3D (see notes below) */

---------------------------------
Execution:

In the relevant directory:

$ java FindBands
    // you must have JMF installed;
    // see the "Testing Hints" note below

$ java BandObjView3D
    // you must have Java 3D and JMF installed;
    // don't try this until FindBands is working


---------------------------------
Testing Hints

* Get FindBands working before you try BandObjView3D.

* Use the same hardware configuration as in the chapter: 
  a webcam near the user's left arm. Even minor changes 
  will affect your chances of success. 

* Image processing is a tricky thing to get working. You will
  probably have to experiment with different coloured bands on
  the wrist strap. You may have to adjust other constants in
  the code, such as MAX_DIST2 in BandManager.

* Read the chapter for lots of hints about testing.

* Make notes of any changes you make to the classes in FindBands,
  so you can make the same changes to the classes in BandObjView3D.


---------------------------------
Notes on Java 3D

Java 3D is available from https://java3d.dev.java.net/

The 3D world used in BandObjView3D is based on ObjView3D,
which is explained in Chapter 7 of "Pro Java 6 3D game Development",
at http://fivedots.coe.psu.ac.th/~ad/jg2.


---------------------------------
Notes on JMF and Webcams

JMF is available from http://java.sun.com/products/java-media/jmf/
I installed the JMF Performance Pack for Windows v.2.1.1e 

A lot of information about JMF and Webcams can be found in 
Chapter 28.7 at http://fivedots.coe.psu.ac.th/~ad/jg.
The JMFCapture class is explained in that chapter.

The webcam must be registered with "JMF Registry"
before FindBands or BandObjView3D can see it. 
You'll find the registry application below the JMF menu 
item in Windows. 


---------
Last updated: 4th March 2007