
// Mover.java
// Andrew Davison, October 2006, ad@fivedots.coe.psu.ac.th

/* Move the user's viewpoint.
   Movement is restricted to: forward, rotate left, rotate right.
*/

import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.universe.*;


public class Mover
{
  private static final double ROT_AMT = Math.PI / 36.0;   // 5 degrees
  private static final double MOVE_STEP = 0.2;

  // forward movement vector
  private static final Vector3d FWD = new Vector3d(0,0,-MOVE_STEP);

  private TransformGroup targetTG;  // the viewpoint TG

  // for repeated calcs
  private Transform3D t3d = new Transform3D();
  private Transform3D toMove = new Transform3D();
  private Transform3D toRot = new Transform3D();


  public Mover(TransformGroup tarTG)
  {  
    targetTG = tarTG;
    doMove( new Vector3d(0, 0.5, 5.0) );   // starting position
  } // end of Mover()


  /* forward(), rotateLeft(), and rotateRight() are called from
     BandsAnalyzer depending on information it extracts from 
     a webcam image. */

  public void forward()
  {  doMove(FWD);  }

  public void rotateLeft()
  {  rotateY(ROT_AMT);  }

  public void rotateRight()
  {  rotateY(-ROT_AMT);  }


  private void rotateY(double radians)
  // rotate about y-axis by radians
  { targetTG.getTransform(t3d);
    toRot.rotY(radians);
    t3d.mul(toRot);
    targetTG.setTransform(t3d);
  } // end of rotateY()


  private void doMove(Vector3d theMove)
  { targetTG.getTransform(t3d);
    toMove.setTranslation(theMove);
    t3d.mul(toMove);
    targetTG.setTransform(t3d);
  } // end of doMove()

}  // end of Mover class
