
// BandObjView3D.java
// Andrew Davison, October 2006, ad@fivedots.coe.psu.ac.th

/* The world consists of a checkboard floor, 
   with a red center square, and labelled XZ axes.

   The floor is populated with models and ground shapes. The
   ground shape images rotate around their y-axis to face
   the viewer. The background is a texture-wrapped sphere.

   The user moves through the scene by moving their left arm in
   front of a webcam. The user should be wearing a coloured
   strap on their arm containing three coloured bands.

   The camera takes pictures of the strap, and depending
   on the visible band, and the strap's position, the 
   user's viewpoint rotates/moves.
   
   *** IMPORTANT ***
   The camera's positioning, and the choice of colours on the strap,
   should be tested and configured using the FindBands application
   before BandCheckers3D is started. 
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class BandObjView3D extends JFrame
{
  private WrapBandObjView3D w3d;

  public BandObjView3D() 
  {
    super("BandObjView3D");
    Container c = getContentPane();
    c.setLayout( new BorderLayout() );
    w3d = new WrapBandObjView3D();  // panel holding the 3D canvas
    c.add(w3d, BorderLayout.CENTER);

    addWindowListener( new WindowAdapter() {
      public void windowClosing(WindowEvent e)
      { w3d.closeDown();    // stop snapping pics
        System.exit(0);
      }
    });

    pack();
    setResizable(false);    // fixed size display
    setVisible(true);
  } // end of BandObjView3D()


// -----------------------------------------

  public static void main(String[] args)
  {  new BandObjView3D(); }

} // end of BandObjView3D class
