
// JointsBehavior.java
// Andrew Davison, June 2006, ad@fivedots.coe.psu.ac.th

/* Check for potential collisions when specified TransformGroups
   change.
*/

import java.awt.event.*;
import java.awt.*;
import java.util.Enumeration;

import javax.media.j3d.*;



public class JointsBehavior extends Behavior
{
  private WakeupOr jointsWakeup;   // any one of the joint TGs can trigger checking
  private Grabbers grabbers;


  public JointsBehavior(Grabbers gs)
  { 
    grabbers = gs;
    jointsWakeup = grabbers.getJointsWakeup();
  }  // end of JointsBehavior()


  public void initialize()
  { wakeupOn( jointsWakeup ); }


  public void processStimulus(Enumeration criteria)
  {
    WakeupCriterion wakeup;
    TransformGroup tg;

    while( criteria.hasMoreElements() ) {
      wakeup = (WakeupCriterion) criteria.nextElement();
      if( wakeup instanceof WakeupOnTransformChange ) {
        // reportTG(wakeup);
        grabbers.checkForCollision();
        grabbers.checkTouching();
      }
    }
    wakeupOn( jointsWakeup );
  } // end of processStimulus()


  private void reportTG(WakeupCriterion wakeup)
  /* Useful for debugging: print the name of the collision joint which
     triggered the collision checking. */
  { 
    TransformGroup jointTG = ((WakeupOnTransformChange)wakeup).getTransformGroup();
    String name = (String) jointTG.getUserData();
    if (name == null)
      System.out.println("Joint has no name");
    else
      System.out.println(name + " moved");
  } // end of reportTG()


} // end of JointsBehavior class
