
// Arms3D.java
// Andrew Davison, July 2006, ad@fivedots.coe.psu.ac.th

/* Two moveable arms (grabbers), which can be move over the XZ plane 
   together. Also, each grabber can rotate as its elbow and fingers.

   A grabber can rotate through the floor, but reports when
   it does so. The grabbers cannot pass through each other.

   The checkboard floor has a red center square, and labelled XZ axes.
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Arms3D extends JFrame
{
  public Arms3D() 
  {
    super("Arms3D");
    Container c = getContentPane();
    c.setLayout( new BorderLayout() );
    WrapArms3D w3d = new WrapArms3D();     // panel holding the 3D canvas
    c.add(w3d, BorderLayout.CENTER);

    setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    pack();
    setResizable(false);    // fixed size display
    setVisible(true);
  } // end of Arms3D()


// -----------------------------------------

  public static void main(String[] args)
  { new Arms3D(); }

} // end of Arms3D class
