
Chapter 4. The Colliding Grabbers

From:
  Pro Java 6 3D Game Development
  Andrew Davison
  Apress, April 2007
  ISBN: 1590598172 
  http://www.apress.com/book/bookDisplay.html?bID=10256
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg2


Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew


==================================
Files and directories here:

  * Arms3D.java, WrapArms3D.java, Grabbers.java, Grabber.java,
    GrabberBounds.java, KeyBehavior.java, JointsBehavior.java,
    CheckerFloor.java, ColouredTiles.java    
       // 9 Java files

  * images/	// a directory holding a single texture
      - steel.jpg

==================================
Requirements:

* J2SE 5.0 from http://java.sun.com/j2se/1.5.0/index.jsp

* Java 3D 1.4.0 (or 1.3.2) from https://java3d.dev.java.net/

==================================
Compilation: 
  $ javac *.java

Execution: 
  $ java Arms3D

==================================
What Keys Operate the Grabbers?

  x	// turn the left grabber's forearm left
  y	// make the left grabber's forearm rotate up
  z     // make the left grabber's forearm rotate clockwise
  f	// open the left grabber's fingers

  All the rotations have limits, after which further rotations
  in the same direction will be ignored.

  <alt> with x, y, z, or f
        // do the opposite rotation for the left grabber

  <shift> with x, y, z, of f
        // same as x, y, z, or f, but for the right grabber

  <shift> and <alt> with x, y, z, of f
        // same as <alt> x, y, z, or f, but for the right grabber

  the arrow keys 
        // translate both grabbers forwards, backwards, left, or right

You can move the camera using Java 3D's OrbitBehavior controls
to pan, rotate, and zoom.

-----------
Last updated: 3rd March 2007