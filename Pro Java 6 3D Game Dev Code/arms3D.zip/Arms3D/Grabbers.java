
// Grabbers.java
// Andrew Davison, June 2006, ad@fivedots.coe.psu.ac.th

/* The grabbers consist of a left and right grabber, whose joints can be
   rotated individually. The two grabbers can also be translated 
   as a single entity left/right/forwards/backwards
   over the XZ plane. The translation code is stored in this
   class, but the joint rotations are handled by the Grabber
   instances.

   Grabbers gets the collision joints for each grabber, and 
   converted them into a single WakeupOr condition. It's 
   used by JointsBehavior to check for collisions when one of the
   collision joints move.

   Grabbers contains collision detection and response code.
   A joints rotation which may have caused a collision will make
   JointsBehavior to call checkCollsions(). Until the rotation
   has been checked, moveNeedsChecking will be true. This boolean will
   stop joints movement commands sent by KeyBehavior
   from being processed.

   The collision response is to 'undo' the offending joint rotation
   by rotating in the opposite direction.
*/

import java.awt.event.*;

import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.image.*;


public class Grabbers
{
  private final static String TEX_FNM = "images/steel.jpg";

  private final static float STEP = 0.1f;      // step size for moving the base

  // for translating the grabbers
  private final static int forwardKey = KeyEvent.VK_DOWN;
  private final static int backKey = KeyEvent.VK_UP;
  private final static int leftKey = KeyEvent.VK_LEFT;
  private final static int rightKey = KeyEvent.VK_RIGHT;

  // for rotating a grabber's joints
  private final static int rotXKey = KeyEvent.VK_X;
  private final static int rotYKey = KeyEvent.VK_Y;
  private final static int rotZKey = KeyEvent.VK_Z;

  // for rotating a grabber's fingers
  private final static int rotfinKey = KeyEvent.VK_F;

  // reusable objects for calculations
  private Transform3D t3d, toMove;
  private Vector3f moveVec;  

  // scene graph elements
  private BranchGroup grabbersBG;
  private TransformGroup midPtTG;
  private Grabber leftGrabber, rightGrabber;

  // for collision detection
  private WakeupOr jointsWakeup;
  private boolean moveNeedsChecking = false;
  private int touchCounter = 1;

  // stores last key command for moving a joint
  private int keyCode;
  private boolean isShift, isAlt;


  public Grabbers(Vector3f posnVec, float grabOffset)
  /*  
    Build the scene graph for the grabbers:
       grabbersBG --> midPtTG --> leftGrabber's TG
                            |---> rightGrabber's TG

    Translations are applied to midPtTG to make both grabbers
    move.
  */
  { 
    t3d = new Transform3D();
    toMove = new Transform3D();
    moveVec = new Vector3f();

    grabbersBG = new BranchGroup();

    // position the grabbers midpoint at posnVec
    t3d.set(posnVec); 
    midPtTG = new TransformGroup(t3d);
    midPtTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
    midPtTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
    grabbersBG.addChild(midPtTG);

    Texture2D tex = loadTexture(TEX_FNM);  // used by both grabbers

    // add the grabber left of the midpoint
    leftGrabber = new Grabber("left", tex, -grabOffset);
    midPtTG.addChild( leftGrabber.getBaseTG() );

    // add the grabber right of the midpoint
    rightGrabber = new Grabber("right", tex, grabOffset);
    midPtTG.addChild( rightGrabber.getBaseTG() );

    buildWakeUps();
  }  // end of Grabbers()


  private Texture2D loadTexture(String fn)
  // load image from file fn as a texture
  {
    TextureLoader texLoader = new TextureLoader(fn, null);
    Texture2D texture = (Texture2D) texLoader.getTexture();
    if (texture == null)
      System.out.println("Cannot load texture from " + fn);
    else {
      System.out.println("Loaded texture from " + fn);
      texture.setEnable(true);
    }
    return texture;
  }  // end of loadTexture()



  private void buildWakeUps()
  /* Collect the joint TGs that may cause collisions into a single
     WakeupOr condition consisting of WakeupOnTransformChange
     criteria. This will be used by JointsBehavior.
  */
  {
    TransformGroup[] leftJoints = leftGrabber.getCollisionJoints();
    TransformGroup[] rightJoints = rightGrabber.getCollisionJoints();

    WakeupOnTransformChange[] jointCriteria = 
      new WakeupOnTransformChange[leftJoints.length + rightJoints.length];

    // fill the criteria array with the TGs from both grabbers
    int i = 0;
    for (int j=0; j < leftJoints.length; j++) {
      jointCriteria[i] = new WakeupOnTransformChange( leftJoints[j]);
      i++;
    }
    for (int j=0; j < rightJoints.length; j++) {
      jointCriteria[i] = new WakeupOnTransformChange( rightJoints[j]);
      i++;
    }

    jointsWakeup = new WakeupOr(jointCriteria);  // make the condition
  }  // end of buildWakeUps()


  public BranchGroup getBG()
  // called by WrapArms3D
  {  return grabbersBG;  }


  public WakeupOr getJointsWakeup()
  // called by JointsBehavior
  {  return jointsWakeup;  }



  // -------------- grabber translation and rotation --------------------

  public void processKey(int keyCode, boolean isShift, boolean isAlt)
  /* Try to move the grabbers midpoint. If the keyCode isn't a translation then 
     try to rotate a grabber joint, but only if the previous 
     joints move doesn't need checking. This method is called by KeyBehavior. 
  */
  {
    if (!moveMidPt(keyCode) && !moveNeedsChecking)
      rotateJoint(keyCode, isShift, isAlt);
  }  // end of processKey()


  private boolean moveMidPt(int keyCode)
  // move the grabbers' midpoint if the keyCode is the right type
  {
    if(keyCode == forwardKey) {
      moveBy(0, STEP);
      return true;
    }
    if(keyCode == backKey) {
      moveBy(0, -STEP);
      return true;
    }
    if(keyCode == leftKey) {
      moveBy(-STEP, 0);
      return true;
    }
    if(keyCode == rightKey) {
      moveBy(STEP, 0);
      return true;
    }
    // not a move keyCode
    return false;
  }  // end of moveMidPt()


  private void moveBy(float x, float z)
  // move the midpoint by an (x,z) offset
  {
    moveVec.set(x,0,z);
    midPtTG.getTransform(t3d);
    toMove.setTranslation(moveVec);
    t3d.mul(toMove);
    midPtTG.setTransform(t3d);
  }  // end of moveBy()


  private void rotateJoint(int keyCode, boolean isShift, boolean isAlt)
  /* decide which grabber should be affected, and the direction
     of the rotation */
  {
    // store the joint-movement key information
    this.keyCode = keyCode;
    this.isShift = isShift;
    this.isAlt = isAlt;
    // System.out.println("Stored: " + keyCode + " s/a: " + isShift + "/" + isAlt);

    // SHIFT means the right grabber
    Grabber grabber = (isShift) ? rightGrabber : leftGrabber;

    if(isAlt)   // ALT means a negative rotation
      rotJoint(grabber, keyCode, Grabber.NEG);
    else
      rotJoint(grabber, keyCode, Grabber.POS);
  }  // end of rotateJoint()


  private void rotJoint(Grabber grabber, int keycode, int dir)
  /* Depending on the keyCode, try to rotate a particular joint
     (X_JOINT, Y_JOINT, Z_JOINT, or FING_JOINT) in the specified
     grabber. 

     If either the
     X_JOINT or Y_JOINT are moved, then moveNeedsChecking is set to 
     true. This will prevent further joint-movement keys from being
     processed until the move has been checked by JointsBehavior
     calling checkForCollision().
   */
  {
    boolean done;
    if(keycode == rotXKey) {
      done = grabber.rotate(Grabber.X_JOINT, dir);
      if (done)
        moveNeedsChecking = true;  // move needs checking
    }
    else if(keycode == rotYKey) {
      done = grabber.rotate(Grabber.Y_JOINT, dir);
      if (done)
        moveNeedsChecking = true;
    }
    else if(keycode == rotZKey)
      grabber.rotate(Grabber.Z_JOINT, dir);
    else if(keycode == rotfinKey)
      grabber.rotate(Grabber.FING_JOINT, dir);
  } // end of rotJoint()


  // ---------------- collision detection and response --------------------

  public void checkForCollision()
  /* If the previous joints rotation key might have caused a collision, then
     JointsBehavior will be triggered. It calls this method to 
     check whether the move did indeed cause a collision. It undoes it 
     by executing the reverse rotation.
  */
  {
    // System.out.println("Checking for collsion");

    // SHIFT means the right grabber
    Grabber grabber = (isShift) ? rightGrabber : leftGrabber;

    BoundingSphere[] bs = rightGrabber.getArmBounds();
    if (leftGrabber.touches(bs)) {
      System.out.println((touchCounter++) + ") Arms are touching");

      // reverse the previous joints-movement operation
      if(isAlt)
        rotJoint(grabber, keyCode, Grabber.POS);   // was NEG
      else
        rotJoint(grabber, keyCode, Grabber.NEG);   // was POS
    }

    moveNeedsChecking = false;  // since move has been checked
  }  // end of checkForCollision()


  public void checkTouching()
  // check if either of the grabbers fingers are touching the ground
  {
    if (leftGrabber.touchingGround())
      System.out.println("Left Grabber's fingers are touching the ground");
    if (rightGrabber.touchingGround())
      System.out.println("Right Grabber's fingers are touching the ground");
  }  // end of checkTouching()

}  // end of Grabbers class
