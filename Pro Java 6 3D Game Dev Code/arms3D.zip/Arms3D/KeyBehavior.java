
// KeyBehavior.java
// Andrew Davison, June 2006, ad@fivedots.coe.psu.ac.th

/* All key presses are caught, and passed to the Grabbers object.
*/

import java.awt.event.*;
import java.awt.*;
import java.util.Enumeration;

import javax.media.j3d.*;



public class KeyBehavior extends Behavior
{
  private WakeupOnAWTEvent keyPress;
  private Grabbers grabbers;


  public KeyBehavior(Grabbers gs)
  { 
    grabbers = gs;
    keyPress = new WakeupOnAWTEvent( KeyEvent.KEY_PRESSED );
  }  // end of KeyBehavior()


  public void initialize()
  { wakeupOn( keyPress ); }


  public void processStimulus(Enumeration criteria)
  {
    WakeupCriterion wakeup;
    AWTEvent[] event;

    while( criteria.hasMoreElements() ) {
      wakeup = (WakeupCriterion) criteria.nextElement();
      if( wakeup instanceof WakeupOnAWTEvent ) {
        event = ((WakeupOnAWTEvent)wakeup).getAWTEvent();
        for( int i = 0; i < event.length; i++ ) {
          if( event[i].getID() == KeyEvent.KEY_PRESSED )
            processKeyEvent((KeyEvent)event[i]);
        }
      }
    }
    wakeupOn( keyPress );
  } // end of processStimulus()


  private void processKeyEvent(KeyEvent eventKey)
  { 
    int keyCode = eventKey.getKeyCode();
    // System.out.println(keyCode);
    grabbers.processKey(keyCode, eventKey.isShiftDown(),
                                 eventKey.isAltDown());
  } // end of processKeyEvent()


} // end of KeyBehavior class
