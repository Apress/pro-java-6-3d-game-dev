
// Grabber.java
// Andrew Davison, June 2006, ad@fivedots.coe.psu.ac.th

/* The grabber has a vertical base, forearm and two fingers.
   The base can move left/right, forwarde/back over the XZ plane.
   The forearm is rotated to face along the -z axis, and
   can turn left/right, up/down, and spin around it's forearm.
   The two fingers are vertically placed, and can open and
   close.

   There are three joints between the base and forearm for the
   x-, y-, and z- axes, and one joint for each finger.

   The grabber supports bounds detection for its forearm and fingers,
   so it cannot move through the other grabber.
*/


// import java.text.DecimalFormat;
import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.geometry.*;


public class Grabber
{
  // joint rotation amount
  private final static int ROTATE_DEG = 2;  // degrees
  private final static double ROTATE_AMT = Math.toRadians(ROTATE_DEG);

  // rotation joint names (used by Grabbers)
  public static final int X_JOINT = 0;
  public static final int Y_JOINT = 1;
  public static final int Z_JOINT = 2;
  public static final int FING_JOINT = 3;

  // rotation directions (used by Grabbers)
  public static final int POS = 0;
  public static final int NEG = 1;


  private Appearance grabberApp; 

  private TransformGroup baseTG;  // top-level TG 

  // grabber's joints
  private TransformGroup jointXTG, jointYTG, jointZTG, topFingTG, botFingTG;

  // for collision detection
  private GrabberBounds grabberBounds;
  private TransformGroup[] collisionJoints;  // joint TGs that may cause collisions

  // rotation joints current angle (in degrees)
  int xCurrAngle, yCurrAngle, zCurrAngle, fingCurrAngle;

  // reusable objects for calculations
  private Transform3D t3d = new Transform3D();
  private Transform3D toRot = new Transform3D();

  // for debugging reporting
  // private DecimalFormat df = new DecimalFormat("0.##");  // 2 dp


  public Grabber(String name, Texture2D tex, float xPos)
  {
    makeAppearance(tex);
    makeGrabber(name, xPos);
  }  // end of Grabber()


  private void makeAppearance(Texture2D tex)
  // shiny metallic appearance, combining a material and texture
  {
    grabberApp = new Appearance();

    // combine texture with material and lighting of underlying surface
    TextureAttributes ta = new TextureAttributes();
    ta.setTextureMode( TextureAttributes.MODULATE );
    grabberApp.setTextureAttributes( ta );

    // shiny metal material
    Color3f alumDiffuse = new Color3f(0.37f, 0.37f, 0.37f);
    Color3f black = new Color3f(0.0f, 0.0f, 0.0f);
    Color3f alumSpecular = new Color3f(0.89f, 0.89f, 0.89f);

    Material armMat = new Material(alumDiffuse, black, alumDiffuse, alumSpecular, 17);
       // sets ambient, emissive, diffuse, specular, shininess
    armMat.setLightingEnable(true);
    grabberApp.setMaterial(armMat);

    // apply texture to the shape
    if (tex != null)
      grabberApp.setTexture(tex);
  }  // end of makeAppearance();



  private void makeGrabber(String name, float xPos)
  /* Build the grabber's vertical base, forearm and two fingers.
     Include x-, y-, z- rotation joints and the finger joints.
     Add grabber bounds for the forearm and fingers.
  */
  {
    // limb dimensions
    float baseWidth = 0.24f;
    float baseLen = 2.0f;
    float foreArmLen = 4.0f;

    /* position baseTG at the base limb's midpoint, so the limb
       will rest on the floor */
    t3d.set( new Vector3f(xPos, baseLen/2, 0));
    baseTG = new TransformGroup(t3d);

    // make base limb
    com.sun.j3d.utils.geometry.Box baseLimb = 
        new com.sun.j3d.utils.geometry.Box(baseWidth/2, baseLen/2, baseWidth/2, 
                       Primitive.GENERATE_NORMALS |
                       Primitive.GENERATE_TEXTURE_COORDS, grabberApp);
    baseTG.addChild(baseLimb);

    // move to top of base limb
    t3d.set( new Vector3f(0, baseLen/2, 0)); 
    TransformGroup baseTopTG = new TransformGroup(t3d);
    baseTG.addChild(baseTopTG);

    /* add jointXTG for left/right swings, start it rotated by 90 degrees
       so the rest of the grabber points along the -z axis */
    t3d.rotX(Math.toRadians(-90));
    jointXTG = new TransformGroup(t3d);
    jointXTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
    jointXTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
    jointXTG.setUserData(name + "-X");   // identify the joint
    baseTopTG.addChild(jointXTG);

    // add jointYTG for up/down swings
    jointYTG = new TransformGroup();
    jointYTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
    jointYTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
    jointYTG.setUserData(name + "-Y");  // identify the joint
    jointXTG.addChild(jointYTG);

    // add jointZTG for spinning the forearm
    jointZTG = new TransformGroup();
    jointZTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
    jointZTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
    jointYTG.addChild(jointZTG);

    // set up bounds checking for the grabbers forearm and fingers
    grabberBounds = new GrabberBounds(jointZTG, (1.0f - baseWidth/2), 0.25, 7);

    /* Move to the middle of forearm limb - half width of baseLimb.
       This will ensure that the end of the forearm will coincide with the
       left side of the base limb when drawn. */
    t3d.set( new Vector3f(0, (foreArmLen/2 - baseWidth/2), 0));
    TransformGroup midTG = new TransformGroup(t3d);
    jointZTG.addChild(midTG);

    // make forearm limb
    Cylinder foreArmLimb = new Cylinder(0.25f, foreArmLen,  // radius was 0.15f
                       Primitive.GENERATE_NORMALS |
                       Primitive.GENERATE_TEXTURE_COORDS, grabberApp);
    midTG.addChild(foreArmLimb);

    // move to end of forearm
    t3d.set( new Vector3f(0, foreArmLen/2, 0));
    TransformGroup wristTG = new TransformGroup(t3d);
    midTG.addChild(wristTG);

    float fingerRadius = 0.1f;

    // create topFingTG for up/down rotation of the top finger
    topFingTG = new TransformGroup();
    makeFinger(fingerRadius, wristTG, topFingTG);

    // create botFingTG for down/up rotation of the bottom finger
    botFingTG = new TransformGroup();
    makeFinger(-fingerRadius, wristTG, botFingTG);

    // store references to the joints that _may_ cause collisions
    collisionJoints = new TransformGroup[2];
    collisionJoints[0] = jointXTG;
    collisionJoints[1] = jointYTG;
      // don't bother with jointZTG and the finger joints
  }  // end of makeGrabber()


  private void makeFinger(float offset, TransformGroup wristTG, 
                                                TransformGroup rotTG)
  /* A finger is offset towards the forearm top/bottom edge, is connected
     to the forearm at wristTG, and rotates using rotTG. */
  {
    // finger dimensions
    float fingerRadius = Math.abs(offset);
    float fingerLen = 1.0f;

    // move finger by offset towards the forearm's edge
    t3d.set( new Vector3f(0,0,offset));  // along local z-axis
    TransformGroup fingTG = new TransformGroup(t3d);
    wristTG.addChild(fingTG);

    // add in finger rotation TG
    rotTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
    rotTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
    fingTG.addChild(rotTG);

    /* forward to middle of finger - radius of finger.
       This will mean that the finger will be drawn with one end
       embedded in the forearm. */
    t3d.set( new Vector3f(0, (fingerLen/2 - fingerRadius), 0));
    TransformGroup midTG = new TransformGroup(t3d);
    rotTG.addChild(midTG);

    // make finger limb
    Cylinder finger = new Cylinder(fingerRadius, fingerLen, 
                             Primitive.GENERATE_NORMALS |
                             Primitive.GENERATE_TEXTURE_COORDS, grabberApp);
    midTG.addChild(finger);
  }  // end of makeFinger()


  public TransformGroup getBaseTG()
  {  return baseTG;  }

  public TransformGroup[] getCollisionJoints()
  {  return collisionJoints;  }


  // ------------------- rotation methods --------------------------

  public boolean rotate(int rotType, int dir)
  /* Called by Grabbers to rotate a joint in a positive or 
     negative direction. */
  {
    int degAngle;   // angle in degrees
    double angle;   // angle in radians

    // test if the rotation is possible
    if (dir == POS) {
      degAngle = ROTATE_DEG;
      if (!withinRange(rotType, degAngle))
        return false;  // do nothing
      angle = ROTATE_AMT;
    }
    else {  // dir == NEG
      degAngle = -ROTATE_DEG;
      if (!withinRange(rotType, degAngle))
        return false;  // do nothing
      angle = -ROTATE_AMT;
    }

    // carry out the rotation; store the new joint angle
    if (rotType == X_JOINT) {       // left/right movement
      doRotate(jointXTG, X_JOINT, angle);
      xCurrAngle += degAngle;
    }
    else if (rotType == Y_JOINT) {  // up/down movement
      doRotate(jointYTG, Y_JOINT, angle);
      yCurrAngle += degAngle;
    }
    else if (rotType == Z_JOINT) {  // spinning around forearm
      doRotate(jointZTG, Z_JOINT, angle);
      zCurrAngle += degAngle;
    }
    else if (rotType == FING_JOINT) {   // up/down of fingers
      doRotate(topFingTG, Y_JOINT, angle);   // up (or down) of top finger
      doRotate(botFingTG, Y_JOINT, -angle);  // down (or up) of bottom finger
      fingCurrAngle += degAngle;
    }
    else {
      System.out.println("Did not recognise rotation type: " + rotType);
      return false;
    }

    return true;
  }  // end of rotate()


  private boolean withinRange(int rotType, int degAngle)
  /* Only do a rotation if it doesn't exceed the joint's range;
     the range's are hardwired. */
  {
    int nextAngle;

    if (rotType == X_JOINT) {
      nextAngle = xCurrAngle + degAngle;
      return ((nextAngle >= -45) && (nextAngle <= 45));
    }
    else if (rotType == Y_JOINT) {
      nextAngle = yCurrAngle + degAngle;
      // System.out.println("Y_JOINT degAngle: " + nextAngle);
      return ((nextAngle >= -45) && (nextAngle <= 45));
    }
    else if (rotType == Z_JOINT) {
      nextAngle = zCurrAngle + degAngle;
      return ((nextAngle >= -90) && (nextAngle <= 90));
    }
    else if (rotType == FING_JOINT) {
      nextAngle = fingCurrAngle + degAngle;
      // System.out.println("FING_JOINT degAngle: " + nextAngle);
      return ((nextAngle >= 0) && (nextAngle <= 20));
    }

    System.out.println("Did not recognise rotation type: " + rotType);
    return false;
  }  // end of withinRange()


  private void doRotate(TransformGroup tg, int rotType, double angle)
  // rotate the tg joint
  {
    tg.getTransform(t3d);

    if (rotType == X_JOINT)
      toRot.rotZ(angle);    // left/right == rotation around z-axis
    else if (rotType == Y_JOINT)
      toRot.rotX(angle);    // up/down == rotation around x-axis
    else   // must be Z_JOINT
      toRot.rotY(angle);    // spin == rotation around y-axis

    t3d.mul(toRot);     // t3d = t3d * toRot, which adds the rotation
    tg.setTransform(t3d);
  } // end of doRotate()


  // -------------------------- check grabber bounds ------------------

  public BoundingSphere[] getArmBounds()
  {  return grabberBounds.getArmBounds();  }

  public boolean touches(BoundingSphere[] bs)
  {  return grabberBounds.touches(bs); } 

  public boolean touchingGround()
  {  return grabberBounds.touchingGround();  }


  // ----------------------- debugging ------------------
/*
  private void printTuple(String id, Tuple3f t)
  {
    System.out.println(id + " (" + df.format(t.x) + 
			", " + df.format(t.y) + ", " + df.format(t.z) + ")");
  }  // end of printTuple()
*/

}  // end of Grabber class